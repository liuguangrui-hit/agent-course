# Lesson 0 materials: Getting started

notes.md is the raw record of a group meeting; the people and content are fictional. The exercise trains the separation of a source file, a product derived from it and an independent check of that product. Follow the Getting started page on the course site.
