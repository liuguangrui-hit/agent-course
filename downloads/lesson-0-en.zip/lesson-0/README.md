# Session 0 materials

notes.md is a raw record of a group meeting. People and content are fictional. Follow the Setup page of the course site.
