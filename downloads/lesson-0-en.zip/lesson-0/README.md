# Lesson 0 materials: Getting started

notes.md is a raw record of a group meeting. People and content are fictional. Follow the Getting started page on the course site.
