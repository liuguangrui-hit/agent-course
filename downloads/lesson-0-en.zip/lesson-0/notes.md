Group meeting notes, Oct 9, afternoon

Present: Prof. Wang, Li, Chen, Jay (Zhou on leave)

Li first. Baseline reproduced but almost 2 points below the paper, suspects preprocessing differs. Prof. Wang: don't tune yet, align preprocessing first, list the differences and post to the group chat by Friday
Chen: rebuttal for the submitted paper. Reviewer 2 mainly says ablations are missing, discussed, decided to add two ablations, one without the retrieval module, one with a smaller model. Chen runs them, Jay helps check the code
rebuttal deadline Oct 20!!
Jay says GPU 3 on the server keeps dropping, Prof. Wang says tell the admin, Jay will do it
then talked about next term's admissions, nothing decided, next time
Prof. Wang mentioned: from now on we take turns writing meeting notes, Chen writes next week's
oh and next week's meeting moves to Thursday 10am because Prof. Wang travels on Wednesday
Chen needs first ablation results by Oct 15
