# Lesson 2 materials: Agent exploration

A verified fourteen-paper list, an empty vault and a six-paper Obsidian preview for practicing full-text retrieval, note writing and research questions.

- [papers.md](papers.md): Paper metadata, entry points and verified versions.
- [vault/](vault/): The learner vault. sources/ holds downloads and the generated manifest.csv; papers/ holds paper notes; concepts/ holds concept notes. .gitkeep preserves the empty directories.
- [vault/templates/paper.md](vault/templates/paper.md): The paper template from the follow-up lesson.
- [preview/README.md](preview/README.md): How to open the example, interpret page references and trace numbers.
- [preview/vault/](preview/vault/): Six paper notes, three concepts, disagreements and three testable questions.
- [preview/baseline.csv](preview/baseline.csv): Means computed from existing Lesson 1 results.
- [preview/timing.csv](preview/timing.csv): Measured single-seed runtimes for the minimal question changes.
- [AGENTS.md](AGENTS.md) and [CLAUDE.md](CLAUDE.md): Project conventions and shared entry point.

Open `preview/vault/` in Obsidian first, then use `vault/` for exercises. Preview source fields name the learner's future downloads; versions and page counts are in manifest.csv. No PDFs are distributed.

Interpret task-card paths from the lesson material root. Place Lesson 1 in the adjacent `lesson-1/`. Exercise 1 creates `vault/sources/manifest.csv`; exercise 2 creates paper and concept notes plus `vault/conflicts.md`; exercise 3 creates `vault/questions.md`, then novelty review creates `vault/novelty.md`. Follow-up exercises may create `papers.csv`, `notes/publishers.md`, `criteria.md` and `screening/`.
