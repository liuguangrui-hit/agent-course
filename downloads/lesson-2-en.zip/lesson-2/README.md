# Lesson 2 exercise materials: Research knowledge bases

## Stages of the session

- Preparation: install the browser and Obsidian, complete sign-ins, and obtain the full texts of items 2, 5 and 11.
- Class session: verify the source documents, divide the reading of three papers, and propose competing explanations based on differences in experimental conditions.
- Review and extension: first redraw the evidence chain, then assess two records of a disagreement, and finally add a version comparison or an update prompted by a counterexample.

Record your preparation checks in preflight.md and your review in review-after-class.md. The session page gives the timing of each activity and the examples for comparison. Complete installations and downloads before class so that the materials are ready for use.

The materials consist of a list of fourteen verified papers, an empty knowledge base and six reading examples that open in Obsidian. They are used to practice obtaining full texts, recording evidence with its conditions and sources, and turning a disagreement in the literature into a testable question.

- [papers.md](papers.md): metadata and entry points for the fourteen papers, with the versions checked.
- [vault/](vault/): the students' knowledge base. sources/ holds downloaded originals and the manifest.csv generated after downloading; papers/ holds paper pages; concepts/ holds concept pages; the three directories are kept with .gitkeep.
- [vault/templates/paper.md](vault/templates/paper.md): the same paper-page template as on the extension page.
- [preview/README.md](preview/README.md): how to open the finished example, the page-number rules and where the numbers come from.
- [preview/vault/](preview/vault/): paper pages for the six papers read, three concept pages, a disagreement table and three testable questions.
- [preview/baseline.csv](preview/baseline.csv): means of the existing experiment results from Lesson 1.
- [preview/timing.csv](preview/timing.csv): actual single-seed run times for the minimal change behind each of the three questions.
- [AGENTS.md](AGENTS.md) and [CLAUDE.md](CLAUDE.md): project conventions and the shared entry point.

Open `preview/vault/` in Obsidian to examine the finished example first, then set `vault/` as your exercise vault. The source field in the examples is the relative file name students use when downloading; the actual version and checked page count are recorded in manifest.csv. The materials contain no PDFs.

Task-card paths are relative to the root of this session's materials. The Lesson 1 materials are in the neighboring `lesson-1/`. Exercise 1 generates `vault/sources/manifest.csv`; Exercise 2 generates paper pages, concept pages and `vault/conflicts.md`; Exercise 3 generates `vault/questions.md`, and the novelty search then generates `vault/novelty.md`. The review and extension exercises generate `papers.csv`, `notes/publishers.md`, `criteria.md` and `screening/` as needed.

Complete the review, independent work and transfer assessment specified on the session page. Any identified core readings are required; remaining extension topics are optional.

Attribution of a disagreement must identify explanations ruled out and still possible, the available evidence, and the discriminating control needed. Insufficient evidence must be recorded explicitly.
