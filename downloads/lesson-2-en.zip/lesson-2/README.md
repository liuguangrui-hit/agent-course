# Lesson 2 exercise materials: Research knowledge bases

## The three stages of this lesson

- Before class: install the browser and Obsidian, complete logins, and get the full texts of items 2, 5 and 11.
- In class: verify the source documents, split the reading of three papers, and propose competing explanations based on differences in experimental conditions.
- After class: first redraw the evidence chain, then judge two disagreement records, and finally add a version comparison or an update prompted by a counterexample.

Record your preparation checks in preflight.md and your after-class review in review-after-class.md. The lesson page gives the timing for each activity and examples to compare. Complete installations and downloads before class so the materials are ready to use.

A list of fourteen verified papers, an empty knowledge base, and six reading examples that open in Obsidian, for practicing downloading full texts, writing notes and proposing questions.

- [papers.md](papers.md): metadata and entry points for the fourteen papers, with the versions checked.
- [vault/](vault/): the students' knowledge base. sources/ holds downloaded originals and the manifest.csv generated after downloading; papers/ holds paper pages; concepts/ holds concept pages; the three directories are kept with .gitkeep.
- [vault/templates/paper.md](vault/templates/paper.md): the same paper-page template as on the after-class deep-dive page.
- [preview/README.md](preview/README.md): how to open the finished example, the page-number rules and where the numbers come from.
- [preview/vault/](preview/vault/): paper pages for the six papers read, three concept pages, a disagreement table and three testable questions.
- [preview/baseline.csv](preview/baseline.csv): means of the existing experiment results from Lesson 1.
- [preview/timing.csv](preview/timing.csv): actual single-seed run times for the minimal change behind each of the three questions.
- [AGENTS.md](AGENTS.md) and [CLAUDE.md](CLAUDE.md): project conventions and the shared entry point.

Open `preview/vault/` in Obsidian to see the finished example first, then set `vault/` as your exercise vault. The source field in the examples is the relative file name students use when downloading; the actual version and checked page count are recorded in manifest.csv. The materials contain no PDFs.

Interpret task-card paths relative to the root of this lesson's materials. The Lesson 1 materials sit in the neighboring `lesson-1/`. Exercise 1 generates `vault/sources/manifest.csv`; Exercise 2 generates paper pages, concept pages and `vault/conflicts.md`; Exercise 3 generates `vault/questions.md`, and the novelty search then generates `vault/novelty.md`. After-class exercises generate `papers.csv`, `notes/publishers.md`, `criteria.md` and `screening/` as needed.
