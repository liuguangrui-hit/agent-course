# Fourteen-paper reading list

Verified on 2026-10-13. Titles, first authors and years for the twelve preprints come from the [arXiv API](https://export.arxiv.org/api/query?id_list=1706.05394,1805.07836,1804.06872,1712.05055,1908.06112,2002.07394,1609.03683,2007.00151,1911.00068,2103.14749,2006.13554,2007.08199&max_results=20). Preprint years refer to first submission; publisher entries use publication years. The returned versions fix the preview page references.

| Number | Title | First author | Year | arXiv identifier or DOI | Source type | Verified version |
|---|---|---|---|---|---|---|
| 1 | A Closer Look at Memorization in Deep Networks | Devansh Arpit | 2017 | [1706.05394](https://arxiv.org/abs/1706.05394v2) | arXiv | 1706.05394v2 |
| 2 | Generalized Cross Entropy Loss for Training Deep Neural Networks with Noisy Labels | Zhilu Zhang | 2018 | [1805.07836](https://arxiv.org/abs/1805.07836v4) | arXiv | 1805.07836v4 |
| 3 | Co-teaching: Robust Training of Deep Neural Networks with Extremely Noisy Labels | Bo Han | 2018 | [1804.06872](https://arxiv.org/abs/1804.06872v3) | arXiv | 1804.06872v3 |
| 4 | MentorNet: Learning Data-Driven Curriculum for Very Deep Neural Networks on Corrupted Labels | Lu Jiang | 2017 | [1712.05055](https://arxiv.org/abs/1712.05055v2) | arXiv | 1712.05055v2 |
| 5 | Symmetric Cross Entropy for Robust Learning with Noisy Labels | Yisen Wang | 2019 | [1908.06112](https://arxiv.org/abs/1908.06112v1) | arXiv | 1908.06112v1 |
| 6 | DivideMix: Learning with Noisy Labels as Semi-supervised Learning | Junnan Li | 2020 | [2002.07394](https://arxiv.org/abs/2002.07394v1) | arXiv | 2002.07394v1 |
| 7 | Making Deep Neural Networks Robust to Label Noise: a Loss Correction Approach | Giorgio Patrini | 2016 | [1609.03683](https://arxiv.org/abs/1609.03683v2) | arXiv | 1609.03683v2 |
| 8 | Early-Learning Regularization Prevents Memorization of Noisy Labels | Sheng Liu | 2020 | [2007.00151](https://arxiv.org/abs/2007.00151v2) | arXiv | 2007.00151v2 |
| 9 | Confident Learning: Estimating Uncertainty in Dataset Labels | Curtis G. Northcutt | 2019 | [1911.00068](https://arxiv.org/abs/1911.00068v6) | arXiv | 1911.00068v6 |
| 10 | Pervasive Label Errors in Test Sets Destabilize Machine Learning Benchmarks | Curtis G. Northcutt | 2021 | [2103.14749](https://arxiv.org/abs/2103.14749v4) | arXiv | 2103.14749v4 |
| 11 | Normalized Loss Functions for Deep Learning with Noisy Labels | Xingjun Ma | 2020 | [2006.13554](https://arxiv.org/abs/2006.13554v1) | arXiv | 2006.13554v1 |
| 12 | Learning from Noisy Labels with Deep Neural Networks: A Survey | Hwanjun Song | 2020 | [2007.08199](https://arxiv.org/abs/2007.08199v7) | arXiv | 2007.08199v7 |
| 13 | Classification in the Presence of Label Noise: A Survey | Benoît Frénay | 2014 | [10.1109/TNNLS.2013.2292894](https://doi.org/10.1109/TNNLS.2013.2292894) | Publisher | IEEE TNNLS |
| 14 | Learning from noisy examples | Dana Angluin | 1988 | [10.1007/BF00116829](https://doi.org/10.1007/BF00116829) | Publisher | Machine Learning |

Both publisher entries were checked through DOI metadata and OpenAlex: [Frénay 2014](https://api.openalex.org/works/https://doi.org/10.1109/TNNLS.2013.2292894) and [Angluin 1988](https://api.openalex.org/works/https://doi.org/10.1007/BF00116829). Title differences are capitalization only; authors and years agree. Frénay retains the original accented spelling; DOI metadata uses Benoit Frenay.

First-submission years differ from common publication years for MentorNet, 2017, and Patrini, 2016. Confident Learning was first submitted on 2019-10-31 and ELR on 2020-06-30. Years follow the API records.

Source type identifies the list's entry point. Angluin's [publisher PDF](https://link.springer.com/content/pdf/10.1007%2FBF00116829.pdf) was directly accessible during verification and contained 28 pages, matching the OpenAlex full-text link. OpenAlex marks Frénay as closed; use its DOI to enter the publisher workflow.

The [preview guide](preview/README.md) lists the six papers read and the page convention. During exercises, save downloaded PDFs in `vault/sources/` and notes in `vault/papers/`.
