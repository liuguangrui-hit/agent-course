---
title: 'A Closer Look at Memorization in Deep Networks'
authors: Devansh Arpit et al.
year: 2017
source: sources/arpit2017.pdf
arxiv_version: 1706.05394v2
source_url: https://arxiv.org/abs/1706.05394v2
---

## Question

Does fitting real data use the same memorization behavior as fitting random labels? PDF p. 1 to 2.

## Setting

Two-layer ReLU MLPs on MNIST use 4096 units per layer by default. CNNs are used on CIFAR-10. Input noise and label noise are studied separately. PDF p. 2.

## Main results

- Across experiments replacing 20% to 80% of inputs or labels, higher noise lowers both final and maximum validation accuracy. PDF p. 7, Figures 7 and 8.
- With random labels, validation accuracy peaks before training accuracy becomes high. The authors interpret this as learning shared patterns before fitting noise. PDF p. 7, Figures 7 and 8.
- Tuned dropout can reduce training performance on random labels while preserving validation performance on real CIFAR-10. PDF p. 7, Figure 10.

## Relation to this topic

This motivates connecting [[memorization]] to [[early-stopping]] and recording accuracy each epoch. Basis: PDF p. 7.
