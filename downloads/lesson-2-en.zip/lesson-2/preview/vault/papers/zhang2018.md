---
title: 'Generalized Cross Entropy Loss for Training Deep Neural Networks with Noisy Labels'
authors: Zhilu Zhang et al.
year: 2018
source: sources/zhang2018.pdf
arxiv_version: 1805.07836v4
source_url: https://arxiv.org/abs/1805.07836v4
---

## Question

Can a loss combine cross entropy optimization with MAE noise tolerance? PDF p. 1 and p. 4.

## Setting

ResNet-34 is used on CIFAR-10 and CIFAR-100. A 10% validation split has noisy labels like training; test labels remain clean. Results use five runs. PDF p. 6 to 8.

## Main results

- GCE is Lq = [1 - p_y^q] / q. It approaches cross entropy as q approaches 0 and is proportional to MAE at q = 1. PDF p. 4, Equation 6.
- On clean CIFAR-100, MAE peaks at 38.29% after 2000 epochs, while CCE reaches 39.92% by epoch 7. PDF p. 4.
- At 40% uniform noise on CIFAR-10, CCE, GCE and truncated GCE achieve 81.88 ± 0.29%, 87.13 ± 0.22% and 87.62 ± 0.26%, selecting epochs by noisy validation accuracy. PDF p. 8, Table 1.
- At 40% open-set noise, final-epoch MAE, GCE and truncated GCE achieve 75.06%, 71.10% and 79.55%. PDF p. 8, Table 2.

## Relation to this topic

[[robust-losses]] separates noise tolerance from optimization; [[early-stopping]] records the use of noisy validation labels. Basis: PDF p. 4 and p. 6 to 8.
