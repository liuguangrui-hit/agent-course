# Three testable questions

The numbers below are predictions and decision thresholds awaiting tests. Observed Lesson 1 means across five seeds are in the [baseline table](../baseline.csv): at 40% noise, final CE is 67.39%, mean per-run peak CE is 93.00%, final GCE is 96.00%, and final small_loss is 90.44%. Peak test accuracy describes existing curves.

All questions retain the Gaussian mixture, ten classes, 512 hidden units, 80 epochs and seeds 0 to 4. Pair conditions using identical training data, corruptions and initialization. Paths are relative to this lesson's material root; use `../lesson-1/code/run_experiment.py`. Test labels are used for reporting. Run each question separately and retain seed-level results and means.

## 1 Can early stopping still prevent memorization when validation labels are also noisy?

Abstract: Fix training corruption at 40% uniform flips. On an independent validation split, compare clean labels with labels corrupted at the same rate. Select the first epoch of maximum validation accuracy. Prediction: selected epochs differ by at most 10 epochs, noisy-validation selection loses at most 3 percentage points of clean test accuracy relative to clean-validation selection, and its wrong-label fitting rate on corrupted training examples is below epoch 80. Failure of any condition in the five-seed means refutes the prediction. Zhang already uses noisy validation labels; this question measures epoch displacement and direct memorization in the Lesson 1 setting.

Minimal change: Set `make_data` to `n_test=3000`; reserve the first 1000 held-out examples for validation and the remaining 2000 for testing. Corrupt validation labels once with `flip` and an independent RNG seeded by `2000 + seed`. Each epoch, predict on concatenated validation, test and training inputs. Record clean-validation accuracy, noisy-validation accuracy, test accuracy and the fraction of examples with `y_noisy != y` predicted as their wrong label. Return these four columns instead of a scalar curve. Use `np.argmax` for first-maximum selection and read test and memorization values at each chosen epoch. One curve gives both selection rules; five training runs suffice. Save `vault/stopping.csv`.

Source notes: [[early-stopping]], [[memorization]], [[zhang2018]] PDF p. 6 to 8, and [[liu2020]] PDF p. 2.

## 2 Does moving GCE toward MAE cause insufficient learning within a fixed budget?

Abstract: At 40% training-label noise, compare GCE with q = 0.7 and q = 1, the latter proportional to MAE. Prediction: after the same 80 epochs, final clean test accuracy at q = 1 is at least 3 percentage points lower. A mean paired difference below 3 points across five seeds refutes the prediction. Lesson 1 final GCE at q = 0.7 averages 96.00%, an observed reference; the q = 1 comparison remains a prediction.

Minimal change: Keep only `gce` in `METHODS` and 0.4 in `NOISE`. Set `q = 0.7` in the loss branch to 0.7 and 1.0 in separate runs, using seeds 0 to 4. Retain final accuracy, peak accuracy and peak epoch; add a q column. Ten runs cover both settings. Save `vault/loss-q.csv`.

Source notes: [[robust-losses]], [[zhang2018]] PDF p. 4 to 5, and [[ma2020]] PDF p. 4 to 6.

## 3 Does earlier high-loss filtering improve final accuracy in a single network?

Abstract: At 40% training-label noise, shorten the small_loss retention schedule from ten epochs to two, keeping the same final 60% retention. Prediction: final test accuracy improves by at least 3 percentage points. A mean paired improvement below 3 points across five seeds refutes the prediction. The original Lesson 1 schedule averages 90.44% final and 96.45% peak accuracy, suggesting later deterioration; earlier filtering may instead lose useful hard examples.

Minimal change: Keep only `small_loss` and noise 0.4. Compare `ep / 10` against `ep / 2`, leaving everything else fixed. The ep counter starts at zero. Add the schedule length to output and run seeds 0 to 4, giving ten runs. Save `vault/selection-schedule.csv`.

Source notes: [[memorization]], row two of [[conflicts]], [[han2018]] PDF p. 3 to 5 and p. 8, and [[liu2020]] PDF p. 3.
