---
title: A Closer Look at Memorization in Deep Networks
authors: Arpit et al.
year: 2017
source: sources/arpit2017.pdf
---
## Question
## Setting
## Main results
- One conclusion and its number. PDF p. page number.
## Relation to this topic
