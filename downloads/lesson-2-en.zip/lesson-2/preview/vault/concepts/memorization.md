# Memorization

Networks can learn shared patterns before fitting wrong labels. Overall test accuracy records a consequence. The fraction of deliberately corrupted examples predicted as their wrong label measures the behavior this course aims to prevent. Underlearned classes can also lower accuracy, so both mechanisms need attention.

- [[arpit2017]]: With 20% to 80% noise, validation accuracy peaks while training accuracy continues rising. PDF p. 7.
- [[liu2020]]: Figure 1 separates fitting wrong labels from predicting true classes. ELR suppresses the former at 40% noise. PDF p. 2.
- [[han2018]]: Small-loss selection exploits early learning; selection errors and retention schedules affect useful data. PDF p. 3 to 5 and p. 8.
- [[wang2019]]: At 40% noise, class 3 achieves approximately 60% while class 6 exceeds 90%. Some classes remain underlearned. PDF p. 2 to 3.

Related concepts: [[early-stopping]] and [[robust-losses]]. The methodological disagreement in [[conflicts]] motivates question 3 in [[questions]].
