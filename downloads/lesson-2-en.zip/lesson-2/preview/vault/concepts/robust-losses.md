# Robust losses

Noise-tolerance theorems compare minimizers of clean and noisy risk. Finite-budget neural-network training also needs effective optimization. GCE, SCE and normalized combinations make different tradeoffs. Rankings can change with architecture, optimization and reporting epoch; the Lesson 1 Gaussian mixture can test one tradeoff at a time.

- [[zhang2018]]: GCE at q = 1 is proportional to MAE and approaches CE as q approaches 0. On clean CIFAR-100, MAE reaches only 38.29% after 2000 epochs. PDF p. 4.
- [[wang2019]]: SCE adds RCE for learning and tolerance. With 60% CIFAR-10 noise, SCE achieves 80.07% and GCE 75.20%. PDF p. 4 to 5 and p. 8.
- [[ma2020]]: Normalization needs assumptions and can still underfit. At the same benchmark and nominal noise rate, SCE achieves 66.08% and GCE 72.00%. PDF p. 4 and p. 7 to 8.
- [[liu2020]]: Historical-prediction regularization counters wrong-label gradients. PDF p. 5 to 6.

Related concepts: [[memorization]] and [[early-stopping]]. See [[conflicts]] for the ranking reversal and question 2 in [[questions]] for the q experiment.
