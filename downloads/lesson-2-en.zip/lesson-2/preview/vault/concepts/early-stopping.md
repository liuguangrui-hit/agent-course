# Early stopping

Early stopping selects an epoch using validation measurements. Noisy labels make label quality, the metric and tie handling relevant. Zhang already uses noisy validation labels. This course asks how far the selected epoch moves from clean-validation selection in Lesson 1 and measures wrong-label fitting directly.

- [[arpit2017]]: Validation performance peaks before training performance on random labels, motivating a stopping window. PDF p. 7.
- [[zhang2018]]: Validation labels are corrupted and epochs selected by validation accuracy. GCE reaches 87.13 ± 0.22% at 40% uniform noise. PDF p. 6 to 8.
- [[liu2020]]: ELR continues training while suppressing memorization. ELR+ results of 91.1% and 93.3% use different selection rules. PDF p. 5 to 8.
- [[wang2019]]: Some classes remain underlearned. Stopping too early may preserve this gap, a course inference based on PDF p. 2 to 3.

Related concepts: [[memorization]] and [[robust-losses]]. See question 1 in [[questions]].
