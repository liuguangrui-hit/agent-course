# Disagreements between papers

The first row records an empirical ranking reversal. The second records opposing methodological choices. Each result retains its own setting and metric.

| Paper A | Paper B | Setting | A reports | B reports | Possible reason |
|---|---|---|---|---|---|
| [[wang2019]] | [[ma2020]] | Both use CIFAR-10 with 60% symmetric noise. A uses an eight-layer CNN and stepwise learning-rate decay; B uses an eight-layer CNN and cosine annealing with different training parameters | SCE 80.07 ± 0.02%, GCE 75.20 ± 0.09%; SCE is higher. PDF p. 7 to 8, Table 1 | SCE 66.08 ± 0.25%, GCE 72.00 ± 0.37%; GCE is higher. PDF p. 7 to 8, Table 2 | Hypothesis: optimization, weight decay and epoch selection change rankings. Compare under one training implementation |
| [[han2018]] | [[liu2020]] | A uses a nine-layer CNN with exchanged sample selection; B uses ResNet-34 with historical-prediction regularization. The cited numbers concern 45% pair flips and 40% symmetric noise respectively | High-loss examples do not update parameters. CIFAR-10 pair-flip Co-teaching reaches 72.62 ± 0.15%, versus self-paced MentorNet 58.14 ± 0.38%. PDF p. 3 to 5 and p. 7, Table 5 | Regularization changes gradients while retaining examples. The authors note that small-loss selection favors easier examples. ELR reaches 89.15 ± 0.17% at 40% CIFAR-10 noise. PDF p. 3 and p. 5 to 7, Table 1 | Hypothesis: discarding examples removes noise but may lose useful hard patterns. Lesson 1 can first vary the selection schedule |

The first row informs [[robust-losses]]; the second informs [[memorization]]. [[questions]] turns these tradeoffs into tests.
