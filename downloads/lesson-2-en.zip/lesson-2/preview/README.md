# Completed example

Use Obsidian's open-local-vault option to open `vault/` in this directory and read six paper notes with their concepts, disagreements and questions.

- [vault/papers/](vault/papers/): Notes on Arpit, Zhang, Han, Wang, Liu and Ma.
- [vault/concepts/](vault/concepts/): Memorization, early stopping and robust losses, connected through Obsidian links.
- [vault/conflicts.md](vault/conflicts.md): A ranking reversal and disagreement over handling examples.
- [vault/questions.md](vault/questions.md): Titles, abstracts, predictions, refutation criteria, minimal changes and source notes.
- [vault/templates/paper.md](vault/templates/paper.md): Paper-note template.
- [vault/sources/manifest.csv](vault/sources/manifest.csv): PDF metadata, checked page counts, versions and SHA-256 hashes. Metadata only.
- [baseline.csv](baseline.csv): Means from data/results.csv in the same-language Lesson 1 materials.
- [timing.csv](timing.csv): Single-seed runtime measurements, using seed 0 and 80 epochs per condition.

Page numbers count the PDF cover as page 1 and include references and appendices. PDF lengths are Arpit 10, Zhang 14, Han 13, Wang 11, Liu 26 and Ma 13. Each PDF passed page-count and first-two-page title checks. Settings and results were read, and table pages rendered for verification. PDFs were read in the maker's temporary directory; source fields retain future download names.

The ± values are author-reported standard deviations. The cited Zhang, Han, Wang and Liu tables use five runs or noise realizations; Ma uses three. Some Liu Table 1 baselines come from Zhang, as recorded in the notes.

At 40% noise, existing Lesson 1 mean final accuracy is 67.39% for CE, 96.00% for GCE and 90.44% for small_loss, computed from five seeds. Measured single-seed runtimes here are 3.552 seconds for validation metrics; 1.791 and 1.345 seconds for q = 0.7 and 1.0; and 1.635 and 1.793 seconds for selection schedules 10 and 2. Every curve contains 80 finite rows. Timing checks the exercise budget; the abstract predictions await the learner's tests.
