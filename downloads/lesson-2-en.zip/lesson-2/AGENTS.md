# Project conventions
- Verify metadata through arXiv and OpenAlex; use Ego for subscription full text.
- Add originals to vault/sources/ without changing them; exclude PDFs from course distribution.
- Write paper notes in vault/papers/ with matching PDF names; cite the version and PDF page for each conclusion.
- Concepts in vault/concepts/ cite paper notes; write disagreements and questions in vault/conflicts.md and vault/questions.md.
