# Three orchestration decisions

These are calculations on example data representing two weeks of typical workbench use. Turn inputs and review comments are also examples. [calc.py](../calc.py) generated the numbers from [ledger.csv](../ledger.csv) and [conversations.csv](../conversations.csv).

## When to split a conversation

Start a new conversation about every **27 turns**. The optimal integer splits save an estimated 46.08% of total modeled cost.

| Conversation | Turns n | Raw growth | Equivalent c | Optimal segments m | Turns per segment | Saving |
|---|---:|---:|---:|---:|---:|---:|
| long-planning | 60 | 2,000 | 200 | 2 | 30.00 | 22.12% |
| long-analysis | 80 | 2,500 | 250 | 3 | 26.67 | 41.67% |
| long-writing | 100 | 3,000 | 300 | 4 | 25.00 | 55.31% |

Handoff length h = 2,000 raw tokens; one-time segment cost r = 80,000 token equivalents. Fit raw and priced input growth by least squares; --c overrides raw growth. Classroom rates per million tokens are USD 3 for uncached input, 0.3 for cache reads, 3.75 for cache writes, and 15 for output. Growing history and repeated handoffs use the cache-read rate. The formula uses h = 200 token equivalents. Express all cost terms in uncached-input token equivalents: F(m) = c·n²/(2m) + n·h + m·r, with m* = n·sqrt(c/2r). Compare neighboring integer segment counts and minimize F. Round the median turns per segment for the recommendation.

The combined one-segment baseline F(1) is 2,948,000 token equivalents; the optimal splits cost 1,589,667. Exercise 1 resets every 20 turns, using the actual final segment length, for a cost of 1,628,000 and savings of 44.78%. Both comparisons use the same cost model, including handoff reads on every turn and startup cost per segment.

## When to stop reviewing

With V = 500,000 token equivalents, **round 3** is the first to meet the stop condition.

| Round | Records with adopted substantive comments | p_k | Mean cost C | p_k·V | V threshold C/p_k |
|---|---:|---:|---:|---:|---:|
| 1 | 8/8 | 100.00% | 111,000 | 500,000 | 111,000 |
| 2 | 4/8 | 50.00% | 126,000 | 250,000 | 252,000 |
| 3 | 1/8 | 12.50% | 141,000 | 62,500 | 1,128,000 |
| 4 | 0/8 | 0.00% | 156,000 | 0 | no finite value |

Each denominator counts reviews of comparable manuscripts; each numerator counts reviews with at least one adopted substantive comment. Use the item decisions in [review.md](../review.md), rather than the adopted column. Read review_round and substantive from ledger.csv. Price all four token categories to obtain mean review cost C in uncached-input token equivalents, the same unit as V. Skip the round when p_k·V < C; continue at equality. In this calculation, complete 2 rounds before stopping. The C/p_k column gives value thresholds. For a new V, compare from round 1 and stop at the first strict inequality.

## When parallel work pays off

Four Sub-agents reduce elapsed time by **72.00%** and increase total tokens by 18.00%.

| Mode | Conversations | Minutes | Total tokens | Estimated USD cost |
|---|---:|---:|---:|---:|
| Serial | 1 | 50 | 100,000 | 0.3330 |
| Four Sub-agents plus coordinator | 5 | 14 | 118,000 | 0.4245 |

Both runs read the same 14 papers and produce adopted notes. Cost increases by 27.48%. Converting T and T′ to hours gives 0.60 hours saved for an extra USD 0.0915. Parallel work pays off when w > USD 0.1525 per hour. At w = 10, the time value is USD 6.00 and the strict comparison passes. Convert a time value in another currency to USD first.

Reproduce from this material directory:

```bash
python3 calc.py --lang en --v 500000 --w 10 --h 2000 --r 80000 --segment-turns 20 --output preview/decisions.md
```
