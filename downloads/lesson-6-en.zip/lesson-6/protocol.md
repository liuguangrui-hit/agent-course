# Frozen protocol for experience learning

This file is a template for the class trial. Before starting, the executor fills in each item in their own protocol file, and keeps worked-example data and real model calls separate.

## Fixed tasks and origin

Record the source of the tasks and the file hashes, and give each task a stable ID. Separate the learning period, the playbook-selection validation period and the final confirmation period, so different versions of the same paper do not leak across groups. For the origin, record the product version, model identifier, tools, permissions and time, and state truthfully what cannot be observed.

## Training and update

Record the initial playbook, capacity, update rule and budget. Answer first, then score, and finally update the playbook. Train one playbook with normal reward and one with shuffled reward; shuffling happens only in the training stage, and the confirmation stage always uses normal tasks and scoring. The update rule's versions are numbered separately.

## Three independent groups

board uses the target playbook, placebo uses a placebo matched in structure and approximate length, and noboard has no playbook attached. Record the matched tokens and output budget. Each task gets three independent sessions, in random order. One confirmation uses the frozen playbook; online replay saves the playbook at every step separately and is not mixed with the frozen-playbook confirmation.

## Scoring and failure

The main reward is between zero and one; define its direction and the code that computes it. A model reviewer has its version and rules frozen, groups and sources hidden, and positions randomized; disagreements in cross-vendor rechecks are recorded separately. Decide in advance how run failures count in the main result, and keep both the failure rate and the analysis conditional on completed tasks. Missing data are reported as errors by input validation; incomplete tasks must not be quietly dropped.

## Analysis and confirmation

Pair by task and report the three group means, board minus placebo, board minus noboard, and placebo minus noboard. Intervals resample independent tasks; repeated calls on the same question are first aggregated according to the protocol, and related papers are treated as clusters. Set the main comparison and a practically meaningful effect in advance, and design the sample size for the real test. The twelve questions in the package only demonstrate the calculation.

## Transfer and cost

Retest the same frozen playbook on another origin, with each origin having its own three groups. Record the costs of writing the playbook, retrieval, execution and evaluation, keeping real charges distinct from converted charges. Compare drift only under consistent tasks and scoring.

## Claim check

Give predictions and refutation conditions separately for content gain, dependence on correct reward and keeping value across origins. Where support is missing, give an experiment that adds evidence at the original scale; only when counterevidence exists or a claim cannot be tested, state the grounds for rewriting it.
