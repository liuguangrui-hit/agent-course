# Review item records

These example records cover the eight manuscripts and four review rounds in the example ledger. Each row records a new comment and its adoption decision.

A substantive comment changes the method, results, or conclusions. Wording changes are recorded separately. The example author makes adoption decisions. adopted describes the whole output; substantive counts substantive comments only.

## Round 1

| Ledger item_id | New comment | Type | Adopted | Other adopted content |
|---|---|---|---|---|
| review-A-1 | Document the fixed random seeds | substantive | yes | none |
| review-B-1 | Remove test samples from the validation set | substantive | yes | none |
| review-C-1 | Give baselines the same compute budget | substantive | yes | none |
| review-D-1 | Add repeated runs and uncertainty estimates | substantive | yes | none |
| review-E-1 | Correct the mix of normalized and raw metrics | substantive | yes | none |
| review-F-1 | Add a control at low noise levels | substantive | yes | none |
| review-G-1 | Define the missing-data exclusion rule | substantive | yes | none |
| review-H-1 | Narrow claims beyond the experimental scope | substantive | yes | none |

## Round 2

| Ledger item_id | New comment | Type | Adopted | Other adopted content |
|---|---|---|---|---|
| review-A-2 | Add ablations under the revised split | substantive | yes | none |
| review-B-2 | Use the same stopping rule for each baseline | substantive | yes | none |
| review-C-2 | Complete the compute-budget accounting | substantive | yes | none |
| review-D-2 | Label the uncertainty measure as standard deviation | substantive | yes | none |
| review-E-2 | Request an unrelated dataset | substantive | no | Standardize heading capitalization |
| review-F-2 | Request a metric incompatible with the experiment | substantive | no | Standardize heading capitalization |
| review-G-2 | Request removal of the disclosed exclusion rule | substantive | no | Standardize heading capitalization |
| review-H-2 | Request stronger claims beyond the evidence | substantive | no | Standardize heading capitalization |

## Round 3

| Ledger item_id | New comment | Type | Adopted | Other adopted content |
|---|---|---|---|---|
| review-A-3 | Report the training budget for the ablation | substantive | yes | none |
| review-B-3 | Suggest rewording a clear paragraph; author keeps it | wording | no | none |
| review-C-3 | Suggest rewording a clear paragraph; author keeps it | wording | no | none |
| review-D-3 | Suggest rewording a clear paragraph; author keeps it | wording | no | none |
| review-E-3 | Suggest rewording a clear paragraph; author keeps it | wording | no | none |
| review-F-3 | Suggest rewording a clear paragraph; author keeps it | wording | no | none |
| review-G-3 | Suggest rewording a clear paragraph; author keeps it | wording | no | none |
| review-H-3 | Suggest rewording a clear paragraph; author keeps it | wording | no | none |

## Round 4

| Ledger item_id | New comment | Type | Adopted | Other adopted content |
|---|---|---|---|---|
| review-A-4 | Check prior revisions; no new comment | none | no | none |
| review-B-4 | Check prior revisions; no new comment | none | no | none |
| review-C-4 | Check prior revisions; no new comment | none | no | none |
| review-D-4 | Check prior revisions; no new comment | none | no | none |
| review-E-4 | Check prior revisions; no new comment | none | no | none |
| review-F-4 | Check prior revisions; no new comment | none | no | none |
| review-G-4 | Check prior revisions; no new comment | none | no | none |
| review-H-4 | Check prior revisions; no new comment | none | no | none |

Set substantive to yes when an item_id has at least one substantive comment adopted as yes. The last four manuscripts in round 2 adopt only wording changes, so the whole output is partial while substantive adoption remains no.
