# Project conventions

- Read numbers from ledger.csv, conversations.csv, and review.md; generate preview/decisions.md with calc.py.
- Use the author decisions in review.md as the evidence for substantive adoption; the ledger summarizes them.
- Keep identical structure, code, and data across language versions; write explanations in the respective language.
