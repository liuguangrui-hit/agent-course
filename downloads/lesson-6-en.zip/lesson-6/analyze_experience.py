#!/usr/bin/env python3
"""Paired three-arm analysis. The supplied data are synthetic teaching data."""
import argparse
import csv
import json
from pathlib import Path
import random
import statistics

ARMS = {'board', 'placebo', 'noboard'}


def percentile(values, probability):
    ordered = sorted(values)
    position = (len(ordered) - 1) * probability
    lower = int(position)
    upper = min(lower + 1, len(ordered) - 1)
    return ordered[lower] + (position - lower) * (ordered[upper] - ordered[lower])


def analyze(path, repeats=5000):
    tasks, kinds = {}, set()
    with path.open(encoding='utf-8', newline='') as stream:
        reader = csv.DictReader(line for line in stream if not line.startswith('#'))
        required = {'behavior', 'origin', 'task_id', 'arm', 'score', 'data_kind'}
        if not required <= set(reader.fieldnames or []):
            raise ValueError('Missing required columns')
        for row in reader:
            key = (row['behavior'], row['origin'], row['task_id'])
            if not all(key):
                raise ValueError('Missing task or version identity')
            arm, score = row['arm'], float(row['score'])
            if arm not in ARMS or not 0 <= score <= 1:
                raise ValueError('Invalid arm or score')
            values = tasks.setdefault(key, {})
            if arm in values:
                raise ValueError(f'Duplicate arm for {key}')
            values[arm] = score
            kinds.add(row['data_kind'])
    if not tasks or len(kinds) != 1 or not kinds <= {'synthetic', 'real'}:
        raise ValueError('Empty data, invalid data kind, or mixed provenance')
    grouped = {}
    for (behavior, origin, task_id), values in sorted(tasks.items()):
        if set(values) != ARMS:
            raise ValueError(f'Incomplete three-arm task: {(behavior, origin, task_id)}')
        grouped.setdefault((behavior, origin), []).append(values)
    output = []
    rng = random.Random(20261015)
    for (behavior, origin), values in grouped.items():
        if len(values) < 2:
            raise ValueError('At least two independent task rows are required for a demo interval')
        content = [r['board'] - r['placebo'] for r in values]
        total = [r['board'] - r['noboard'] for r in values]
        placebo = [r['placebo'] - r['noboard'] for r in values]
        draws = {'content': [], 'total': [], 'placebo': []}
        for _ in range(repeats):
            indices = [rng.randrange(len(values)) for _ in values]
            for name, vector in (('content', content), ('total', total), ('placebo', placebo)):
                draws[name].append(statistics.mean(vector[i] for i in indices))
        report = {'behavior': behavior, 'origin': origin, 'n_tasks': len(values),
                  'means': {arm: statistics.mean(r[arm] for r in values) for arm in sorted(ARMS)}}
        for name, vector in (('content', content), ('total', total), ('placebo', placebo)):
            report[name] = {'mean': statistics.mean(vector),
                            'paired_bootstrap_ci95': [percentile(draws[name], .025),
                                                      percentile(draws[name], .975)]}
        output.append(report)
    return {'data_kind': kinds.pop(), 'bootstrap_seed': 20261015,
            'bootstrap_repeats': repeats, 'unit': 'task', 'reports': output}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, default=Path(__file__).with_name('experience_scores.csv'))
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()
    try:
        result = analyze(args.input)
    except (ValueError, OSError) as error:
        parser.exit(2, f'Analysis rejected: {error}\n')
    text = json.dumps(result, ensure_ascii=False, indent=2) + '\n'
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(text, encoding='utf-8')
    else:
        print(text, end='')


if __name__ == '__main__':
    main()
