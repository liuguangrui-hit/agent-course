#!/usr/bin/env python3
"""Calculate three orchestration decisions from the classroom example data."""
import argparse
import csv
from collections import defaultdict
import math
from pathlib import Path

INPUT_RATE = 3.0
CACHE_READ_RATE = 0.3
CACHE_WRITE_RATE = 3.75
OUTPUT_RATE = 15.0


def input_equivalent(row, uncached_field='input_tokens'):
    return (int(row[uncached_field])
            + int(row['cache_read_tokens']) * CACHE_READ_RATE / INPUT_RATE
            + int(row['cache_write_tokens']) * CACHE_WRITE_RATE / INPUT_RATE)


def cost_equivalent(row):
    return input_equivalent(row) + int(row['output_tokens']) * OUTPUT_RATE / INPUT_RATE


def total_tokens(row):
    return sum(int(row[field]) for field in
               ['input_tokens', 'cache_read_tokens', 'cache_write_tokens', 'output_tokens'])


def fitted_growth(turns, values):
    mean_turn = sum(turns) / len(turns)
    mean_value = sum(values) / len(values)
    return (sum((turn - mean_turn) * (value - mean_value)
                for turn, value in zip(turns, values))
            / sum((turn - mean_turn) ** 2 for turn in turns))


def positive(value):
    number = float(value)
    if not math.isfinite(number) or number <= 0:
        raise argparse.ArgumentTypeError('must be finite and greater than zero')
    return number


def nonnegative(value):
    number = float(value)
    if not math.isfinite(number) or number < 0:
        raise argparse.ArgumentTypeError('must be finite and nonnegative')
    return number


def positive_integer(value):
    number = int(value)
    if number < 1:
        raise argparse.ArgumentTypeError('must be a positive integer')
    return number


def read_csv(path):
    with path.open(encoding='utf-8', newline='') as source:
        return list(csv.DictReader(line for line in source if not line.startswith('#')))


def conversation_decisions(records, ledger, h, r, segment_turns, c_override=None):
    groups = defaultdict(list)
    for row in records:
        groups[row['conversation_id']].append(row)
    results = []
    for ident, rows in groups.items():
        rows.sort(key=lambda row: int(row['turn']))
        n = len(rows)
        turns = [int(row['turn']) for row in rows]
        inputs = [int(row['input_tokens']) for row in rows]
        if n < 2 or turns != list(range(1, n + 1)):
            raise ValueError('conversation turns must start at 1 and be consecutive')
        raw_fit = fitted_growth(turns, inputs)
        equivalent_inputs = [input_equivalent(row, 'uncached_input_tokens') for row in rows]
        c_fit = fitted_growth(turns, equivalent_inputs)
        # In this example, growing history is read from cache on subsequent turns.
        c = c_fit if c_override is None else c_override * CACHE_READ_RATE / INPUT_RATE
        if c <= 0:
            raise ValueError('the fitted cost growth must be positive')
        observed = sum(inputs)
        ledger_row = next(row for row in ledger if row['item_id'] == ident)
        if sum(int(ledger_row[field]) for field in
               ['input_tokens', 'cache_read_tokens', 'cache_write_tokens']) != observed:
            raise ValueError('conversation input sum does not match ledger')
        h_equivalent = h * CACHE_READ_RATE / INPUT_RATE
        m_continuous = n * math.sqrt(c / (2 * r))
        candidates = {max(1, min(n, math.floor(m_continuous))),
                      max(1, min(n, math.ceil(m_continuous)))}
        def objective(m):
            return c * n * n / (2 * m) + n * h_equivalent + m * r
        m = min(candidates, key=lambda value: (objective(value), value))
        fixed_m = math.ceil(n / segment_turns)
        # Apply the same formula to the actual fixed segment sizes, including the tail.
        sizes = [min(segment_turns, n - start) for start in range(0, n, segment_turns)]
        fixed_cost = c * sum(size * size for size in sizes) / 2 + n * h_equivalent + fixed_m * r
        baseline = objective(1)
        optimized = objective(m)
        results.append(dict(ident=ident, n=n, c=c, raw_fit=raw_fit, c_fit=c_fit,
                            observed=observed, baseline=baseline, optimized=optimized,
                            fixed_cost=fixed_cost, m_continuous=m_continuous, m=m,
                            interval=n / m, savings=(1 - optimized / baseline) * 100))
    return results


def review_decisions(ledger, value):
    groups = defaultdict(list)
    for row in ledger:
        if row['review_round']:
            groups[int(row['review_round'])].append(row)
    results = []
    for k, rows in sorted(groups.items()):
        count = sum(row['substantive'] == 'yes' for row in rows)
        p = count / len(rows)
        cost = sum(cost_equivalent(row) for row in rows) / len(rows)
        results.append(dict(k=k, count=count, total=len(rows), p=p, cost=cost,
                            expected=p * value, stop=p * value < cost,
                            threshold=cost / p if p else math.inf))
    return results


def parallel_decision(ledger, w):
    serial = next(row for row in ledger if row['item_id'] == 'notes-serial')
    parallel = next(row for row in ledger if row['item_id'] == 'notes-parallel')
    t, tp = float(serial['minutes']), float(parallel['minutes'])
    s, sp = float(serial['est_cost_usd']), float(parallel['est_cost_usd'])
    tokens = total_tokens(serial)
    tokens_p = total_tokens(parallel)
    hours_saved = (t - tp) / 60
    return dict(t=t, tp=tp, s=s, sp=sp, tokens=tokens, tokens_p=tokens_p,
                time_change=(tp / t - 1) * 100,
                token_change=(tokens_p / tokens - 1) * 100,
                cost_change=(sp / s - 1) * 100, hours_saved=hours_saved,
                threshold=(sp - s) / hours_saved,
                time_value=hours_saved * w, extra_cost=sp - s,
                worthwhile=hours_saved * w > sp - s)


def render(conversations, reviews, parallel, args):
    zh = args.lang == 'zh'
    baseline = sum(row['baseline'] for row in conversations)
    optimized = sum(row['optimized'] for row in conversations)
    fixed_cost = sum(row['fixed_cost'] for row in conversations)
    savings = (1 - optimized / baseline) * 100
    fixed_savings = (1 - fixed_cost / baseline) * 100
    interval = max(1, math.floor(
        sorted(row['interval'] for row in conversations)[len(conversations) // 2] + 0.5))
    stop = next((row['k'] for row in reviews if row['stop']), None)
    stop_label = str(stop) if stop else ('未触发' if zh else 'not reached')
    completed = stop - 1 if stop else reviews[-1]['k']
    lines = [
        '# 三个编排决策' if zh else '# Three orchestration decisions', '',
        ('以下是示例数据的计算结果。账本按一个工作台两周的典型用法编成，'
         '逐轮输入和审稿意见也是示例。数字由 [calc.py](../calc.py) 读取 '
         '[ledger.csv](../ledger.csv) 和 [conversations.csv](../conversations.csv) 后生成。'
         if zh else 'These are calculations on example data representing two weeks of typical '
         'workbench use. Turn inputs and review comments are also examples. '
         '[calc.py](../calc.py) generated the numbers from [ledger.csv](../ledger.csv) '
         'and [conversations.csv](../conversations.csv).'), '',
        '## 对话何时分段' if zh else '## When to split a conversation', '',
        (f'建议约每 **{interval} 轮** 换对话，按最优整数段数估算总成本节省 {savings:.2f}%。'
         if zh else f'Start a new conversation about every **{interval} turns**. The optimal integer splits save an estimated {savings:.2f}% of total modeled cost.'), '',
        ('| 对话 | 轮数 n | 原始增长 | 折算后的 c | 最优段数 m | 每段轮数 | 节省 |'
         if zh else '| Conversation | Turns n | Raw growth | Equivalent c | Optimal segments m | Turns per segment | Saving |'),
        '|---|---:|---:|---:|---:|---:|---:|',
    ]
    for row in conversations:
        raw_used = row['raw_fit'] if args.c is None else args.c
        lines.append(f"| {row['ident']} | {row['n']} | {raw_used:,.0f} | {row['c']:,.0f} | {row['m']} | {row['interval']:.2f} | {row['savings']:.2f}% |")
    lines += ['',
        (f'交接文件 h = {args.h:,.0f} 原始 token，每段一次性代价 r = {args.r:,.0f} token 等价。'
         '原始增长及成本增长由逐轮数据最小二乘拟合，--c 可覆盖原始增长。'
         '输入、缓存读取、缓存写入、输出的课堂费率分别为每百万 token 3、0.3、3.75、15 美元。'
         f'历史增长与交接重读按缓存价折算，h 在公式中为 {args.h * CACHE_READ_RATE / INPUT_RATE:,.0f} token 等价。'
         '所有成本项统一成未缓存输入 token 等价，使用 F(m) = c·n²/(2m) + n·h + m·r，'
         'm* = n·sqrt(c/2r)。比较相邻整数段数，取 F 最小者。建议轮数取每段轮数的中位数后四舍五入。'
         if zh else f'Handoff length h = {args.h:,.0f} raw tokens; one-time segment cost r = {args.r:,.0f} token equivalents. '
         'Fit raw and priced input growth by least squares; --c overrides raw growth. '
         'Classroom rates per million tokens are USD 3 for uncached input, 0.3 for cache reads, '
         '3.75 for cache writes, and 15 for output. Growing history and repeated handoffs use the cache-read rate. '
         f'The formula uses h = {args.h * CACHE_READ_RATE / INPUT_RATE:,.0f} token equivalents. '
         'Express all cost terms in uncached-input token equivalents: F(m) = c·n²/(2m) + n·h + m·r, '
         'with m* = n·sqrt(c/2r). Compare neighboring integer segment counts and minimize F. '
         'Round the median turns per segment for the recommendation.'), '',
        (f'三条对话的一段基准 F(1) 合计 {baseline:,.0f} token 等价，最优分段为 {optimized:,.0f}。'
         f'练习 1 每 {args.segment_turns} 轮分段，末段按实际轮数计算，总量 {fixed_cost:,.0f}，节省 {fixed_savings:.2f}%。'
         '这些比例比较同一分段模型中的成本，包含每轮交接读取与每段启动代价。'
         if zh else f'The combined one-segment baseline F(1) is {baseline:,.0f} token equivalents; '
         f'the optimal splits cost {optimized:,.0f}. Exercise 1 resets every {args.segment_turns} turns, '
         f'using the actual final segment length, for a cost of {fixed_cost:,.0f} and savings of {fixed_savings:.2f}%. '
         'Both comparisons use the same cost model, including handoff reads on every turn and startup cost per segment.'), '',
        '## 审稿何时停止' if zh else '## When to stop reviewing', '',
        (f'V = {args.v:,.0f} token 等价时，**第 {stop_label} 轮** 首次满足停止条件。'
         if zh else f'With V = {args.v:,.0f} token equivalents, **round {stop_label}** is the first to meet the stop condition.'), '',
        ('| 轮次 | 采纳实质意见的记录数 | p_k | 平均成本 C | p_k·V | V 临界值 C/p_k |'
         if zh else '| Round | Records with adopted substantive comments | p_k | Mean cost C | p_k·V | V threshold C/p_k |'),
        '|---|---:|---:|---:|---:|---:|',
    ]
    for row in reviews:
        threshold = f"{row['threshold']:,.0f}" if math.isfinite(row['threshold']) else ('无有限值' if zh else 'no finite value')
        lines.append(f"| {row['k']} | {row['count']}/{row['total']} | {row['p']:.2%} | {row['cost']:,.0f} | {row['expected']:,.0f} | {threshold} |")
    lines += ['',
        ('每轮分母为同类稿件的审稿记录数，分子为至少有一条被采纳实质意见的记录数。'
         '以 [review.md](../review.md) 的逐条决定为依据，不用 adopted 列代替。'
         '读取 ledger.csv 的 review_round 与 substantive 列。'
         'C 按四类 token 费率折算为该轮平均未缓存输入 token 等价，与 V 使用同一单位。'
         'p_k·V < C 时不再启动这一轮，相等时继续。'
         f'本次计算做完前 {completed} 轮就停。表中 C/p_k 给出各轮价值临界值。'
         '取新的 V 后从第一轮重新比较，首个严格小于成本的轮次就是停止轮次。'
         if zh else 'Each denominator counts reviews of comparable manuscripts; each numerator counts '
         'reviews with at least one adopted substantive comment. Use the item decisions in '
         '[review.md](../review.md), rather than the adopted column. Read review_round and substantive '
         'from ledger.csv. Price all four token categories to obtain mean review cost C in '
         'uncached-input token equivalents, the same unit as V. Skip the round when p_k·V < C; '
         f'continue at equality. In this calculation, complete {completed} rounds before stopping. '
         'The C/p_k column gives value thresholds. For a new V, compare from round 1 and stop '
         'at the first strict inequality.'), '',
        '## 并行何时划算' if zh else '## When parallel work pays off', '',
        (f"四个 Sub-agent 使耗时减少 **{-parallel['time_change']:.2f}%**，总 token 增加 {parallel['token_change']:.2f}%。"
         if zh else f"Four Sub-agents reduce elapsed time by **{-parallel['time_change']:.2f}%** and increase total tokens by {parallel['token_change']:.2f}%."), '',
        ('| 方式 | 对话数 | 耗时分钟 | 总 token | 估算费用美元 |'
         if zh else '| Mode | Conversations | Minutes | Total tokens | Estimated USD cost |'),
        '|---|---:|---:|---:|---:|',
        f"| {'串行' if zh else 'Serial'} | 1 | {parallel['t']:g} | {parallel['tokens']:,} | {parallel['s']:.4f} |",
        f"| {'四个 Sub-agent 加主对话' if zh else 'Four Sub-agents plus coordinator'} | 5 | {parallel['tp']:g} | {parallel['tokens_p']:,} | {parallel['sp']:.4f} |", '',
        (f"两次读相同的 14 篇论文，均采用笔记，费用增加 {parallel['cost_change']:.2f}%。"
         f"T 与 T′ 换成小时后，节省 {parallel['hours_saved']:.2f} 小时，额外费用 {parallel['extra_cost']:.4f} 美元。"
         f"因此 w > {parallel['threshold']:.4f} 美元每小时时并行划算。当前 w = {args.w:g}，"
         f"时间价值 {parallel['time_value']:.2f} 美元，"
         f"{'满足' if parallel['worthwhile'] else '不满足'}严格大于额外费用的条件。"
         '人民币时间价值先换成美元再比较。'
         if zh else f"Both runs read the same 14 papers and produce adopted notes. Cost increases by {parallel['cost_change']:.2f}%. "
         f"Converting T and T′ to hours gives {parallel['hours_saved']:.2f} hours saved for an extra USD {parallel['extra_cost']:.4f}. "
         f"Parallel work pays off when w > USD {parallel['threshold']:.4f} per hour. At w = {args.w:g}, "
         f"the time value is USD {parallel['time_value']:.2f} and the strict comparison "
         f"{'passes' if parallel['worthwhile'] else 'fails'}. Convert a time value in another currency to USD first."), '',
        ('复算命令，在本材料目录运行：' if zh else 'Reproduce from this material directory:'), '',
        '```bash',
        f'python3 calc.py --lang {args.lang} --v {args.v:g} --w {args.w:g} --h {args.h:g} --r {args.r:g}'
        + (f' --c {args.c:g}' if args.c is not None else '')
        + f' --segment-turns {args.segment_turns} --output preview/decisions.md',
        '```', '',
    ]
    return '\n'.join(lines)


def main():
    base = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--v', '--V', type=positive, default=500000,
                        help='value of a substantive issue in token equivalents')
    parser.add_argument('--w', type=nonnegative, default=10,
                        help='value of time in USD per hour')
    parser.add_argument('--h', type=positive, default=2000,
                        help='raw handoff length; rereads use the cache-read price')
    parser.add_argument('--r', type=positive, default=80000,
                        help='one-time segment cost in uncached-input token equivalents')
    parser.add_argument('--c', type=positive,
                        help='override raw input growth per turn; default least-squares fit')
    parser.add_argument('--segment-turns', type=positive_integer, default=20)
    parser.add_argument('--lang', choices=['zh', 'en'],
                        default='en' if base.name == 'en' else 'zh')
    parser.add_argument('--output', type=Path, help='Markdown output path; default stdout')
    args = parser.parse_args()
    ledger = read_csv(base / 'ledger.csv')
    conversations = conversation_decisions(read_csv(base / 'conversations.csv'), ledger,
                                           args.h, args.r, args.segment_turns, args.c)
    reviews = review_decisions(ledger, args.v)
    parallel = parallel_decision(ledger, args.w)
    report = render(conversations, reviews, parallel, args)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(report, encoding='utf-8')
    else:
        print(report, end='')


if __name__ == '__main__':
    main()
