#!/usr/bin/env python3
"""Recompute the finite-candidate bound and a two-state nonconvergence example."""
import json
import math

if __name__ == '__main__':
    candidates, delta, epsilon = 8, .05, .1
    required = math.ceil(math.log(2 * candidates / delta) / (2 * epsilon ** 2))
    trace = [0]
    for _ in range(10):
        trace.append(1 - trace[-1])
    print(json.dumps({'assumptions': 'fixed candidates, independent bounded task rewards',
                      'candidates': candidates, 'delta': delta, 'epsilon': epsilon,
                      'tasks_per_candidate': required,
                      'epsilon_with_six_tasks': math.sqrt(math.log(2*candidates/delta)/12),
                      'two_state_trace': trace}, indent=2))
