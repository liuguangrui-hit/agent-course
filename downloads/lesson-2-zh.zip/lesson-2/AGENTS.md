# 项目约定
- 论文元数据先查 arXiv 与 OpenAlex 接口，订阅全文用 Ego 浏览器。
- vault/sources/ 原件只增不改，PDF 不随课程材料分发。
- 论文页写在 vault/papers/，与 PDF 同名；每条结论注明版本与 PDF 页码。
- 概念页写在 vault/concepts/，只引用论文页；分歧和问题分别写进 vault/conflicts.md、vault/questions.md。
