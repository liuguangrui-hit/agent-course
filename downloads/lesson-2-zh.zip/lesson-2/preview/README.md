# 成品示例

用 Obsidian 的打开本地库功能选择本目录下的 `vault/`，即可阅读六篇真实论文笔记及它们形成的概念、分歧和问题。

- [vault/papers/](vault/papers/)：Arpit、Zhang、Han、Wang、Liu、Ma 六篇论文的阅读笔记。
- [vault/concepts/](vault/concepts/)：记忆化、早停、鲁棒损失三个概念页，使用 Obsidian 双链。
- [vault/conflicts.md](vault/conflicts.md)：结果排序反转与样本处理方法的分歧。
- [vault/questions.md](vault/questions.md)：题目、摘要、预测、推翻条件、最小改法与来源笔记。
- [vault/templates/paper.md](vault/templates/paper.md)：论文页模板。
- [vault/sources/manifest.csv](vault/sources/manifest.csv)：六份 PDF 的元数据、核对页数、版本和 SHA-256。只含元数据。
- [baseline.csv](baseline.csv)：第 1 课结果的均值，来自同语言材料的 data/results.csv。
- [timing.csv](timing.csv)：最小改法的计时记录，每种条件运行种子 0 和 80 轮。

页码从下载 PDF 的首页算第 1 页，包括正文后参考文献和附录。实际 PDF 页数依次为 Arpit 10、Zhang 14、Han 13、Wang 11、Liu 26、Ma 13。每份均检查了页数和前两页题目，并阅读正文的设定与结果，表格页经过渲染核对。PDF 只在制作者的临时目录阅读，source 字段保留未来下载时的文件名。

论文里的 ± 是作者报告的标准差。Zhang、Han、Wang 和 Liu 对应表格为 5 次运行或噪声实现，Ma 为 3 次。Liu 表 1 中部分基线摘自 Zhang，笔记已注明。

四成噪声下，已有小实验的 CE 最终均值为 67.39%，GCE 为 96.00%，small_loss 为 90.44%。均值用原 CSV 的 5 个种子计算。单种子最小改法在本次执行环境实跑：验证指标版 3.552 秒，q = 0.7 和 1.0 分别为 1.791 和 1.345 秒，筛选日程 10 和 2 分别为 1.635 和 1.793 秒。所有曲线包含 80 行有限数值。这些计时用来核对练习预算，问题摘要中的预测尚待学员检验。
