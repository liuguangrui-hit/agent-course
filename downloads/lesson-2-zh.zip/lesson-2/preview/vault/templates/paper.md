---
title: A Closer Look at Memorization in Deep Networks
authors: Arpit et al.
year: 2017
source: sources/arpit2017.pdf
---
## 问题
## 设定
## 主要结果
- 结论一句话，数字。PDF p. 页码。
## 和本课题的关系
