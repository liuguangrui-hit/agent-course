---
title: 'Generalized Cross Entropy Loss for Training Deep Neural Networks with Noisy Labels'
authors: Zhilu Zhang et al.
year: 2018
source: sources/zhang2018.pdf
arxiv_version: 1805.07836v4
source_url: https://arxiv.org/abs/1805.07836v4
---

## 问题

能否只改损失，就兼顾交叉熵的可优化性和 MAE 的抗噪性质。PDF p. 1、p. 4。

## 设定

CIFAR-10 和 CIFAR-100 用 ResNet-34。留出训练数据的 10% 作验证集，训练和验证标签都加噪声，测试标签保持干净；重复 5 次。PDF p. 6 至 8。

## 主要结果

- GCE 为 Lq = [1 - p_y^q] / q。q 趋近 0 时得到交叉熵，q = 1 时得到与 MAE 成比例的损失。PDF p. 4，公式 6。
- 在干净 CIFAR-100 的优化诊断中，MAE 训练 2000 轮的最高测试准确率为 38.29%，CCE 仅第 7 轮就达到 39.92%。PDF p. 4，图 1 及正文。
- CIFAR-10 四成均匀噪声下，按带噪验证集准确率选轮次，CCE 为 81.88 ± 0.29%，GCE 为 87.13 ± 0.22%，截断 GCE 为 87.62 ± 0.26%。PDF p. 8，表 1。
- CIFAR-10 四成开集噪声下，最后一轮 MAE 为 75.06%，普通 GCE 为 71.10%，截断 GCE 为 79.55%。PDF p. 8，表 2。

## 和本课题的关系

[[robust-losses|鲁棒损失]] 页据此区分理论抗噪和有限轮次优化；[[early-stopping|早停]] 页记录作者已经使用带噪验证集的事实。依据为 PDF p. 4、p. 6 至 8。
