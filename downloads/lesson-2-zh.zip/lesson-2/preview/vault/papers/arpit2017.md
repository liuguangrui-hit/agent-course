---
title: 'A Closer Look at Memorization in Deep Networks'
authors: Devansh Arpit et al.
year: 2017
source: sources/arpit2017.pdf
arxiv_version: 1706.05394v2
source_url: https://arxiv.org/abs/1706.05394v2
---

## 问题

网络能拟合随机标签，真实数据上的学习是否也只是逐条记忆。PDF p. 1 至 2。

## 设定

MNIST 上用两层 ReLU MLP，默认每层 4096 个单元；CIFAR-10 上用 CNN。分别替换输入和标签，观察训练、验证准确率和决策边界复杂度。PDF p. 2。

## 主要结果

- 在 20% 至 80% 的输入或标签噪声实验中，噪声越多，最终和最高验证准确率都越低。PDF p. 7，图 7、图 8。
- 随机标签实验中，验证准确率先达到最高，训练准确率随后继续升高；作者据此判断网络先学共有模式，再拟合噪声。PDF p. 7，图 7、图 8。
- 调整 dropout 可以降低随机标签上的训练表现，同时保留真实 CIFAR-10 上的验证表现。PDF p. 7，图 10。

## 和本课题的关系

本课据此把 [[memorization|记忆化]] 和 [[early-stopping|早停]] 连起来，并用每轮曲线寻找可停止的阶段。依据为 PDF p. 7。
