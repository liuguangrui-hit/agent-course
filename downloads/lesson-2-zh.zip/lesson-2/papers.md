# 十四篇论文清单

名单已于 2026-10-13 核对。十二篇预印本的题目、第一作者和年份来自 [arXiv 接口](https://export.arxiv.org/api/query?id_list=1706.05394,1805.07836,1804.06872,1712.05055,1908.06112,2002.07394,1609.03683,2007.00151,1911.00068,2103.14749,2006.13554,2007.08199&max_results=20)。年份取首次提交年，出版社论文取发表年。核对时 arXiv 返回的版本列在表中，示例页码固定到这些版本。

| 编号 | 题目 | 第一作者 | 年份 | arXiv 编号或 DOI | 来源类型 | 核对版本 |
|---|---|---|---|---|---|---|
| 1 | A Closer Look at Memorization in Deep Networks | Devansh Arpit | 2017 | [1706.05394](https://arxiv.org/abs/1706.05394v2) | arXiv | 1706.05394v2 |
| 2 | Generalized Cross Entropy Loss for Training Deep Neural Networks with Noisy Labels | Zhilu Zhang | 2018 | [1805.07836](https://arxiv.org/abs/1805.07836v4) | arXiv | 1805.07836v4 |
| 3 | Co-teaching: Robust Training of Deep Neural Networks with Extremely Noisy Labels | Bo Han | 2018 | [1804.06872](https://arxiv.org/abs/1804.06872v3) | arXiv | 1804.06872v3 |
| 4 | MentorNet: Learning Data-Driven Curriculum for Very Deep Neural Networks on Corrupted Labels | Lu Jiang | 2017 | [1712.05055](https://arxiv.org/abs/1712.05055v2) | arXiv | 1712.05055v2 |
| 5 | Symmetric Cross Entropy for Robust Learning with Noisy Labels | Yisen Wang | 2019 | [1908.06112](https://arxiv.org/abs/1908.06112v1) | arXiv | 1908.06112v1 |
| 6 | DivideMix: Learning with Noisy Labels as Semi-supervised Learning | Junnan Li | 2020 | [2002.07394](https://arxiv.org/abs/2002.07394v1) | arXiv | 2002.07394v1 |
| 7 | Making Deep Neural Networks Robust to Label Noise: a Loss Correction Approach | Giorgio Patrini | 2016 | [1609.03683](https://arxiv.org/abs/1609.03683v2) | arXiv | 1609.03683v2 |
| 8 | Early-Learning Regularization Prevents Memorization of Noisy Labels | Sheng Liu | 2020 | [2007.00151](https://arxiv.org/abs/2007.00151v2) | arXiv | 2007.00151v2 |
| 9 | Confident Learning: Estimating Uncertainty in Dataset Labels | Curtis G. Northcutt | 2019 | [1911.00068](https://arxiv.org/abs/1911.00068v6) | arXiv | 1911.00068v6 |
| 10 | Pervasive Label Errors in Test Sets Destabilize Machine Learning Benchmarks | Curtis G. Northcutt | 2021 | [2103.14749](https://arxiv.org/abs/2103.14749v4) | arXiv | 2103.14749v4 |
| 11 | Normalized Loss Functions for Deep Learning with Noisy Labels | Xingjun Ma | 2020 | [2006.13554](https://arxiv.org/abs/2006.13554v1) | arXiv | 2006.13554v1 |
| 12 | Learning from Noisy Labels with Deep Neural Networks: A Survey | Hwanjun Song | 2020 | [2007.08199](https://arxiv.org/abs/2007.08199v7) | arXiv | 2007.08199v7 |
| 13 | Classification in the Presence of Label Noise: A Survey | Benoît Frénay | 2014 | [10.1109/TNNLS.2013.2292894](https://doi.org/10.1109/TNNLS.2013.2292894) | 出版社 | IEEE TNNLS |
| 14 | Learning from noisy examples | Dana Angluin | 1988 | [10.1007/BF00116829](https://doi.org/10.1007/BF00116829) | 出版社 | Machine Learning |

出版社两条同时核对了 DOI 返回的元数据和 OpenAlex：[Frénay 2014](https://api.openalex.org/works/https://doi.org/10.1109/TNNLS.2013.2292894)、[Angluin 1988](https://api.openalex.org/works/https://doi.org/10.1007/BF00116829)。题目只有大小写差别，作者与年份一致。Frénay 保留姓名原拼写，DOI 返回的拼写为 Benoit Frenay。

首次提交年与常见正式发表年不同的条目包括 MentorNet 的 2017 和 Patrini 的 2016。Confident Learning 首次提交于 2019-10-31，ELR 首次提交于 2020-06-30，年份按接口记录填写。

来源类型表示清单使用的入口。Angluin 的出版社 PDF 在核对时可直接取得，共 28 页；[出版社全文入口](https://link.springer.com/content/pdf/10.1007%2FBF00116829.pdf)与 OpenAlex 开放全文链接一致。Frénay 的 OpenAlex 记录标为 closed，全文任务可按 DOI 进入出版社。

[示例库说明](preview/README.md)列出已阅读的六篇和页码规则。练习时把自己下载的 PDF 存入 `vault/sources/`，论文页存入 `vault/papers/`。
