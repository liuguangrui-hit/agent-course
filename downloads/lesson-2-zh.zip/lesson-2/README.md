# 第 2 课练习材料：知识库

## 本练习训练的方法

本练习以带噪标签下鲁棒损失的文献为材料，训练以下方法：核验文献及其版本身份；区分原文观察、跨文献归纳与研究假设；按实验条件判断表面冲突的来源；把分歧转化为带竞争解释和判别预测的研究问题；通过抽查原文评价分工阅读与合并的质量。

## 课程的三个阶段

- 课前准备：安装浏览器与 Obsidian，完成登录，取得编号 2、5 和 11 的全文。
- 课堂教学：核验原件身份，分工阅读三篇论文，从条件差异提出竞争解释。
- 课后复习与扩展：先重画证据链，再判断两份分歧记录，最后补充版本对照或反例更新。

课前检查记录写入 preflight.md，课后复习记录写入 review-after-class.md。课堂各段时间、正反例和能力达成评价见本课课程页。安装和下载在课前完成，课堂直接使用本地材料。

材料包括已核对身份的十四篇论文清单、空知识库，以及可用 Obsidian 打开的六篇阅读示例，供下载全文、撰写笔记和提出研究问题的练习使用。

- [papers.md](papers.md)：十四篇论文的元数据与入口，以及核对版本。
- [vault/](vault/)：学员知识库。sources/ 放下载原件和下载后生成的 manifest.csv；papers/ 放论文页；concepts/ 放概念页；三个目录用 .gitkeep 保留。
- [vault/templates/paper.md](vault/templates/paper.md)：与课后深入页相同的论文页模板。
- [preview/README.md](preview/README.md)：成品示例的打开方式、页码规则和数字来源。
- [preview/vault/](preview/vault/)：已读六篇的论文页、三个概念页、分歧表和三个可检验问题。
- [preview/baseline.csv](preview/baseline.csv)：第 1 课已有实验结果的均值。
- [preview/timing.csv](preview/timing.csv)：三个问题最小改法的单种子实跑耗时。
- [AGENTS.md](AGENTS.md) 与 [CLAUDE.md](CLAUDE.md)：项目约定和共同入口。

先用 Obsidian 打开 `preview/vault/` 查看成品，再把 `vault/` 设为练习库。示例里的 source 字段是学员下载时使用的相对文件名，实际版本和核对页数记录在 manifest.csv。材料不含 PDF。

任务卡的路径从本课材料根目录解释。第 1 课材料放在相邻的 `lesson-1/`。练习 1 生成 `vault/sources/manifest.csv`；练习 2 生成论文页、概念页和 `vault/conflicts.md`；练习 3 生成 `vault/questions.md`，随后查新生成 `vault/novelty.md`。课后练习按需生成 `papers.csv`、`notes/publishers.md`、`criteria.md` 和 `screening/`。

本练习须配合课程页面完成复习、独立实践与迁移评价。指定必读片段须完成，其余深入专题按研究需要选做。

分歧归因须列明已排除与未排除的解释、现有证据及所需判别对照；证据不足时记录为尚不可确定。
