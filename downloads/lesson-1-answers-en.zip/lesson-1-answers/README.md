# Session 1 answers

One way to finish the Session 1 exercises. Look only after trying them yourself.

- paper/: the retold paper. Numbers and the table come from `numbers.tex` and `table_main.tex`, generated from the data.
- code/check_numbers.py: lists numbers in a .tex file that the data does not support. On the original draft it finds the two planted errors.
- code/make_numbers.py: writes `paper/numbers.tex` and `paper/table_main.tex` from `data/`.
- code/plot_paper.py: the two figures at one-column width.
- skills/paper-retell/: an example Skill. Copy the folder to `.claude/skills/` for Claude Code or `.agents/skills/` for Codex.
- AGENTS.md: example project conventions after the session.

Run from this folder: `python code/make_numbers.py`, `python code/plot_paper.py`, then compile `paper/main.tex`.
