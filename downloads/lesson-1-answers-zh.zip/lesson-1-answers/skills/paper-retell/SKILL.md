---
name: paper-retell
description: Retell an academic paper from title to conclusion around its single most striking result, redraw its data figures at final size, and check every number against the data. Use when asked to revise, rewrite, polish or de-AI a paper draft.
---

# Retell a paper

Inputs: the draft (`.tex`), the result files it reports, and one exemplar paper from the target venue in `exemplar/`.

1. Read the exemplar's title, abstract and first introduction paragraph. Note how it hooks the reader.
2. Read the whole draft and the data. Name the single most striking result, with its number.
3. Propose three titles of at most ten words, each a claim. Stop and let the user choose.
4. Write an abstract of at most 150 words. First sentence: the striking result. One number per finding. No limitations.
5. Set the draft aside and write the paper afresh in a new version folder. Introduction opens with the striking example. Results follow the questions a reader would ask, each paragraph opening with its conclusion. Limitations: one paragraph, in the discussion. Never patch the old text, and never add caveats on your own.
6. Figures: decide the one conclusion each figure shows, then draw it from the data at final column width, 7 to 9 pt text, vector PDF, one color-blind-safe color per method across figures, mean with a band over seeds, direct labels, no plot title. The conclusion becomes the caption's first sentence.
7. Compile. Render every page as an image and look at it: overlapping text, text out of bounds, text too small. Fix and recompile.
8. Run `python check_numbers.py <file.tex>` (in this skill's folder) and fix every mismatch.
9. If review comments exist, read every past round, not only the latest, before retelling.

Check the result against [style_table.md](style_table.md).
