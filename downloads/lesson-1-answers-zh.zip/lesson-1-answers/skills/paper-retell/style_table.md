# Style table for papers

## Text

| Problem | Example | Fix |
|---|---|---|
| Title describes instead of claims | Towards an Empirical Understanding of ... : A Preliminary Study | A short title that states the finding and sticks in memory |
| Abstract opens with background | In recent years, deep neural networks have achieved remarkable success | First sentence is the most striking result |
| Hedges everywhere | may, to some extent, preliminary, appears to | State the claim; give the evidence boundary once, in one place |
| Walking a claim back | a finding, followed at once by "It should be noted that ..." | Make the claim; limits go in one Discussion paragraph |
| The same caveat in abstract, introduction, results and conclusion | "limited to a synthetic setting" four times | Say it once |
| Contribution list repeating the abstract | We systematically compare ... We find ... We observe ... | Introduction ends with the questions the paper answers, in the order the reader would ask them |
| Sections named after experiments | RQ1, RQ2, RQ3 | Order results by the reader's questions; open each with a conclusion sentence |
| Paragraph leads that only name a topic | Memorization. Robust losses. | Lead with the paragraph's conclusion |
| Stock phrases | Notably, It is worth noting, In conclusion, We hope this work | Cut them |
| Numbers that differ between places | 96.2% in the abstract, 96.0 in the table | Every number traces to the data file, same wording everywhere |

## Figures

| Problem | Fix |
|---|---|
| Drawn large, then shrunk into the column, text becomes 4 pt | Draw at the final width (one column ≈ 3.25 in), text 7 to 9 pt |
| Raster PNG at screen resolution | Vector PDF |
| Title inside the plot | The caption carries the message; no plot title |
| Raw variable names as labels | Readable axis labels with units: Test accuracy (%) |
| A legend covering the data, or twenty spaghetti lines | Mean line with a band over seeds; label lines directly |
| The same method in different colors across figures | One fixed color per method in every figure |
| Default color cycle | A color-blind-safe palette |
| Dashed grid, heavy frame | Light horizontal grid only, drop top and right spines |
| Caption that names the plot | Caption states what the reader should see |
