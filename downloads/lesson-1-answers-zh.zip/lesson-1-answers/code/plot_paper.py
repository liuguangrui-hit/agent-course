"""Publication figures: column width, 8 pt text, one color per method, mean and spread over seeds."""
import csv
import pathlib
import collections
import statistics as st
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

BASE = pathlib.Path(__file__).resolve().parent.parent

COLORS = {"ce": "#2a78d6", "label_smoothing": "#eb6834", "gce": "#1baf7a", "small_loss": "#eda100"}
NAMES = {"ce": "Cross-entropy", "label_smoothing": "Label smoothing", "gce": "GCE", "small_loss": "Small-loss"}
INK, MUTED = "#222222", "#6b6b6b"
plt.rcParams.update({
    "font.family": "serif", "font.size": 8, "axes.labelsize": 8, "xtick.labelsize": 7, "ytick.labelsize": 7,
    "axes.edgecolor": MUTED, "axes.labelcolor": INK, "xtick.color": MUTED, "ytick.color": MUTED,
    "axes.spines.top": False, "axes.spines.right": False, "pdf.fonttype": 42, "lines.linewidth": 1.4,
})
W = 3.25  # one column of a two-column paper, inches

rows = list(csv.DictReader(open(BASE / "data/results.csv")))
acc = collections.defaultdict(list)
for r in rows:
    acc[(r["method"], float(r["noise"]))].append(100 * float(r["final_acc"]))
noise = [0.0, 0.2, 0.4, 0.6]

fig, ax = plt.subplots(figsize=(W, 2.2))
label_y = {}
for m in COLORS:
    mu = [st.mean(acc[(m, n)]) for n in noise]
    sd = [st.stdev(acc[(m, n)]) for n in noise]
    x = [100 * n for n in noise]
    ax.fill_between(x, [a - b for a, b in zip(mu, sd)], [a + b for a, b in zip(mu, sd)], color=COLORS[m], alpha=0.15, lw=0)
    ax.plot(x, mu, color=COLORS[m], marker="o", ms=3.5, mec="white", mew=0.6)
    label_y[m] = mu[-1]
# direct labels at the right end, nudged apart where lines end close together
nudge = {"ce": -2.2, "label_smoothing": 2.2, "gce": 1.5, "small_loss": -1.5}
for m, y in label_y.items():
    ax.annotate(NAMES[m], (60, y), xytext=(63, y + nudge[m]), color=INK, fontsize=7, va="center")
ax.set_xlim(-2, 82)
ax.set_xticks([0, 20, 40, 60])
ax.set_xticklabels(["0", "20", "40", "60"])
ax.spines["bottom"].set_bounds(0, 60)
ax.set_xlabel("Training labels flipped (%)")
ax.set_ylabel("Test accuracy (%)")
ax.set_ylim(40, 101)
ax.grid(axis="y", color="#e6e6e6", lw=0.6)
fig.tight_layout(pad=0.3)
fig.savefig(BASE / "paper/figures/fig_noise.pdf")

curves = list(csv.DictReader(open(BASE / "data/curves.csv")))
by = collections.defaultdict(list)
for r in curves:
    if float(r["noise"]) == 0.4:
        by[(r["method"], int(r["epoch"]))].append(100 * float(r["test_acc"]))
epochs = sorted({e for _, e in by})
fig, ax = plt.subplots(figsize=(W, 2.0))
end = {}
for m in COLORS:
    mu = [st.mean(by[(m, e)]) for e in epochs]
    sd = [st.stdev(by[(m, e)]) for e in epochs]
    ax.fill_between(epochs, [a - b for a, b in zip(mu, sd)], [a + b for a, b in zip(mu, sd)], color=COLORS[m], alpha=0.15, lw=0)
    ax.plot(epochs, mu, color=COLORS[m], lw=1.2)
    end[m] = mu[-1]
for m, text in (("gce", "GCE"), ("small_loss", "Small-loss"), ("ce", "Cross-entropy,\nlabel smoothing")):
    ax.annotate(text, (epochs[-1], end[m]), xytext=(4, 0), textcoords="offset points", color=INK, fontsize=7, va="center")
ce = [st.mean(by[("ce", e)]) for e in epochs]
peak = max(range(len(ce)), key=lambda i: ce[i])
ax.annotate(f"Cross-entropy peaks at {ce[peak]:.0f}%\nin epoch {epochs[peak]}, then\nmemorizes the wrong labels", (epochs[peak], ce[peak]),
            xytext=(5, 72), textcoords="data", fontsize=7, color=INK, va="top",
            arrowprops=dict(arrowstyle="-", color=MUTED, lw=0.6, relpos=(0.0, 1.0), shrinkA=0, shrinkB=2))
ax.set_xlim(0, 112)
ax.set_xticks([0, 20, 40, 60, 80])
ax.spines["bottom"].set_bounds(0, 80)
ax.set_xlabel("Epoch")
ax.set_ylabel("Test accuracy (%)")
ax.set_ylim(55, 101)
ax.grid(axis="y", color="#e6e6e6", lw=0.6)
fig.tight_layout(pad=0.3)
fig.savefig(BASE / "paper/figures/fig_curves.pdf")
