"""List every percentage or point difference in a .tex file that the data does not support.

Candidates are computed from data/results.csv and data/curves.csv: mean and
standard deviation of final accuracy per method and noise rate, gaps between
methods, peaks of the mean curves and the drop after them, and the noise rates.
Keep the set small: the more candidates, the easier a wrong number matches one
by chance. A number in the text passes if it
matches a candidate at the precision it is written with.

    python code/check_numbers.py paper/main.tex   (from the project folder)
"""
import collections
import csv
import pathlib
import re
import statistics as st
import sys

BASE = pathlib.Path.cwd()  # run from the project folder that holds data/


def candidates():
    rows = list(csv.DictReader(open(BASE / "data/results.csv")))
    final = collections.defaultdict(list)
    for r in rows:
        k = (r["method"], float(r["noise"]))
        final[k].append(100 * float(r["final_acc"]))
    vals = {100 * n for _, n in final}
    means = {k: st.mean(v) for k, v in final.items()}
    vals |= set(means.values())
    vals |= {st.stdev(v) for v in final.values()}
    for (m1, n1), a in means.items():
        for (m2, n2), b in means.items():
            if n1 == n2 and m1 != m2:
                vals.add(abs(a - b))
                vals.add(abs(round(a, 1) - round(b, 1)))  # gaps written from rounded table values
    curves = collections.defaultdict(list)
    for r in csv.DictReader(open(BASE / "data/curves.csv")):
        curves[(r["method"], float(r["noise"]), int(r["epoch"]))].append(100 * float(r["test_acc"]))
    by = collections.defaultdict(dict)
    for (m, n, e), v in curves.items():
        by[(m, n)][e] = st.mean(v)
    for c in by.values():
        peak = max(c.values())
        vals |= {peak, peak - c[max(c)]}
    return vals


def matches(text, vals):
    decimals = len(text.split(".")[1]) if "." in text else 0
    x = float(text)
    return any(round(v, decimals) == x for v in vals)


PATTERN = re.compile(r"(\d+(?:\.\d+)?)\s*(\\%|%|\s*percentage points|\s*points|\s*pp\b)")


def main(path):
    vals = candidates()
    bad = 0
    for i, line in enumerate(open(path, encoding="utf-8"), 1):
        if line.lstrip().startswith("%"):
            continue
        for m in PATTERN.finditer(line):
            if not matches(m.group(1), vals):
                bad += 1
                print(f"line {i}: {m.group(0).strip()} not found in the data  | {line.strip()[:90]}")
    print(f"{bad} unsupported number(s)" if bad else "all numbers match the data")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
