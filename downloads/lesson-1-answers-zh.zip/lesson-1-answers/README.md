# 第 1 课参考答案：写作绘图

第 1 课练习的一种完成方式。先自己做，再来对照。

- paper/：重讲后的论文。正文里的数字和表格来自 `numbers.tex` 与 `table_main.tex`，由数据生成。
- code/check_numbers.py：列出 .tex 文件里数据不支持的数字。在原始初稿上它会找出那两处埋好的错误。
- code/make_numbers.py：从 `data/` 生成 `paper/numbers.tex` 和 `paper/table_main.tex`。
- code/plot_paper.py：按单栏宽度画的两张图。
- skills/paper-retell/：一个 Skill 示例。复制到 `.claude/skills/` 给 Claude Code 用，或复制到 `.agents/skills/` 给 Codex 用。
- AGENTS.md：课后的项目约定示例。

在本文件夹运行 `python code/make_numbers.py` 与 `python code/plot_paper.py`，再编译 `paper/main.tex`。
