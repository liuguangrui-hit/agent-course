# Project conventions

- paper/main.tex is the original draft; never edit it. Each new version goes in its own folder: versions/v1/, versions/v2/.
- Every number in the paper comes from data/ through code/make_numbers.py. Never type a result by hand.
- Figures are drawn by code/plot_paper.py from data/. Never edit figure files by hand.
- Write for the reader: lead with the result, state each limitation once, no hedging.
- Reviews name the version they read on their first line. Keep every round in versions/<v>/review.md.
