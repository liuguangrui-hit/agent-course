# Playbook archive

Entries moved from [playbook.md](playbook.md) retain all four fields and their sources. No archived entries yet.
