# Daily reflection check

Start an independent new conversation at 08:00 each day. First read STATE.md only. If completed rounds minus the last reflection's covered round is less than three, exit without writing a check report. Completed means wrap-up finished; failed reviews also count as completed rounds.

After at least three more completed rounds, read STATE.md, playbook.md, and every round's prediction.md, result.md, results/, and review.md. Verify question sources in the round records. If launch or wrap-up is writing files, wait for a stable handoff before checking. Record the completed rounds covered by this reflection and exclude newly running rounds.

Answer three questions with specific rounds and files as evidence.

1. Is prediction hit rate improving or worsening? Recompute cumulative and recent-round values using the fixed denominators in LOOP.md, and check review pass rate as well.
2. Are recent questions getting smaller or more alike? Identify repeated questions, reduced settings, missing controls, or good results awaiting verification.
3. Does any playbook entry hide a problem? Check for widened predictions after results, skipped failures, self-review counted as independent passage, or untested practices treated as effective.

Write `reflections/date.md` with coverage, the three answers, evidence, and a continue or stop decision. Then update only the reflection coverage, date, report path, and decision fields in STATE.md. Leave experiments and the playbook unchanged. Experiment files are read-only inputs; this task outputs a reflection report, related state fields, and STOP when needed.

If the direction is wrong, write STOP with the reason, evidence, and what the learner must address. Send one stop notification through ntfy with the result-page URL. Record the round at which STOP was created. Active workers check STOP before the next step, save state, and stop their monitor. Reflection does not change evaluation criteria or delete STOP; it waits for the learner.
