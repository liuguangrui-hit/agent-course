# Daily reflection check

Start an independent new conversation on the confirmed timetable. First read only STATE.md; if the total of completed rounds minus the round covered by the last reflection is less than three, exit straight away without writing a check report. A completed round is one whose wrap-up has finished; a round that failed review also counts as completed.

Once three rounds are reached, read STATE.md, playbook.md, and every round's prediction.md, result.md, results/ and review.md. Check where questions came from in each round's records too. If launch or wrap-up is writing files, wait until the handover is stable before checking, record which completed rounds this check covers, and do not count newly added rounds still running.

Answer three questions, citing specific rounds and files as evidence.

1. Is the prediction hit rate getting better or worse? Compute the cumulative value and the most recent rounds with the fixed denominators in LOOP.md, and check the review pass rate as well.
2. Are recent questions getting smaller and more alike? Point out rounds with repeated questions, narrowed settings, missing controls, or good results not yet rechecked.
3. Is any playbook entry covering up a problem? Check whether predictions were loosened afterwards, failures skipped, self-review counted as independent passage, or untested practices treated as effective.

Write to `reflections/<date>.md`, recording the scope covered, the three answers, the evidence and the decision to continue or stop. Then update only the reflection-coverage round, date, report path and decision in STATE.md, without changing experiments or the playbook. Experiment files are read-only input; this task's output is the reflection report, the corresponding state fields and a STOP when necessary.

End your comments with a claim check: list the items that suggest narrowing a title or core claim; where evidence is missing, first give a way to add evidence at the original scale; where counterevidence exists or the claim cannot be tested, state the grounds that make a rewrite necessary.

If the direction is wrong, write STOP, stating the reason, the evidence and what the student needs to handle. Notify only through authorized channels; without that authorization, keep the notification text locally. Save the record that STOP has reached the current round; a conversation that is executing checks STOP before its next step, writes back the state and stops the monitor. Reflection does not change the evaluation criteria and does not delete STOP; it waits for the student to handle it.
