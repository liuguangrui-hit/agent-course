# Question-list entry point

The question list for this lesson is `../lesson-2/vault/questions.md`. Launch selects an unattempted question there, and wrap-up adds a question arising from a new disagreement. This file only identifies the location.

Place same-language Lesson 2, 3, and 4 materials in adjacent folders named lesson-2, lesson-3, and lesson-4. Complete the Lesson 2 vault and question list before starting the loop. Lesson 2 preview/vault/ is a completed reading example. To use it as a starting point, first copy it into your own vault/.
