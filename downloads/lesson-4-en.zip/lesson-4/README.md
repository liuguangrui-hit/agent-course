# Lesson 4 exercise materials: Research automation

## Stages of the session

- Preparation: gather the results of earlier sessions, prepare dependencies and the local preview, and complete one zero-delay read-only call. Do not create a long-term schedule.
- Class session: observe interruption recovery, configure one short-delay read-only review, resume from the recorded state in a new session, then design a test of a playbook entry.
- Review and extension: first draw the recovery path, then distinguish retries from negative scientific results, and finally add a small schedule or a three-group test.

Record your preparation checks in preflight.md and your review in review-after-class.md. The session page gives the timing of each activity and the examples for comparison. Complete installations and downloads before class so that the materials are ready for use.

Continuing from the Lesson 3 experiment repository, the exercises train the representation of a research round as recorded states, recovery that avoids duplicated effects, and the evaluation of playbook entries on unseen tasks. The activities are timed launch, wrap-up review, writing back to the knowledge base, the playbook and the results page.

| File or folder | Purpose |
|---|---|
| [LOOP.md](LOOP.md) | Launch and wrap-up of one round, lock handover and the fixed evaluation criteria |
| [STATE.md](STATE.md) | Initial state template, completed after every step |
| [playbook.md](playbook.md) | Empty playbook, explaining the four fields, merging and the limit |
| [playbook-archive.md](playbook-archive.md) | Archive for entries once the playbook exceeds its limit |
| [review_task.md](review_task.md) | Read-only review of how numbers, conclusions and commits correspond |
| [reflection_task.md](reflection_task.md) | Checks daily whether three more rounds are complete, then reflects independently |
| [ledger.csv](ledger.csv) | Empty usage table; launch and wrap-up each record one row of actual usage |
| [questions.md](questions.md) | A note pointing to vault/questions.md from Lesson 2 |
| [code/run_experiment.py](code/run_experiment.py) | The original Lesson 3 experiment code, kept as the starting version |
| [code/make_page.py](code/make_page.py) | Standard-library web page generator, producing a public and an internal version |
| [data/](data/) | The real Lesson 1 CSVs carried over from Lesson 3 |
| [pyproject.toml](pyproject.toml) | numpy experiment environment |
| [uv.lock](uv.lock) | Environment versions locked in Lesson 3 |
| [.gitignore](.gitignore) | Excludes environments, secrets, logs, run locks and generated pages |
| [preview/](preview/README.md) | Real finished products from round 1, with web page and notification examples |
| [AGENTS.md](AGENTS.md) | Stable project conventions |
| [CLAUDE.md](CLAUDE.md) | Refers to AGENTS.md |

## Examining the finished example

Open the [public summary](preview/site/index.html) in a browser, then the [public detail page](preview/site/round-1.html). The full numbers and figures are on the [internal detail page](preview/internal/round-1.html), and the source of the numbers and the review status are given in the [preview notes](preview/README.md). The notification is in [notification.txt](preview/notification.txt). The completed example contains only round 1.

## Starting the exercise

Place the materials for one language in neighboring folders named lesson-2, lesson-3 and lesson-4. Run this session's tasks from inside lesson-4, so that `../lesson-2/vault/` points to your own knowledge base. Begin after completing the Lesson 2 knowledge base and question list. The tool configuration installed in Lesson 3 is carried over.

Following the session page, first demonstrate interruption recovery, then use as the starting point either your complete results from earlier sessions or a preview with a clearly stated source. In class, one timed read-only review is configured jointly and work continues from STATE.md; after class, it is extended to a small number of scheduled runs according to the execution environment. Notification and publication use channels that are already authorized; in class, only the local page is examined.

The experiment environment reuses Python 3.9 to 3.12 and numpy 2.0.2.

```sh
uv sync --frozen
mkdir -p logs
```

`code/run_experiment.py` is identical to the Lesson 3 starting code: it writes to data/ and has only `--quick`, whose short run is twenty epochs. LOOP.md requires early stopping and parameters for seeds, epochs, output directory and commit. Students who completed Lesson 3 can bring their own code; the preview implementation and summary script can also be copied into code/ as a starting point.

A run creates `runs/<n>/`, logs/ and reflections/. Each round contains prediction.md, results/, result.md, review.md and the public text projection public.json. For the structure of public.json, see the [real preview](preview/runs/1/public.json). It stores no experiment numbers or scores; the generator takes the verdicts from result.md and the overall review decision from review.md.

## Generating the web page

Run in this exercise directory:

```sh
python3 code/make_page.py
```

This generates site/index.html, site/style.css and site/round-n.html for each round; internal/ has the same structure and keeps the original text and result files. Rounds with missing files, failed execution or content pending a check show their status separately and are excluded from the denominator of completed rounds. Each build-status.json records denominators and states. For a failed execution, phase can be set to failed with an error_code in that round's run.json. Before generating, check the display scope of public.json and the playbook round by round; checks on projection fields and numeric characters cannot determine whether content is suitable for publication.

Examine the page locally first. Once authorization has been obtained for a specific publication target and projection, deploy only the approved site/ content, and keep internal/ on the local machine. Check the remote deployment and open the version actually served. The generated directories are excluded from Git tracking in the experiment repository.

## Usage and recovery

ledger.csv starts with only a header. Tokens and costs are read from actual execution records; when they cannot be read, the fields are left empty and marked unavailable. STATE.md records the rounds and half-round keys already entered in the ledger, and these are checked against existing rows before work continues.

The lock is created at launch and released at the end of wrap-up. The monitor keeps updating the time of latest activity, and a new wrap-up conversation takes over the existing lock through owner and worker; details are in LOOP.md. An expired heartbeat requires a check of the holder and the actual process; the lock is not deleted directly. STOP and timed-out locks are handled by the student after checking.

## Interruption recovery demonstration

[recovery_demo.py](recovery_demo.py) demonstrates only recovery from a process failure after one local file action; it does not provide an exactly-once guarantee for external services. Use a demonstration directory you create yourself:

```bash
python3 recovery_demo.py --root demo-run --crash-after-action
python3 recovery_demo.py --root demo-run
python3 recovery_demo.py --root demo-run
```

The first command should exit with 17, with the product written but state.json not committed; the next two both show effect_count as 1. events.json keeps the recovery observations. The deliberate failure releases the example lock; when a process that was actually killed leaves an old lock behind, check the owner and take over manually. The script makes no guarantee of durability across power loss or of distributed lease safety.

Examine the web page locally first. The user chooses public fields individually, and questions and predictions may also be unpublished information; a random notification channel name is not access control. The historical preview is kept as it was, and new runs are recorded according to this round's LOOP.md.

## Single wake-up and read-only review

[wake_review.py](wake_review.py) reuses your existing Claude sign-in and starts one tool-free review through the official non-interactive interface, with input supplied by the script through stdin. It restricts tools and MCP, and saves the host, time zone, input hash, planned and actual times, process status and output. Its command options were checked against this round's CLI help and the [official CLI docs](https://code.claude.com/docs/en/cli-reference); the version used must support --restricted. If another official entry point is used instead, its equivalent permissions and output method are checked together in class.

The review instructions built into wake_review.py are in Chinese, and the script is the same in both language editions. It asks the reviewer to read only the one record supplied, check whether it states the input identity, execution status and next step, point out anything missing without inventing facts, and give its comments only in the final answer. The review it returns may therefore be in Chinese; translate it for the class when needed.

Before class, carry out one zero-delay functionality check, using a new output directory:

```bash
python3 wake_review.py --input preflight-input.md --out preflight-call --delay-seconds 0 --timeout-seconds 90
```

In class, switch the input to this round's result.md and set a five-second delay. The packaged preview can be used for rehearsal but must not be recorded as your own new experiment:

```bash
python3 wake_review.py --input preview/runs/1/result.md --out one-shot-review --delay-seconds 5 --timeout-seconds 90
```

The call is complete only when its status is completed and review.md is non-empty; run failure, empty output, launch failure and timeout are each recorded separately. Ctrl+C cancels the wait or stops this subprocess; check run.json and the actual process before handing over. Use a new directory each time and keep old records; after the program exits there is no periodic task. Configuring and stopping periodic scheduling continue in 4.1.

Complete the review, independent work and transfer assessment specified on the session page. Any identified core readings are required; remaining extension topics are optional.

Evaluation of playbook effects must report the target, matched-placebo and no-playbook results on unseen tasks, effect comparisons and uncertainty. Unfinished evaluations remain pending.
