# Lesson 4 practice materials

Continue the Lesson 3 experiment repository to practice scheduled launch, wrap-up review, vault writeback, a playbook, and result pages.

| File or folder | Purpose |
|---|---|
| [LOOP.md](LOOP.md) | Launch, wrap-up, lock handoff, and fixed evaluation criteria |
| [STATE.md](STATE.md) | Initial state template, updated after every step |
| [playbook.md](playbook.md) | Empty playbook with four fields, merging, and a size limit |
| [playbook-archive.md](playbook-archive.md) | Archive for entries exceeding the limit |
| [review_task.md](review_task.md) | Read-only checks of numbers, conclusions, and commit provenance |
| [reflection_task.md](reflection_task.md) | Daily check for three more completed rounds before independent reflection |
| [ledger.csv](ledger.csv) | Empty usage table, one actual launch and wrap-up row per round |
| [questions.md](questions.md) | Pointer to Lesson 2 vault/questions.md |
| [code/run_experiment.py](code/run_experiment.py) | Original Lesson 3 starter experiment code |
| [code/make_page.py](code/make_page.py) | Standard-library generator for public and internal pages |
| [data/](data/) | Real Lesson 1 CSV files carried over from Lesson 3 |
| [pyproject.toml](pyproject.toml) | numpy experiment environment |
| [uv.lock](uv.lock) | Environment versions locked in Lesson 3 |
| [.gitignore](.gitignore) | Excludes environments, secrets, logs, runtime locks, and generated pages |
| [preview/](preview/README.md) | Real Round 1 artifacts, pages, and notification example |
| [AGENTS.md](AGENTS.md) | Stable project conventions |
| [CLAUDE.md](CLAUDE.md) | References AGENTS.md |

## View the completed example

Open the [public summary](preview/site/index.html) and [public detail](preview/site/round-1.html) in a browser. Full numbers and figures are in the [internal detail](preview/internal/round-1.html). See the [preview notes](preview/README.md) for sources and review status, and [notification.txt](preview/notification.txt) for the notice. Only Round 1 is included.

## Start the exercise

Place same-language lesson materials in adjacent folders named lesson-2, lesson-3, and lesson-4. Run this lesson's tasks from lesson-4 so `../lesson-2/vault/` points to your vault. Complete the Lesson 2 vault and question list first. Carry over your tool configuration from Lesson 3.

Follow the lesson to run one round manually, then schedule launch at 22:00, wrap-up at 07:00, and reflection at 08:00. Each uses a new conversation and records progress in STATE.md. The package supplies task files; configure scheduling, ntfy, and the lab-results repository in class.

The experiment environment retains Python 3.9 through 3.12 and numpy 2.0.2.

```sh
uv sync --frozen
mkdir -p logs
```

`code/run_experiment.py` is unchanged from the Lesson 3 starter. It writes into data/ and only offers `--quick`, which uses twenty epochs. Add early stopping, seed, epoch, output, and commit options under LOOP.md. Learners who completed Lesson 3 can bring their own implementation. The preview implementation and analysis scripts can also be copied into code/ as a starting point.

During execution, create `runs/<n>/`, logs/, and reflections/. Each round contains prediction.md, results/, result.md, review.md, and a public prose projection in public.json. See its structure in the [real preview](preview/runs/1/public.json). It stores no experiment numbers or scores. The generator reads verdicts from result.md and overall review status from review.md.

## Generate pages

Run from this practice folder:

```sh
python3 code/make_page.py
```

This creates site/index.html, site/style.css, and site/round-n.html for every round. internal/ has the same structure plus original documents and results. Rounds missing predictions, a result report, review, or result CSV do not enter completed-round counts. Before generating, check the public.json prose and playbook in each round. The script validates projection fields, prediction counts, and numerical characters. Wrap-up checks their meaning against the private originals.

Copy only site/ contents into the public lab-results repository, commit, push, and verify Pages deployment. Open internal/ locally. Generated folders are excluded from Git tracking in the experiment repository; the public repository receives site/ contents only.

## Usage and recovery

ledger.csv initially contains only a header. Read tokens and cost from actual execution records. Leave unavailable numbers blank and write unavailable. STATE.md records each round and half-round ledger key; check existing rows before resuming.

Launch creates the lock; wrap-up removes it at the end. The monitor renews its latest activity, and the six-hour timeout uses that time. A new wrap-up conversation uses owner and worker to take over the existing lock under LOOP.md. The learner checks and resolves STOP and stale locks.
