# One loop round

This round continues from [STATE.md](STATE.md), and each task has only one executing session. Products go in a separate `runs/<n>/`, and every action with side effects has a run ID and an effect that can be checked. In class, run it by hand and test recovery first, then configure the schedule.

## Fixed objective and evaluation

The prediction table is fixed as `Prediction | Reason | Falsification condition`, and the result table as `Prediction | Actual result | Verdict`. The verdict column says Correct or Wrong. The two tables list the predictions in the same order, and the main comparison and analysis method are frozen before execution.

Prediction hit rate, execution success rate and review pass rate are counted separately, each with its denominator stated. They are run metrics; a scientific conclusion also depends on whether the competing explanations were told apart. The playbook can suggest practices but cannot change how evaluation is measured. Updating the evaluation creates a new version, and the user decides on it.

## Lock and takeover

At launch, check STOP first. If it exists, read the reason and exit, keeping the original. Create `.lock` atomically, recording the owner, the run ID and a heartbeat in it. The session that writes files must also take `.lock/worker`.

When a lock already exists, check its holder and the actual task, and do not start a parallel round. An expired heartbeat only means it needs checking; it does not let you infer that the old session has stopped. Before a takeover, stop the old session's monitor and scheduled wake-ups, confirm it no longer writes, then record the takeover. The current file lock does not provide a distributed lease or fencing of expired holders.

When launch finishes, leave this round's lock and release worker. Wrap-up takes over the same round by owner and run ID, and releases it when done. Recovery judges only from records and actual products, never from the chat.

## Launch

1. Read the state and the candidate lessons that apply to this round, and check quota and the execution environment. If quota is insufficient, write a waiting state and keep any known recovery time; retries on error have a limit.
2. Choose one question from the Lesson 2 question list, record its source and two competing explanations, and assign the round and run ID.
3. Write the prediction, the main metric and the analysis plan, commit them and record their identity. Keep the original prediction.
4. Change the code and do a short run, checking the number of rows, finite values, the data split and the result fields. Once it passes, commit the execution code and record the data hash, configuration and environment.
5. Prepare the log and metadata for this round's execution directory. Query the launch request by run ID; if the status is unknown, check first, and retry only after confirming it did not start. On a server use the scheduler or tmux; locally use a background process that can be tracked.
6. Record the job identifier and how it is monitored. After the process exits, check the exit code and the completeness of products; only on success move to analysis, and on failure keep the phase and error_code in run.json.
7. Write the state immediately after every step. The ledger key for launch is this round's number plus launch, and an existing row is not appended again. Leave unknown usage missing. Release worker and hand over.

The starting run_experiment.py has only --quick. You can reuse your own Lesson 3 implementation, or read the preview code and add parameters for seeds, epochs, output and the real commit. The preview's placeholder commit must not be copied as the identity of a new run.

## Wrap-up

1. Get write permission for this round and check the executor. If it is still running, record waiting and exit; if it failed, first tell a code execution failure apart from a negative scientific result.
2. Pull back the necessary small products, keeping the location and checksum of large files. Pair the analysis by the seeds set in advance, and record failures and missing items in full.
3. Write result.md with the main comparison first, compare each original prediction item by item, and let the conclusion explain what changed for the competing explanations. State the execution and analysis identities.
4. Give the frozen materials to an independent session from the other vendor for a read-only review following [review_task.md](review_task.md). The comments state the input hashes and a verdict of pass or return for revision, and end with a claim check. Within the project, calls across agents all go through call_agent.
5. If the results change, review again, keeping the old comments. Once it passes, update the evidence and concepts in the knowledge base; if it does not pass, still save this round's results and the next piece of evidence to add.
6. Add at most one candidate lesson, writing its conditions, action and source. Record usage counts and results separately, leaving causal contribution to later controls. Capacity is at most ten entries; merge similar ones, and keep the reasons for retiring entries in the archive.
7. Generate the local web page. The current generator reads the qualitative projection in public.json; for the field structure, see the [preview projection](preview/runs/1/public.json). The user first decides which fields may be shown, and questions and predictions are also treated as unpublished information. The internal page keeps the full results. Failed or incomplete rounds show their status and do not enter the completed denominator.
8. Publish or notify to a target only with explicit authorization already in place. First check the specific projection, then the build, upload and deployment status, and open the actual page to confirm the version. Without publication authorization, stop at the local results page.
9. Record the ledger with the unique key of this round's number plus wrap-up, and write the completed state. Confirm the monitor has stopped and release this round's lock.

## Independent reflection

After every three completed rounds, use a new session to check following [reflection_task.md](reflection_task.md). Look at results under the same measure, the scale of tasks and the distribution of failures, and propose the next version of the process. It may write STOP but may not quietly change the yardstick. When a policy is repeatedly changed against the same confirmation set, keep new tasks aside for the final confirmation.
