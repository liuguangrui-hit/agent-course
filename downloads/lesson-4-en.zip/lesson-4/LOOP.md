# One loop round

Start each launch and wrap-up in a new conversation and resume from [STATE.md](STATE.md). Task paths are relative to this practice folder. Each round lives in `runs/<n>/`. After every step, immediately record the completed action, artifact path, and next step in STATE.md. On restart, inspect the artifacts before continuing. Check recorded commits, launches, publications, and notifications before repeating an action.

## Fixed evaluation criteria

Prediction hit rate is the number of correct predictions divided by all predictions in completed rounds. Review pass rate is the number of rounds passing the overall review divided by all completed rounds. Completed rounds with failed reviews stay in both denominators. Running rounds and rounds awaiting review are excluded for now. The page shows both rates.

Write and commit `runs/<n>/prediction.md` before changing code or starting the official run. Each prediction specifies the target, number, reason, and falsification condition, including metric, units, seed aggregation, and allowed range. At wrap-up, score every prediction against its original criterion and preserve the original. Do not remove wrong predictions or widen their ranges afterward. Record smoke-test and classroom short-run settings in the prediction file; these runs do not test predictions for the full setting.

Review uses the three checks in [review_task.md](review_task.md). Overall passage requires all checks to pass and independent review by another agent provider. The playbook changes practices only. Loop workers and reflection reviewers cannot change these criteria, the prediction format, or the review task. The scoring agent does not read the playbook.

## Lock and handoff

1. Launch checks `STOP` first. If it exists, read the reason and exit, leaving it for the learner. The reflection task already sends the stop notification when creating STOP; later scheduled triggers do not send it again.
2. Acquire the round lock with `mkdir .lock`. On success, write `.lock/owner`, `.lock/started_at`, and `.lock/heartbeat`, and record them in STATE.md. The owner identifies the round and launch conversation. Failure means the round is occupied. If its latest activity was within six hours, exit without changing anything. If older than six hours, treat it as a crashed round, send one error notification, and exit. Leave the lock for the learner to inspect processes before takeover. An unreadable timestamp is also an error.
3. Measure the six hours from the latest activity in `.lock/heartbeat`. Launch, wrap-up, and the experiment monitor renew it while working. The monitor checks logs every five minutes, updating only this lock timestamp and its observation record. After the experiment ends, it continues the heartbeat until wrap-up takes over. The nine-hour overnight interval then does not turn a healthy experiment into a stale lock.
4. During launch, use `mkdir .lock/worker` to claim the active writer slot. At the end of launch, record handoff to wrap-up in STATE.md and remove worker, keeping the round lock. The monitor observes; wrap-up writes artifacts and sends notifications.
5. Wrap-up also checks STOP, then verifies the round, owner, server session or local process, and monitor against STATE.md. Only when the state permits wrap-up and its owner matches `.lock/owner` may it claim `mkdir .lock/worker`. If this fails, exit. Wrap-up does not recreate `.lock` or bypass it as a new round. Handle stale locks as in step 2.
6. If STOP, insufficient quota, or a runtime error occurs during this round, update the state, stop this conversation's monitor and scheduled wakeups, and send one stop or error notification. Record any experiment still running and retain the lock until it is checked. Manage experiments by their actual PID or named tmux session.

## Launch

1. Check STOP, acquire the lock, and read STATE.md in the order above. Check quota. If insufficient, record the wait and known reset time, send an error notification, and exit until the next scheduled time. Read [playbook.md](playbook.md) and use practices that fit this task.
2. Pick an unattempted question from `../lesson-2/vault/questions.md`, allocate the next round number, and create `runs/<n>/`. Mark the chosen question and round in the vault. This folder belongs to this question only; preserve its source.
3. Write predictions. Use the table headings `Prediction | Reason | Falsification condition`, or `预测 | 理由 | 推翻条件` in Chinese. Commit predictions and record their commit before editing code.
4. Extend `code/run_experiment.py` with the needed settings and result version field. For the Lesson 3 exercise, add `--seeds`, `--epochs`, `--out`, and the actual commit identifier. Run one seed for five epochs into `runs/<n>/smoke/`. Check columns, row counts, settings, and finite values. Commit the code after the smoke test passes and record the commit. The inherited starter only has `--quick` and needs these options added. See the [Round 1 implementation](preview/runs/1/code/run_experiment.py); its `--commit git` checks that the repository is clean and committed.
5. Before the official run, record its command, expected output, and log. The classroom demo uses one seed and ten epochs. A full round uses the settings fixed in its predictions. Launch in server tmux, write logs to `logs/run.log` or a round-specific log, and results to `runs/<n>/results/`. SSH must return immediately. Without a server, use a local background process fully detached from the terminal and record its PID. Every result row records the code commit made before the run.
6. Set a monitor to inspect the log tail and explicit process state every five minutes. Record its identifier, check method, and wrap-up handoff. When the experiment finishes, mark it ready for wrap-up and continue renewing the heartbeat. Successful background launch does not establish successful completion; wrap-up checks the exit code and completion marker.
7. Append one actual launch usage row to [ledger.csv](ledger.csv), with start and end times, agent, usage source, input and output tokens, and any available cost. Leave unavailable numerical values blank and set usage_status to unavailable; do not fill them with zero. Record the row key as round plus launch and check it on restart.
8. Write launch complete and experiment running or ready for wrap-up in STATE.md, with wrap-up as the next step. Remove `.lock/worker`, keep `.lock`, and end the conversation.

## Wrap-up

1. Take over under the lock rules and verify launch state. If the experiment is still running, record the wait, release worker, leave the monitor active, and exit. This check is not a completed wrap-up; it does not add the wrap-up usage row or send a completion notice.
2. Stop the round's monitor and scheduled wakeups. Retrieve only small results, metadata, and completion records into `runs/<n>/results/`. Large files stay on the server; generate figures locally from small results. For a local run, verify the existing folder. Check exit code, output completeness, and the code commit in every row.
3. Generate figures from result files. Write `runs/<n>/result.md` with each original prediction, actual result, and verdict side by side. Use headings `Prediction | Actual result | Verdict`, or `预测 | 实际结果 | 对错` in Chinese. Verdicts must be Correct or Wrong, or 对 or 错 in Chinese. Add a paragraph on what the result supports and what remains untested, and identify the code commit.
4. Commit the report and small results, then request a read-only Codex review. Replace n with the round number.

```sh
codex exec --sandbox read-only --output-last-message runs/<n>/review.md 'Read review_task.md and apply it to runs/<n>/prediction.md, results/, result.md, and Git history. Output review comments only.'
```

Use Claude as the loop writer and Codex as reviewer. If Codex writes the round, use another provider for review and save the same review filename. The CLI saves the last response to review.md while the review conversation reads inputs only. Identify the reviewed commit and input digests on the first line and finish with the required overall status. Record failed reviews honestly. After changing results, review again; retain the previous opinion in the round folder with its corresponding version.

5. Write results and wrong predictions back to `../lesson-2/vault/conflicts.md` and the relevant pages in `../lesson-2/vault/concepts/`, citing this round's result and review. Add a testable question from the new disagreement to `../lesson-2/vault/questions.md` and identify its source conflict. Root [questions.md](questions.md) is an entry point, not a second question list. If there is no new disagreement, record the reason rather than inventing a question.
6. Update the playbook with at most two entries. Each has practice, applicability, source, and score. Merge similar practices and append sources while retaining a specific action to check. Score actual uses and occasions when it helped. Keep at most ten entries; move the lowest success fraction to [playbook-archive.md](playbook-archive.md). Archive unused entries first; break ties by fewer uses, then older sources. Commit the vault and playbook separately and record their commits.
7. Write `runs/<n>/public.json`, following the [preview projection](preview/runs/1/public.json). question, predictions, and conclusion contain qualitative public prose. predictions correspond to the original predictions in the same order and retain their metric and direction. Supply zh and en text; verdicts are read from result.md. Public prose and playbook entries contain questions, practices, and loop counts; full experiment numbers, figures, addresses, and secrets stay in internal records. Check that the public projection preserves the meaning of the private originals.
8. Run the generator.

```sh
python3 code/make_page.py
```

It reads `runs/<n>/prediction.md`, `results/`, `result.md`, and `review.md`, deriving verdicts from result tables and overall status from review comments. `public.json` supplies public prose. It generates `site/` and `internal/`: the former contains summaries, while the latter contains original text, full numbers, figures, and result files. Record generation completion and the internal page location in STATE.md.

9. Copy only the contents of `site/` to the separate public `lab-results` repository. Commit and push, check Pages deployment with gh, and open the URL to verify this round after deployment succeeds. Experiment code, data, and `internal/` remain private. On deployment failure, record the error and pending publication step, then resume there next time.
10. Send a completion notice through ntfy containing one qualitative conclusion, prediction verdicts, review status, and the result-page URL. See the [notification preview](preview/notification.txt). Read the topic and credentials from local configuration. Notify only on completion, error, or stop. Record delivery status; preserve a failed delivery as an error to resume.
11. Append one actual wrap-up usage row to ledger.csv, including available usage from the review invocation and its source. Verify that this round has exactly one launch and one wrap-up row. Update STATE.md with the previous conclusion, completed-round count, publication commit, notification status, and launch as the next step. Mark wrap-up complete. Confirm the monitor is stopped, then remove `.lock/worker` and `.lock` as the final action and end the conversation.

## Daily reflection

At 08:00 each day, run [reflection_task.md](reflection_task.md) in an independent new conversation. Perform the actual check only after three more rounds have completed since the last reflection; otherwise exit. It reads all records and writes `reflections/date.md`. If the direction is wrong, it writes STOP and notifies the learner. Only the learner can clear STOP or resolve a stale lock.
