# Round 1 playbook

Entries record practice, applicability, source, and score. Uses and helpful checks come from the actual checks performed in this round.

## Share validation examples and compare paired seeds

Practice: Replace only validation labels, keep the same validation examples and training trajectory, and compute differences and intervals for matching seeds.

Applicability: Comparing the effect of validation labels on early stopping.

Source: [Round 1 result](runs/1/result.md) and [Round 1 review](runs/1/review.md). The paired-interval check supports the statement that the difference is unclear.

Score: Used 1 time; completed the paired check and helped constrain the conclusion 1 time.

## Record stopping trigger and restored checkpoint separately

Practice: Write both stop_epoch and selected_epoch and explain them separately in the report.

Applicability: Early stopping with patience and best-weight restoration.

Source: [Round 1 result](runs/1/result.md) and [Round 1 review](runs/1/review.md). Review verified the distinction between these epoch definitions.

Score: Used 1 time; verified the distinction between the two epoch definitions 1 time.
