# Completed Round 1

The real local CPU run from Lesson 3 becomes Round 1 here, preserving its original predictions, results, and self-review; this lesson's script generates the pages.

| File or folder | Purpose |
|---|---|
| [site/index.html](site/index.html) | Public summary with qualitative prose and loop metrics |
| [site/round-1.html](site/round-1.html) | Public detail with each prediction and verdict |
| [site/style.css](site/style.css) | Public page styles |
| [internal/index.html](internal/index.html) | Internal summary |
| [internal/round-1.html](internal/round-1.html) | Full predictions, numbers, figure, and review |
| [internal/style.css](internal/style.css) | Internal page styles |
| [internal/assets/](internal/assets/) | Original documents and result copies used internally |
| [runs/1/prediction.md](runs/1/prediction.md) | Four predictions written before the Lesson 3 experiment |
| [runs/1/result.md](runs/1/result.md) | Verdicts, conclusions, and numerical sources |
| [runs/1/review.md](runs/1/review.md) | Original Codex self-review, with formal overall passage failed |
| [runs/1/public.json](runs/1/public.json) | Chinese and English qualitative projections of the same originals |
| [runs/1/results/](runs/1/results/) | Real CSV files, figure, metadata, numerical checks, and log |
| [runs/1/code/](runs/1/code/) | Experiment, analysis, and plotting code used in Lesson 3 |
| [playbook.md](playbook.md) | Two practices drawn from the actual Round 1 process |
| [notification.txt](notification.txt) | Completion notice example with a placeholder URL |

## Real numbers

There is one round with four predictions: one correct and three wrong, for a 25% hit rate. Numbers and conclusions passed self-review, but actual Git provenance and independent review by another provider did not pass. The overall review pass rate is 0%. Pages read the verdict table in result.md and recognize the PREVIEW_UNCOMMITTED commit placeholder in results.csv, preserving the failed overall status.

results/results.csv has 240 rows across four methods, four noise levels, five seeds, and three policies. At 40% noise, five-seed CE means are 93.25% accuracy with noisy validation, 92.26% with clean validation, and 68.37% without stopping. Noisy and clean stopping trigger epochs are 11.8 and 14.4, while restored checkpoint epochs are 3.8 and 6.4. Every value comes from the [per-run results](runs/1/results/results.csv); see [summary.csv](runs/1/results/summary.csv) and [paired_differences.csv](runs/1/results/paired_differences.csv). Actual runtime in [run_metadata.json](runs/1/results/run_metadata.json) is 258.5348861217499 seconds.

These are existing Lesson 3 results, imported here to regenerate pages. The original review's prediction.md and results.csv digests match the originals, while its result.md digest differs from the current original. This package preserves both the source report and source review, with overall passage still failed. There are no results for Round 2 or later, and no Lesson 4 server execution, actual commits, publication, or notification delivery records. notification.txt demonstrates the message to send and contains no specific experiment numbers. Both packages use the existing English-labelled Lesson 3 figure and share the same code and data.

## Regenerate and rerun

Run from the parent practice folder:

```sh
python3 code/make_page.py --root preview --language en
```

This rebuilds preview/site/ and preview/internal/ without changing Round 1 inputs. Public output contains HTML and CSS only. Internal output retains all small results and original text.

Save reruns separately to preserve the originals shown in class:

```sh
uv run python preview/runs/1/code/run_experiment.py --seeds 0 --epochs 5 --out runs/replay/smoke
uv run python preview/runs/1/code/run_experiment.py --out runs/replay/results
uv run python preview/runs/1/code/analyze_results.py --input runs/replay/results/results.csv --out runs/replay/results
uv run --with matplotlib==3.9.4 python preview/runs/1/code/plot_results.py --input runs/replay/results/results.csv --out runs/replay/results/fig_early_stop.png --language en
```

Experiment and analysis require only numpy; uv temporarily supplies matplotlib for plotting. replay is a rerun folder, not a new numbered round, and does not enter public pages. For the official loop, place completed code in code/, commit first, then use `--commit git` to record the actual commit.
