# Review this round

Use an independent conversation with another agent provider to perform the three checks from Lesson 3 Exercise 3 for the specified round. Read only prediction.md, results/, result.md, the code version used, and Git history. Do not read the playbook.

On the first line, identify the reviewed code and report commits. Then write three lines: `prediction.md SHA-256: <actual digest>`, `results/results.csv SHA-256: <actual digest>`, and `result.md SHA-256: <actual digest>`. For each check, state passed or failed and cite specific files or result rows. The generator checks that a passing opinion's three digests match the current files.

1. Numbers match. Recompute every numerical claim in the report. Check means, variability, paired differences, figures, prediction verdicts, and falsification conditions. Every number must have evidence in the results.
2. Conclusions stay within the numbers. Check controls, seeds, noise settings, the distinction between stopping trigger and restored checkpoint epochs, the tested scope, and what remains untested. Identify claims the results do not support.
3. Commits and settings match. Every result row's commit must exist in history and precede the official run. That version's settings must match metadata and results. The prediction commit precedes code changes and the official run. Placeholder identifiers and file digests do not replace commit history.

If all three checks pass and another provider performed an independent review, end with `REVIEW_STATUS: PASS`. Otherwise end with `REVIEW_STATUS: FAIL`. State self-review and missing history explicitly. Review applies to the current artifact version; review again after changing inputs. Output comments only. The main worker saves the response as this round's review.md using the CLI output-last-message option.
