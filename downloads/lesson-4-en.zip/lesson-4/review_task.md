# Review this round

In an independent conversation with another vendor's agent, review the specified round as in Lesson 3 Exercise 3. Read only that round's prediction.md, results/, result.md, the code version used and the Git history. Do not read the playbook.

On the first line, state the code commit and the result-report commit reviewed. Then write three separate lines: `prediction.md SHA-256: <actual digest>`, `results/results.csv SHA-256: <actual digest>` and `result.md SHA-256: <actual digest>`. For each item, write passed or failed, citing specific files or result rows. The generator checks that the three digests in a passing review match the current files.

1. Do the numbers match? Recompute every number in the result report, checking means, variability, same-seed paired differences, figures, prediction verdicts and falsification conditions. Every number should have a basis in the result files.
2. Do the conclusions go beyond the numbers? Check controls, seeds, noise settings, and the distinction between the stopping epoch and the restored-weights epoch; check the scope the conclusions apply to and what remains untested. Point out inferences the results cannot support.
3. Do commits and settings match? The commit of every result row must exist in the history and come before the real run, and that version's code parameters must agree with the metadata and the results. The prediction commit comes before the code change and the real run. Placeholder IDs and file digests cannot replace commit records.

Before the verdict, write a claim check: list every comment that asks to narrow a claim and why it is necessary; where support is missing, first give an experiment that adds evidence at the original scale; for problems of expression, give a way to retell. Suggest a corresponding rewrite only when counterevidence already exists or the claim cannot be tested in principle.

If all three items pass and the review was done independently by the other vendor, write `REVIEW_STATUS: PASS` on the last line; otherwise write `REVIEW_STATUS: FAIL`. State clearly if it was a self-review or history was missing. The review applies to the current product version; after inputs change, review again. Output only the comments; the main executor saves them through its own caller. In the AI Scientist project, all such calls go through call_agent.
