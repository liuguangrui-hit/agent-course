# Single-call preparation check

Input identity: this file is an ordinary check record that comes with the course.
Execution status: no research experiment has been started; this only checks whether the non-interactive call works.
Next step: in class, read the real result record, then set up one short-delay wake-up.
