# Loop state

This is the initial template. Fill in actual values after every step. Include a timezone in timestamps.

Current round: 0
Phase: Not started
Current step: Awaiting first launch
Active conversation: None
Conversation start time: Not started
Server tmux session: Not configured
Local background PID: None
Experiment location: Not configured
Run command: Not configured
Result folder: Not created
Log location: Not created
Experiment exit code and completion marker: Not completed
Lock owner: None
Lock start time: None
Lock latest activity: None
Worker conversation: None
Monitor and scheduled wakeups: Not started
Monitor stop method: Not configured
Handoff status: Not launched
Prediction commit: None
Code commit: None
Result and review version: None
Vault writeback and commit: Not completed
Playbook writeback and commit: Not completed
Public projection check: Not completed
Page generation and internal location: Not generated
Pages URL and publication commit: Not configured
Pages deployment status: Not published
Notification status: Not sent
ntfy configuration entry: Not configured, record configuration location only
Launch ledger row key: None
Wrap-up ledger row key: None
Quota and reset time: Not checked
Completed rounds: 0
Last reflection covered through round: 0
Last reflection date and file: None
Reflection conversation and status: None
Previous conclusion: None
Next step: Launch, check STOP first
Wait or error: None
