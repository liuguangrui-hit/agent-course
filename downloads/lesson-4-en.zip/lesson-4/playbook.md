# Playbook

Give each entry a second-level heading, and write the concrete action, the conditions of use and the source, noting its candidate status and the test to follow. Record usage claims and actual results separately; an entry's contribution needs a control or an ablation. At most ten entries, at most one new entry per round; merge similar entries, and write the reasons for retiring an entry into [playbook-archive.md](playbook-archive.md). Use it for internal work first; the user decides what may be shown. The evaluation rules are in [LOOP.md](LOOP.md), and the playbook has no authority to change them.

No entries yet. Fill in after the first round.
