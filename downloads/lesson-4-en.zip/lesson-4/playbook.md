# Playbook

Use a level-two heading for each entry, followed by four fields: Practice is an action to take next time; Applicability states when to use it; Source links to a specific round's result or review; Score records actual uses and occasions when it helped. Keep at most ten entries and write at most two per round. Merge similar entries and move excess entries to [playbook-archive.md](playbook-archive.md) under the rules in LOOP.md. Entries appear publicly and contain practices and loop counts. Evaluation criteria are fixed in [LOOP.md](LOOP.md); the playbook cannot change them.

No entries yet. Add them after the first round.
