# 第 5 课练习材料：安全控制

## 本练习训练的方法

本练习为第 4 课的工作环境增加权限配置、沙箱和两道自动检查，训练以下方法：沿信息流识别信任边界；按角色设计文件、网络与凭据权限；用允许、拒绝及跨入口测试验证边界，并说明每类结果支持的判断；评价 Hook 的事件覆盖与失败行为。允许测试说明合法任务可以完成，拒绝测试只说明被测入口在当前配置下阻止了预定动作，其他入口须另行测试。

## 课程的三个阶段

- 课前准备：检查 Python、Git、Bash 与 gitleaks，下载所需组件并备份配置，不启用成品权限表。
- 课堂教学：绘制角色能力表，配置边界，实测允许与拒绝行为，再核查 Hook 覆盖范围。
- 课后复习与扩展：先重画信息流，再辨析入口拒绝与进程隔离，最后更换入口或执行端重测。

课前检查记录写入 preflight.md，课后复习记录写入 review-after-class.md。课堂各段时间、正反例和能力达成评价见本课课程页。安装和下载在课前完成，课堂直接使用本地材料。

材料为第 4 课的工作环境提供项目权限配置、沙箱和两道自动检查的起点。

- [settings.example.json](settings.example.json)：Claude Code 权限表起点，allow 与 deny 都为空。
- [config.example.toml](config.example.toml)：Codex 项目配置起点，限制写入范围并关闭命令联网。
- [hooks/check_tex.py](hooks/check_tex.py)：编辑 paper/ 下的 .tex 后核对数字。
- [hooks/pre_push_secrets.sh](hooks/pre_push_secrets.sh)：单分支推送前扫描待推送提交。
- [code/check_numbers.py](code/check_numbers.py)：第 1 课参考答案的数字检查器，只用 Python 标准库。
- data/：检查器需要的原始实验结果，分别为 [results.csv](data/results.csv) 和 [curves.csv](data/curves.csv)。
- [code/test_hooks.py](code/test_hooks.py)：用假的事件输入和普通提交复跑分支测试。
- [.env.example](.env.example)：环境变量名称起点，值留空，由你复制成 .env 后填写。
- [.gitignore](.gitignore)：让 Git 忽略 .env。
- [preview/](preview/README.md)：课堂先看的完整配置和实际验证记录。
- [AGENTS.md](AGENTS.md)：工作台的稳定约定。
- [CLAUDE.md](CLAUDE.md)：让 Claude Code 读取同一份约定。

## 先看成品，再填起点

课前只阅读材料并备份配置，以下配置在课堂划分角色后进行。先读 preview/，再把两份 example 文件分别复制到工作台的 `.claude/settings.json` 和 `.codex/config.toml`。把 hooks/ 放在工作台根目录。JSON 不支持注释，字段说明放在这里。`permissions.deny` 写拒绝规则，`permissions.allow` 写常用命令规则，两者同时命中时拒绝优先。空数组供练习填写，已有用户配置和管理配置也会参与合并。Claude Code 在信任项目后才加载项目的 Hooks。

按正文任务卡先列实际用到的命令，再填表。preview/settings.json 放行 git 的提交、推送、状态、差异和日志，也放行 uv run、ssh lab 和 gh。拒绝表中的 Read(./.env) 禁止 Agent 直接读取 .env，脚本启动时自己加载它。沙箱的 autoAllowBashIfSandboxed 设为 false，让表外命令继续走权限询问。allowUnsandboxedCommands 设为 false，关闭退出沙箱重试。excludedCommands 中的 ssh lab:* 让 ssh lab 在沙箱外运行，ssh 自己使用私钥。failIfUnavailable 设为 true，缺少沙箱组件时停止启动。

成品使用 `sandbox.network.strictAllowlist` 为 true，严格拒绝沙箱命令访问名单外域名。这个字段在项目配置文件里不生效，需要用户配置、管理配置或命令行 `--settings`。练习时把 preview/settings.json 复制到工作台的 `.claude/settings.json`，在工作台根目录启动：

```sh
claude --settings .claude/settings.json
```

这样名单和 ssh 例外从同一个命令行配置加载。域名限制只管沙箱中的命令。ssh lab 例外在沙箱外运行，服务器端权限另外管理。

Codex 起点使用 workspace-write 和 on-request。writable_roots 为空，表示没有额外可写目录；两个 exclude 字段去掉默认临时目录写权限。network_access 为 false，命令联网需要另行配置或请求批准。Codex 只在信任项目后加载项目配置，沙箱外命令的规则使用 `.rules` 文件。这份 TOML 的用途是设置沙箱与审批策略。

## 接上两道检查

`hooks/check_tex.py` 读取 stdin 的 JSON，从 tool_input.file_path 取文件路径。只有工作台 paper/ 下的 .tex 才调用 `code/check_numbers.py`。检查器从第 1 课参考答案包的 `code/check_numbers.py` 原样复制。把 code/check_numbers.py 和 data/ 中两份 CSV 放到工作台的同名位置，在工作台根目录运行 `python3 code/check_numbers.py paper/main.tex`。data/ 也从参考答案原样复制，是第 1 课真实实验结果。检查器接收一个相对工作台的 .tex 路径，成功退出 0，数字不匹配时非零退出并输出原因。Hook 把失败原因写到 stderr 并退出 2，Claude 会看到原因；文件编辑已经发生。

`hooks/pre_push_secrets.sh` 需要 Python 3、Git 和 gitleaks。支持 `git push`、`git push origin main`、`git push -u origin main`、`git push origin HEAD:main`，也支持 git -C。推送单独运行，每次一个分支。脚本读取目标远端的当前分支位置，用该位置到本地提交的区间扫描；新分支或本地缺少远端对象时扫描源分支历史。扫描报告隐藏密钥值。发现疑似密钥、扫描失败或超时都退出 2，由 PreToolUse 阻止推送。它是 Claude Code 的工具 Hook，命令行里手动运行 git push 要另接 Git 的 pre-push Hook。

preview 的 allowedDomains 按正文任务卡包含 github.com、arxiv.org 和 api.openalex.org。通过上述 --settings 启动后，名单外的连接会被拒绝。Claude 沙箱默认还允许写临时目录。gh 常用的 api.github.com 需要按实际调用加入同一层的名单。

## 复跑验证

安装 gitleaks 后，在本份材料目录运行：

```sh
python3 code/test_hooks.py
```

程序从 stdin 喂入假的事件，创建临时本地仓库，实际扫描普通提交，再用扫描器替身测试发现问题时的退出码。结果写到终端。现有 preview/verification.json 保留材料初版的中英文实际运行结果。

字段已对照 [Claude 设置](https://code.claude.com/docs/en/settings)、[沙箱](https://code.claude.com/docs/en/sandboxing)、[Hooks](https://code.claude.com/docs/en/hooks)、[Codex 配置](https://developers.openai.com/codex/config-reference/) 和 [Codex 规则](https://developers.openai.com/codex/rules/) 核对。扫描区间的写法来自 [gitleaks 文档](https://github.com/gitleaks/gitleaks)。

## 边界说明

现有验证脚本测试 Hook 分支与扫描入口，不代表当前桌面或 CLI 的操作系统沙箱已验证。接入自己的配置后，分别做允许和拒绝的无害行为测试。示例中放行的脚本类命令和沙箱外 SSH 都是较宽能力，按自己的角色表收紧。

Read 拒绝规则只约束对应工具入口；同用户下的任意脚本可能读取环境变量或本地凭据。.gitignore 只防常规提交。需要凭据隔离时，使用隔离进程、独立账号或受限服务能力。

Hook 与沙箱字段按当前厂商文档核对。对外发布前的全量检查放在固定发布入口，记录所检产物版本。测试用失效样例或扫描器替身，不使用真实凭据。

本练习须配合课程页面完成复习、独立实践与迁移评价。指定必读片段须完成，其余深入专题按研究需要选做。
