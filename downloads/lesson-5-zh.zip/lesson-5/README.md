# 第 5 课练习材料：编排安全

给第 4 课的工作台加项目权限配置、沙箱和两道自动检查。

- [settings.example.json](settings.example.json)：Claude Code 权限表起点，allow 与 deny 都为空。
- [config.example.toml](config.example.toml)：Codex 项目配置起点，限制写入范围并关闭命令联网。
- [hooks/check_tex.py](hooks/check_tex.py)：编辑 paper/ 下的 .tex 后核对数字。
- [hooks/pre_push_secrets.sh](hooks/pre_push_secrets.sh)：单分支推送前扫描待推送提交。
- [code/check_numbers.py](code/check_numbers.py)：第 1 课参考答案的数字检查器，只用 Python 标准库。
- data/：检查器需要的原始实验结果，分别为 [results.csv](data/results.csv) 和 [curves.csv](data/curves.csv)。
- [code/test_hooks.py](code/test_hooks.py)：用假的事件输入和普通提交复跑分支测试。
- [.env.example](.env.example)：环境变量名称起点，值留空，由你复制成 .env 后填写。
- [.gitignore](.gitignore)：让 Git 忽略 .env。
- [preview/](preview/README.md)：课堂先看的完整配置和实际验证记录。
- [AGENTS.md](AGENTS.md)：工作台的稳定约定。
- [CLAUDE.md](CLAUDE.md)：让 Claude Code 读取同一份约定。

## 先看成品，再填起点

先读 preview/，再把两份 example 文件分别复制到工作台的 `.claude/settings.json` 和 `.codex/config.toml`。把 hooks/ 放在工作台根目录。JSON 不支持注释，字段说明放在这里。`permissions.deny` 写拒绝规则，`permissions.allow` 写常用命令规则，两者同时命中时拒绝优先。空数组供练习填写，已有用户配置和管理配置也会参与合并。Claude Code 在信任项目后才加载项目的 Hooks。

按正文任务卡先列实际用到的命令，再填表。preview/settings.json 放行 git 的提交、推送、状态、差异和日志，也放行 uv run、ssh lab 和 gh。拒绝表中的 Read(./.env) 禁止 Agent 直接读取 .env，脚本启动时自己加载它。沙箱的 autoAllowBashIfSandboxed 设为 false，让表外命令继续走权限询问。allowUnsandboxedCommands 设为 false，关闭退出沙箱重试。excludedCommands 中的 ssh lab:* 让 ssh lab 在沙箱外运行，ssh 自己使用私钥。failIfUnavailable 设为 true，缺少沙箱组件时停止启动。

成品使用 `sandbox.network.strictAllowlist` 为 true，严格拒绝沙箱命令访问名单外域名。这个字段在项目配置文件里不生效，需要用户配置、管理配置或命令行 `--settings`。练习时把 preview/settings.json 复制到工作台的 `.claude/settings.json`，在工作台根目录启动：

```sh
claude --settings .claude/settings.json
```

这样名单和 ssh 例外从同一个命令行配置加载。域名限制只管沙箱中的命令。ssh lab 例外在沙箱外运行，服务器端权限另外管理。

Codex 起点使用 workspace-write 和 on-request。writable_roots 为空，表示没有额外可写目录；两个 exclude 字段去掉默认临时目录写权限。network_access 为 false，命令联网需要另行配置或请求批准。Codex 只在信任项目后加载项目配置，沙箱外命令的规则使用 `.rules` 文件。这份 TOML 的用途是设置沙箱与审批策略。

## 接上两道检查

`hooks/check_tex.py` 读取 stdin 的 JSON，从 tool_input.file_path 取文件路径。只有工作台 paper/ 下的 .tex 才调用 `code/check_numbers.py`。检查器从第 1 课参考答案的 `paper/v2/cases/lesson-1-answers/zh/code/check_numbers.py` 原样复制。把 code/check_numbers.py 和 data/ 中两份 CSV 放到工作台的同名位置，在工作台根目录运行 `python3 code/check_numbers.py paper/main.tex`。data/ 也从参考答案原样复制，是第 1 课真实实验结果。检查器接收一个相对工作台的 .tex 路径，成功退出 0，数字不匹配时非零退出并输出原因。Hook 把失败原因写到 stderr 并退出 2，Claude 会看到原因；文件编辑已经发生。

`hooks/pre_push_secrets.sh` 需要 Python 3、Git 和 gitleaks。支持 `git push`、`git push origin main`、`git push -u origin main`、`git push origin HEAD:main`，也支持 git -C。推送单独运行，每次一个分支。脚本读取目标远端的当前分支位置，用该位置到本地提交的区间扫描；新分支或本地缺少远端对象时扫描源分支历史。扫描报告隐藏密钥值。发现疑似密钥、扫描失败或超时都退出 2，由 PreToolUse 阻止推送。它是 Claude Code 的工具 Hook，命令行里手动运行 git push 要另接 Git 的 pre-push Hook。

preview 的 allowedDomains 按正文任务卡包含 github.com、arxiv.org 和 api.openalex.org。通过上述 --settings 启动后，名单外的连接会被拒绝。Claude 沙箱默认还允许写临时目录。gh 常用的 api.github.com 需要按实际调用加入同一层的名单。

## 复跑验证

安装 gitleaks 后，在本份材料目录运行：

```sh
python3 code/test_hooks.py
```

程序从 stdin 喂入假的事件，创建临时本地仓库，实际扫描普通提交，再用扫描器替身测试发现问题时的退出码。结果写到终端。现有 preview/verification.json 保留材料初版的中英文实际运行结果。

字段已对照 [Claude 设置](https://code.claude.com/docs/en/settings)、[沙箱](https://code.claude.com/docs/en/sandboxing)、[Hooks](https://code.claude.com/docs/en/hooks)、[Codex 配置](https://developers.openai.com/codex/config-reference/) 和 [Codex 规则](https://developers.openai.com/codex/rules/) 核对。扫描区间的写法来自 [gitleaks 文档](https://github.com/gitleaks/gitleaks)。
