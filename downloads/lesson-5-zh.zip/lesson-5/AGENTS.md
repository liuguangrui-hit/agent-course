# 项目约定
- 配置放在项目的 .claude/settings.json 和 .codex/config.toml。
- paper/ 下的 .tex 改动使用 code/check_numbers.py 核对数字。
- 推送前扫描待推送提交，检查失败先修正原因。
- 密钥值留在钥匙串或被 Git 忽略的 .env 中。
