# 成品与验证记录

[settings.json](settings.json) 是课堂先看的完整 Claude Code 配置，[verification.json](verification.json) 保留材料初版的两个语言版本实际测试结果。

| 项目 | 数值 | 来源 |
|---|---:|---|
| 拒绝规则 | 5 | settings.json 的 permissions.deny |
| 允许规则 | 8 | settings.json 的 permissions.allow |
| 网络域名 | 3 | settings.json 的 sandbox.network.allowedDomains |
| Hook 事件 | 2 | settings.json 的 hooks |
| 初版每个语言版本通过用例 | 23 | code/test_hooks.py 的实际运行 |
| 测试仓库待推送提交 | 1 | git rev-list 对远端与本地提交区间的实际计数 |
| 中文版最慢用例秒数 | 0.462950 | verification.json 的 zh.maximum_case_seconds |
| 英文版最慢用例秒数 | 0.378229 | verification.json 的 en.maximum_case_seconds |

真实扫描使用 gitleaks 8.30.1。扫描对象是临时仓库中的普通提交。发现问题的分支由扫描器替身返回失败状态，测试没有密钥样本。以上数字来自解析文件、Git 计数和进程计时。

成品包含 Read(./.env) 拒绝规则、ssh lab:* 沙箱外例外和 sandbox.network.strictAllowlist 为 true。把 settings.json 复制到工作台的 `.claude/settings.json`，在工作台根目录运行 `claude --settings .claude/settings.json`。strictAllowlist 在项目配置层不生效，通过 --settings 加载才会严格拒绝沙箱命令访问名单外域名，见 [官方网络隔离说明](https://code.claude.com/docs/en/sandboxing#network-isolation)。

工作台根目录使用 hooks/ 和随附的 code/check_numbers.py、data/。数字检查器来自第 1 课参考答案，接口见 [材料说明](../README.md)。表中的用例与计时保留初版记录，JSON 的规则数按当前 settings.json 读取。Claude Code 内的加载和沙箱边界按正文练习在你的工作台实测。
