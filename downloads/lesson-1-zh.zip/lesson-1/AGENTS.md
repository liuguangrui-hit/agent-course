# 项目约定

- paper/main.tex 是初稿。每个新版本另建文件夹，依次为 versions/v1/，versions/v2/。
- 论文里的每个数字都要来自 data/results.csv 或 data/curves.csv。
- 图由 code/ 里的脚本从数据文件生成，不手工修改。
