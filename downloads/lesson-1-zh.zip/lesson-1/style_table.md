# 论文表达对照表

论文用英文写，下表的例子保留英文原句。

## 文字

| 问题 | 例子 | 改法 |
|---|---|---|
| 题目在描述而不是下论断 | Towards an Empirical Understanding of ... : A Preliminary Study | 短题目，直接说发现，让人记得住 |
| 摘要从背景开始 | In recent years, deep neural networks have achieved remarkable success | 第一句就是最抓人的结果 |
| 处处留后路 | may, to some extent, preliminary, appears to | 直接下论断，证据边界只在一处讲一次 |
| 说完结论马上往回收 | 结论后紧跟 It should be noted that | 只下论断，局限集中在讨论里讲一段 |
| 同一句限定在摘要引言结果结论各说一遍 | limited to a synthetic setting 出现四次 | 只说一次 |
| 贡献清单把摘要再说一遍 | We systematically compare ... We find ... | 引言末尾按读者会追问的顺序交代要回答的问题 |
| 结果按实验编号排 | RQ1，RQ2，RQ3 | 按读者的追问排，每段第一句是结论 |
| 段首只写话题 | Memorization. Robust losses. | 段首写这一段的结论 |
| 套话 | Notably, It is worth noting, We hope this work | 删掉 |
| 同一个数各处不一致 | 摘要 96.2%，表里 96.0 | 每个数都能追到数据文件，各处说法一致 |

## 图

| 问题 | 改法 |
|---|---|
| 画得很大再缩进一栏，字缩到 4 磅 | 按最终宽度画，单栏约 3.25 英寸，字号 7 到 9 磅 |
| 屏幕分辨率的 PNG | 矢量 PDF |
| 图里有标题 | 结论写进图注，图里不放标题 |
| 坐标轴直接用变量名 | 写成读者看得懂的名字并带单位，如 Test accuracy (%) |
| 图例压住数据，或者二十条线缠在一起 | 多个种子画均值线加误差带，线旁直接标名字 |
| 同一方法在不同图里颜色不同 | 每个方法固定一种颜色 |
| 默认配色 | 色盲友好的配色 |
| 虚线网格，粗边框 | 只留浅色横向网格，去掉上边和右边的框 |
| 图注只说这是什么图 | 图注说读者应该看到什么 |
