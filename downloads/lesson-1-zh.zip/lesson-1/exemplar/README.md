范文放在这里。课上由 Agent 下载 arXiv 1611.03530，即 Zhang 等人的 Understanding deep learning requires rethinking generalization；课后换成目标刊会里你最欣赏的一篇。
