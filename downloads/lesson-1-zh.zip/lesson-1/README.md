# 第 1 课练习材料

- before.md 与 after.md：同一段内容重讲前后的对照。
- draft.md：练习用的原稿。
- style_table.md：去 AI 味对照表。
- AGENTS.md 与 CLAUDE.md：项目约定，两家 Agent 共读。
- exemplar/：放范文。

文中的课题组与数字均为虚构。
