# 第 1 课练习材料：写作绘图

## 本课的三个阶段

- 课前预备：提前装 Python、LaTeX 与 PDF 渲染工具，编译原稿并下载范文。
- 课上一小时：课堂重讲论文、重画数据图、做独立审阅，并提炼最小 Skill。
- 课后复习与拔高：先复述稿件与追查数字，再比较两种讲法与种子选择，最后做返修或迁移测试。

课前检查写入 preflight.md，课后复盘写入 review-after-class.md。逐段时间与正反例见本课课程页。安装和下载在课前完成，课堂直接使用本地材料。

一篇四页的初稿，研究几种训练损失在标签有噪声时的表现。实验是真的：`code/run_experiment.py` 在笔记本上一分钟左右就能重新跑出 `data/`，只需要 numpy。文字和图故意写得粗糙。

- paper/：LaTeX 初稿和图
- data/：实验结果，每次运行一行，以及每轮的测试准确率
- code/：实验代码和画初稿图的脚本
- preview/：before.pdf 是初稿编译结果；after.pdf 是一种改法，最后对照用
- style_table.md：文字和图要改的地方
- AGENTS.md 与 CLAUDE.md：项目约定，两家 Agent 共读
- exemplar/：放范文
