# 第 1 课练习材料：一篇待改的短论文

一篇四页的初稿，研究几种训练损失在标签有噪声时的表现。实验是真的：`code/run_experiment.py` 在笔记本上一分钟左右就能重新跑出 `data/`，只需要 numpy。文字和图故意写得粗糙。

- paper/：LaTeX 初稿和图
- data/：实验结果，每次运行一行，以及每轮的测试准确率
- code/：实验代码和画初稿图的脚本
- preview/：before.pdf 是初稿编译结果；after.pdf 是一种改法，最后对照用
- style_table.md：文字和图要改的地方
- AGENTS.md 与 CLAUDE.md：项目约定，两家 Agent 共读
- exemplar/：放范文
