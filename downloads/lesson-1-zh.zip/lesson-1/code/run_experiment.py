"""Label-noise study: how four training losses hold up as labels get noisier.

A two-layer network learns a 10-class Gaussian-mixture task. A fraction of
training labels is flipped uniformly at random; test labels stay clean.
Writes results.csv (one row per run) and curves.csv (test accuracy per epoch).
Needs only numpy. Runs in a few minutes on a laptop.
"""
import argparse
import csv
import time

import numpy as np

METHODS = ["ce", "label_smoothing", "gce", "small_loss"]
NOISE = [0.0, 0.2, 0.4, 0.6]
SEEDS = [0, 1, 2, 3, 4]


def make_data(rng, n_train=4000, n_test=2000, d=20, k=10, sep=1.15):
    means = rng.normal(size=(k, d)) * sep
    def sample(n):
        y = rng.integers(0, k, size=n)
        x = means[y] + rng.normal(size=(n, d))
        return x.astype(np.float32), y
    return sample(n_train), sample(n_test)


def flip(rng, y, rate, k=10):
    y = y.copy()
    idx = rng.random(len(y)) < rate
    y[idx] = (y[idx] + rng.integers(1, k, size=idx.sum())) % k
    return y


def softmax(z):
    z = z - z.max(1, keepdims=True)
    e = np.exp(z)
    return e / e.sum(1, keepdims=True)


def train(x, y_noisy, x_te, y_te, method, rate, rng, hidden=512, epochs=80, bs=64, lr=2e-3, k=10):
    d = x.shape[1]
    params = {
        "W1": rng.normal(size=(d, hidden)).astype(np.float32) * np.sqrt(2 / d),
        "b1": np.zeros(hidden, np.float32),
        "W2": rng.normal(size=(hidden, k)).astype(np.float32) * np.sqrt(1 / hidden),
        "b2": np.zeros(k, np.float32),
    }
    m = {p: np.zeros_like(v) for p, v in params.items()}
    v = {p: np.zeros_like(v) for p, v in params.items()}
    step = 0
    curve = []
    n = len(x)
    for ep in range(epochs):
        order = rng.permutation(n)
        for s in range(0, n, bs):
            b = order[s:s + bs]
            xb, yb = x[b], y_noisy[b]
            h_pre = xb @ params["W1"] + params["b1"]
            h = np.maximum(h_pre, 0)
            p = softmax(h @ params["W2"] + params["b2"])
            onehot = np.eye(k, dtype=np.float32)[yb]
            if method == "ce":
                g = p - onehot
            elif method == "label_smoothing":
                target = onehot * 0.9 + 0.1 / k
                g = p - target
            elif method == "gce":
                q = 0.7
                py = p[np.arange(len(yb)), yb][:, None]
                # d/dz of (1 - p_y^q)/q = -p_y^q * (onehot - p)
                g = (py ** q) * (p - onehot)
            elif method == "small_loss":
                keep_frac = 1 - rate * min(1.0, ep / 10)
                loss = -np.log(p[np.arange(len(yb)), yb] + 1e-12)
                keep = np.argsort(loss)[: max(1, int(round(keep_frac * len(yb))))]
                mask = np.zeros((len(yb), 1), np.float32)
                mask[keep] = 1
                g = (p - onehot) * mask * len(yb) / max(1, len(keep))
            g = g / len(yb)
            grads = {
                "W2": h.T @ g,
                "b2": g.sum(0),
            }
            gh = (g @ params["W2"].T) * (h_pre > 0)
            grads["W1"] = xb.T @ gh
            grads["b1"] = gh.sum(0)
            step += 1
            for name in params:
                m[name] = 0.9 * m[name] + 0.1 * grads[name]
                v[name] = 0.999 * v[name] + 0.001 * grads[name] ** 2
                mh = m[name] / (1 - 0.9 ** step)
                vh = v[name] / (1 - 0.999 ** step)
                params[name] -= lr * mh / (np.sqrt(vh) + 1e-8)
        logits = np.maximum(x_te @ params["W1"] + params["b1"], 0) @ params["W2"] + params["b2"]
        curve.append(float((logits.argmax(1) == y_te).mean()))
    return curve


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=str(__import__("pathlib").Path(__file__).resolve().parent.parent / "data"))
    ap.add_argument("--quick", action="store_true", help="one seed, fewer epochs")
    a = ap.parse_args()
    seeds = SEEDS[:1] if a.quick else SEEDS
    epochs = 20 if a.quick else 80
    rows, curves = [], []
    t0 = time.time()
    for seed in seeds:
        rng = np.random.default_rng(seed)
        (x, y), (x_te, y_te) = make_data(rng)
        for rate in NOISE:
            y_noisy = flip(np.random.default_rng(1000 + seed), y, rate)
            for method in METHODS:
                curve = train(x, y_noisy, x_te, y_te, method, rate, np.random.default_rng(seed), epochs=epochs)
                rows.append({"method": method, "noise": rate, "seed": seed,
                             "final_acc": round(curve[-1], 4), "best_acc": round(max(curve), 4),
                             "best_epoch": int(np.argmax(curve)) + 1})
                curves += [{"method": method, "noise": rate, "seed": seed, "epoch": i + 1, "test_acc": round(c, 4)}
                           for i, c in enumerate(curve)]
                print(f"seed {seed} noise {rate} {method:16s} final {curve[-1]:.3f} best {max(curve):.3f}  {time.time()-t0:.0f}s", flush=True)
    for name, data in (("results.csv", rows), ("curves.csv", curves)):
        with open(f"{a.out}/{name}", "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(data[0]))
            w.writeheader()
            w.writerows(data)


if __name__ == "__main__":
    main()
