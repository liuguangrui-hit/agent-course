"""Draft figures, as a first-year student might make them."""
import csv
import pathlib
import collections
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

BASE = pathlib.Path(__file__).resolve().parent.parent

rows = list(csv.DictReader(open(BASE / "data/results.csv")))
acc = collections.defaultdict(list)
for r in rows:
    acc[(r["method"], float(r["noise"]))].append(float(r["final_acc"]))
noise = [0.0, 0.2, 0.4, 0.6]

plt.figure(figsize=(8, 6))
for m in ["gce", "ce", "small_loss", "label_smoothing"]:
    plt.plot(noise, [sum(acc[(m, n)]) / len(acc[(m, n)]) for n in noise], label=m)
plt.title("Final Test Accuracy of Different Methods under Different Noise Rates")
plt.xlabel("noise")
plt.ylabel("acc")
plt.grid(linestyle="--")
plt.legend()
plt.savefig(BASE / "paper/figures/fig_noise.png", dpi=72)

curves = list(csv.DictReader(open(BASE / "data/curves.csv")))
plt.figure(figsize=(8, 6))
for m in ["ce", "label_smoothing", "gce", "small_loss"]:
    for s in range(5):
        pts = [r for r in curves if r["method"] == m and float(r["noise"]) == 0.4 and int(r["seed"]) == s]
        plt.plot([int(r["epoch"]) for r in pts], [float(r["test_acc"]) for r in pts], label=f"{m} seed{s}")
plt.title("Test Accuracy Curves (noise=0.4)")
plt.xlabel("epoch")
plt.ylabel("test acc")
plt.legend()
plt.savefig(BASE / "paper/figures/fig_curves.png", dpi=72)
