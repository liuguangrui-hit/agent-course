# 第 6 课练习材料：编排理论

## 本课的三个阶段

- 课前预备：检查 Python 标准库与三组文件，带一条经验，不先生成分析结论。
- 课上一小时：课堂定义学习对象、回报与更新，运行三组分析并设计可检验预测。
- 课后复习与拔高：先不用公式讲一轮更新，再拆总效应与内容差，最后做样本量、识别或迁移推导。

课前检查写入 preflight.md，课后复盘写入 review-after-class.md。逐段时间与正反例见本课课程页。安装和下载在课前完成，课堂直接使用本地材料。

## 课堂三组练习

课堂先用三组演算，再按冻结协议设计真实 Agent 试验。

- [protocol.md](protocol.md)：任务、原点、更新与评分的冻结协议。
- [experience_scores.csv](experience_scores.csv)：明确标注 synthetic 的合成演算数据，十二个任务、两种行为、两段原点记录，各有三组。没有真实 Agent 运行成绩。
- [analyze_experience.py](analyze_experience.py)：标准库分析器，检查每项任务三组完整且无重复，按任务配对 bootstrap，按原点版本分开。
- [theory_checks.py](theory_checks.py)：有限候选比较界和有限状态不保证收敛的复算。

```bash
python3 analyze_experience.py --out experience-analysis.json
python3 theory_checks.py
```

输出保留 data_kind。分析自己的真实数据时按同样列名填表，把 data_kind 写为 real。分析器要求每个任务每组一个预先汇总分数，任务之间独立。重复调用和相关任务按自己的协议聚类分析；缺组先补齐或按事前失败规则显式记分。

同一张演算榜在 origin-v2 中的内容差减小，专门用来说明版本必须分开。这不是两家厂商的能力比较。

## 6.4 用量与成本核算练习

下面给出账本的数据定义与复算入口，数值均为合成演算。

这套示例材料把一个工作台两周的典型用法编成账本，供你计算对话分段、审稿停止与并行决策。

- [ledger.csv](ledger.csv)：四十件事的示例账本，包含八篇稿件的四轮审稿、同一组论文的串行与并行笔记、三个长对话及日常任务。
- [conversations.csv](conversations.csv)：三个长对话的逐轮输入 token，供 6.4 对话分段练习画曲线。
- [review.md](review.md)：逐条示例审稿意见与作者采纳决定，供 6.4 复核实质意见。
- [calc.py](calc.py)：只用 Python 标准库计算三个决策，可修改 c、h、r、V、w。
- [preview/decisions.md](preview/decisions.md)：6.4 深入时看的成品，由 calc.py 实际运行生成。
- [README.md](README.md)：文件说明、数据口径和复算方法。
- [AGENTS.md](AGENTS.md)：本材料的稳定约定。
- [CLAUDE.md](CLAUDE.md)：供 Claude 读取同一份约定的入口。

账本在课后 6.4 深入时使用。先看 preview/decisions.md，再让 Agent 按该深入页的练习写自己的 decisions.md。

```bash
python3 calc.py --output decisions.md
python3 calc.py --c 2500 --h 2000 --r 80000 --v 1128000 --w 0.1 --output decisions.md
```

默认 V 为 500000 未缓存输入 token 等价，w 为每小时 10 美元，h 为 2000 原始 token，r 为 80000 未缓存输入 token 等价。c 默认从 conversations.csv 做最小二乘拟合，--c 可指定原始输入每轮新增量，替代三条对话各自的拟合值。--V 与 --v 等效。--segment-turns 默认 20，可改变练习 1 的固定分段轮数。--lang zh 输出中文，--lang en 输出英文。脚本从自身所在目录读取数据，--output 相对运行命令的目录；省略时输出到终端。

## 数据口径

两份 CSV 都是示例数据，首行注释注明用途，第二行是列名。导入表格或画图工具时跳过首行；calc.py 自动跳过。中文与英文版本的代码和数据完全相同，任务和标识统一使用英文。

ledger.csv 的日期覆盖 2026-09-14 至 2026-09-27。核心列为 date、task、agent、conversations、input_tokens、cache_read_tokens、cache_write_tokens、output_tokens、review_round、substantive、est_cost_usd、minutes、adopted。四类 token 分开记，input_tokens 只计未缓存输入，与缓存读取和缓存写入互不重叠。总 token 是这四列之和。minutes 是实际耗时，conversations 包含主对话和 Sub-agent，adopted 的 yes、partial、no 分别表示采用、部分采用、未采用。agent 中 support 表示示例支撑账号。

review_round 与 substantive 只填审稿任务。substantive 为 yes 表示提出过至少一条被作者采纳的实质意见，为 no 表示没有；逐条意见和采纳决定见 review.md。额外列 item_id 用来对应逐轮数据或审稿记录，notes 标明稿件版本或串并行任务范围。review.md 的 substantive、wording、none 分别表示实质意见、文字意见、没有新意见。

费用采用课堂统一费率，每百万未缓存输入 token 为 3 美元，缓存读取为 0.3 美元，缓存写入为 3.75 美元，输出为 15 美元。因此 est_cost_usd = input_tokens × 3 / 1000000 + cache_read_tokens × 0.3 / 1000000 + cache_write_tokens × 3.75 / 1000000 + output_tokens × 15 / 1000000。比较并行时，w 使用与账本相同的货币，单位为美元每小时，T 与 T′ 先从分钟换为小时。

conversations.csv 的 input_tokens 是每轮完整输入，用于画增长曲线；其中未缓存部分另列为 uncached_input_tokens。完整输入等于该行未缓存输入、缓存读取和缓存写入之和。三条对话分别有 60、80、100 轮，原始输入每轮新增 2000、2500、3000 token，并有小幅波动。各类 token 的逐轮合计与账本对应列一致。

审稿 p_k 读取 review_round 与 substantive，逐条决定由 review.md 核验。成本 C 按四类费率换算为每次审稿的平均未缓存输入 token 等价。1 个缓存读取 token 等于 0.1 个未缓存输入 token，缓存写入等于 1.25 个，输出等于 5 个。V 使用相同单位。脚本寻找第一轮 p_k·V < C，表示不再启动这一轮。V 改变时，输出同时给出各轮的临界值。

## 分段模型

总量使用计算器公式 F(m) = c·n²/(2m) + n·h + m·r，最佳段数 m* = n·sqrt(c/2r)，最优整数段数限制在 1 到 n。连续最优点的相邻整数分别代入 F，取成本较小者。

所有成本项统一折算为未缓存输入 token 等价。示例中新增历史在后续轮次通过缓存读取，所以拟合得到的成本增长 c 为 200、250、300，--c 指定的原始增长也按缓存读取价折算。h 表示交接文件的原始长度，每轮重读按缓存价计入公式，默认相当于 200 个未缓存输入 token。缓存写入与固定未缓存部分不随轮次增长，拟合时仍按各自费率计入逐轮输入成本。

r 表示每段的一次性写交接文件与启动代价。默认预算由 2000 个输出 token 按 5 倍折成 10000 个输入 token 等价，加上启动时读取项目约定、相关代码与重新熟悉任务的多次调用合计 70000 个输入 token 等价，得到 80000。这是示例预算，可用 --r 替换；h 只计算每轮重读，r 中的写文件成本只计一次。

节省比例以同一模型的一段基准 F(1) 为分母，包含该段的启动与交接读取成本。按最优整数段数计算的比例是模型估算。练习 1 的每 20 轮分段按各段实际长度计算 c·各段轮数平方和/2 + n·h + m·r，末段不足 20 轮时照实计入。
