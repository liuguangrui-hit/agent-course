# 项目约定

- 数字从 ledger.csv、conversations.csv 和 review.md 取，preview/decisions.md 由 calc.py 生成。
- 实质意见采纳以 review.md 的作者决定为准，账本只汇总。
- 中文与英文版保持相同结构，代码和数据逐字一致，说明分别用中文与英文。
