# 审稿逐条记录

这是示例审稿记录，对应示例账本里的八篇稿件和四轮复查。每行记录该次审稿的新意见及采纳决定。

实质意见指会改变方法、结果或论文结论的意见。文字润色单独记录。采纳决定由示例中的作者作出，adopted 是整次产出的采用状态，substantive 只统计实质意见。

## 第 1 轮

| 账本 item_id | 新意见 | 意见类型 | 采纳 | 其他采用内容 |
|---|---|---|---|---|
| review-A-1 | 补充固定随机种子的说明 | substantive | yes | none |
| review-B-1 | 修正验证集混入测试样本的问题 | substantive | yes | none |
| review-C-1 | 补齐基线的同等计算预算 | substantive | yes | none |
| review-D-1 | 加入重复运行与误差范围 | substantive | yes | none |
| review-E-1 | 修正表格中归一化前后的指标混用 | substantive | yes | none |
| review-F-1 | 增加低噪声条件下的对照 | substantive | yes | none |
| review-G-1 | 明确缺失数据的筛选规则 | substantive | yes | none |
| review-H-1 | 收窄超出实验范围的结论 | substantive | yes | none |

## 第 2 轮

| 账本 item_id | 新意见 | 意见类型 | 采纳 | 其他采用内容 |
|---|---|---|---|---|
| review-A-2 | 补充新划分下的消融结果 | substantive | yes | none |
| review-B-2 | 统一各基线的停止条件 | substantive | yes | none |
| review-C-2 | 补齐计算预算统计口径 | substantive | yes | none |
| review-D-2 | 修正误差范围使用标准差的标注 | substantive | yes | none |
| review-E-2 | 要求增加与当前假设无关的数据集 | substantive | no | 统一标题大小写 |
| review-F-2 | 要求改用与实验条件不符的指标 | substantive | no | 统一标题大小写 |
| review-G-2 | 要求删除已披露的筛选规则 | substantive | no | 统一标题大小写 |
| review-H-2 | 要求恢复超出证据范围的强结论 | substantive | no | 统一标题大小写 |

## 第 3 轮

| 账本 item_id | 新意见 | 意见类型 | 采纳 | 其他采用内容 |
|---|---|---|---|---|
| review-A-3 | 补报消融实验使用的训练预算 | substantive | yes | none |
| review-B-3 | 建议再次改写已清晰的段落，作者保留原文 | wording | no | none |
| review-C-3 | 建议再次改写已清晰的段落，作者保留原文 | wording | no | none |
| review-D-3 | 建议再次改写已清晰的段落，作者保留原文 | wording | no | none |
| review-E-3 | 建议再次改写已清晰的段落，作者保留原文 | wording | no | none |
| review-F-3 | 建议再次改写已清晰的段落，作者保留原文 | wording | no | none |
| review-G-3 | 建议再次改写已清晰的段落，作者保留原文 | wording | no | none |
| review-H-3 | 建议再次改写已清晰的段落，作者保留原文 | wording | no | none |

## 第 4 轮

| 账本 item_id | 新意见 | 意见类型 | 采纳 | 其他采用内容 |
|---|---|---|---|---|
| review-A-4 | 复查前轮修改，未提出新意见 | none | no | none |
| review-B-4 | 复查前轮修改，未提出新意见 | none | no | none |
| review-C-4 | 复查前轮修改，未提出新意见 | none | no | none |
| review-D-4 | 复查前轮修改，未提出新意见 | none | no | none |
| review-E-4 | 复查前轮修改，未提出新意见 | none | no | none |
| review-F-4 | 复查前轮修改，未提出新意见 | none | no | none |
| review-G-4 | 复查前轮修改，未提出新意见 | none | no | none |
| review-H-4 | 复查前轮修改，未提出新意见 | none | no | none |

同一个 item_id 出现至少一条 substantive 且采纳为 yes 时，账本 substantive 记 yes。第二轮后四篇只采用了文字调整，整次 adopted 为 partial，实质意见采纳仍为 no。
