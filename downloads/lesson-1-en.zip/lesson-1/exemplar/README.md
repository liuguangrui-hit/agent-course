Put the exemplar paper here. In class the agent downloads arXiv 1512.03385; afterwards, use a paper you admire.
