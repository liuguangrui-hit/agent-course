# Style table: removing the AI flavour

| Problem | Example | Fix |
|---|---|---|
| Opening with background | In recent years, with the rapid advancement of | Lead with the result |
| Hedges everywhere | to some extent, preliminary results indicate, relatively limited | Cut them; state the evidence boundary once, at the end |
| Telling the reader what to notice | Notably, It should be noted that | Cut; just say it |
| Stock frames | not about replacing X but about Y; In conclusion | State the point directly |
| Claim, then walk it back | an advantage, followed at once by a list of limitations | Make the claim; give limits once, in their own paragraph |
| Listing instead of choosing | every dimension, every exception | Keep the one result that matters most |
| Inflated verbs | garnered significant attention, leveraging, warranting further exploration | Use the plain verb |
| Em dashes for asides | time-consuming — which is | Use a full stop or a comma |
| Scare quotes | "overnight automated tuning" | Drop the quotes |
