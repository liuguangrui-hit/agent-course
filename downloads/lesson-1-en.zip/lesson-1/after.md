In three months, an agent read 4,200 new papers for our group. It recommended 310, and 268 of them were worth a close read: nearly nine in ten.

The setup is simple. Each day the agent screens the new arXiv papers in machine learning, vision and language, and our graduate students read only what it recommends, judging each one. That judgment varies by person, so next we will have a second group look at the same recommendations.
