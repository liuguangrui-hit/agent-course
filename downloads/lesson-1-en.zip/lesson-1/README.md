# Session 1 materials: a short paper to revise

A four-page draft on how training losses cope with noisy labels. The experiment is real: `code/run_experiment.py` reproduces `data/` in about a minute on a laptop (needs numpy). The text and figures are deliberately rough.

- paper/: the LaTeX draft and its figures
- data/: experiment results, one row per run, and test accuracy per epoch
- code/: the experiment and the script that drew the draft figures
- preview/: before.pdf is the draft as compiled; after.pdf is one possible revision, for comparing at the end
- style_table.md: what to fix in text and figures
- AGENTS.md and CLAUDE.md: project conventions read by both agents
- exemplar/: put the exemplar paper here
