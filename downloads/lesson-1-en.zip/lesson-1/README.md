# Session 1 materials

- before.md and after.md: the same content before and after a retell.
- draft.md: the draft you will work on.
- style_table.md: patterns that make text read as AI-written.
- AGENTS.md and CLAUDE.md: project conventions, read by both agents.
- exemplar/: put the exemplar paper here.

The group and all numbers are fictional.
