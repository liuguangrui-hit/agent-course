# Lesson 1 exercise materials: Writing and figures

## Stages of the session

- Preparation: install Python, LaTeX and a PDF renderer in advance, compile the original draft and download the exemplar.
- Class session: restructure the paper, redraw the figures, carry out an independent review and distill a minimal Skill.
- Review and extension: first summarize your draft and trace its numbers, then compare two narrative structures and two ways of selecting seeds, and finally carry out a revision or a transfer test.

Record your preparation checks in preflight.md and your review in review-after-class.md. The session page gives the timing of each activity and the examples for comparison. Complete installations and downloads before class so that the materials are ready for use.

The exercises train three methods: organizing a paper around its central finding, verifying that numbers and figures agree with the source data, and using an independent review tied to a specific version.

The material is a four-page draft on how several training losses perform when labels are noisy. The experiment is real: `code/run_experiment.py` regenerates `data/` in about a minute on a laptop and needs only numpy. The text and figures are deliberately rough.

- paper/: the LaTeX draft and its figures
- data/: experiment results, one row per run, and test accuracy for every epoch
- code/: the experiment code and the script that draws the draft figures
- preview/: before.pdf is the compiled draft; after.pdf is one possible revision, for comparison at the end
- style_table.md: what to correct in the text and figures
- AGENTS.md and CLAUDE.md: project conventions read by both agents
- exemplar/: location for the exemplar paper

Complete the review, independent work and transfer assessment specified on the session page. Any identified core readings are required; remaining extension topics are optional.
