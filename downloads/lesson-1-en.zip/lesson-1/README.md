# Lesson 1 exercise materials: Writing and figures

## The three stages of this lesson

- Before class: install Python, LaTeX and a PDF renderer in advance, compile the original draft and download the exemplar.
- In class: restructure the paper, redraw the figures, do an independent review, and distill a minimal Skill.
- After class: first summarize your draft and trace the numbers, then compare two narrative structures and two ways of selecting seeds, and finally do a revision or a transfer test.

Record your preparation checks in preflight.md and your after-class review in review-after-class.md. The lesson page gives the timing for each activity and examples to compare. Complete installations and downloads before class so the materials are ready to use.

A four-page draft on how several training losses perform when labels are noisy. The experiment is real: `code/run_experiment.py` regenerates `data/` in about a minute on a laptop and needs only numpy. The text and figures are deliberately rough.

- paper/: the LaTeX draft and its figures
- data/: experiment results, one row per run, and test accuracy for every epoch
- code/: the experiment code and the script that draws the draft figures
- preview/: before.pdf is the compiled draft; after.pdf is one possible revision, for comparison at the end
- style_table.md: what to fix in the text and figures
- AGENTS.md and CLAUDE.md: project conventions read by both agents
- exemplar/: put the exemplar paper here
