# Project conventions

- draft.md is the original. Do not edit it.
- Save each version as a new file: v1.md, v2.md, v3.md.
