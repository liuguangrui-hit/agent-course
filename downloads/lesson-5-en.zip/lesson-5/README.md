# Lesson 5 materials: orchestration safety

Add project permissions, a sandbox, and two automatic checks to the lesson 4 workbench.

- [settings.example.json](settings.example.json): the Claude Code starter, with empty allow and deny lists.
- [config.example.toml](config.example.toml): the Codex starter for write boundaries and disabled command networking.
- [hooks/check_tex.py](hooks/check_tex.py): check numbers after editing a .tex file under paper/.
- [hooks/pre_push_secrets.sh](hooks/pre_push_secrets.sh): scan pending commits before pushing one branch.
- [code/check_numbers.py](code/check_numbers.py): the lesson 1 reference answer's number checker, using only the Python standard library.
- data/: the original experiment results needed by the checker, [results.csv](data/results.csv) and [curves.csv](data/curves.csv).
- [code/test_hooks.py](code/test_hooks.py): rerun branch checks with synthetic events and benign commits.
- [.env.example](.env.example): environment variable names with empty values; copy to .env and fill them yourself.
- [.gitignore](.gitignore): keep .env out of Git.
- [preview/](preview/README.md): the completed configuration and recorded verification to view in class.
- [AGENTS.md](AGENTS.md): stable workbench conventions.
- [CLAUDE.md](CLAUDE.md): tell Claude Code to read the same conventions.

## View the preview, then fill the starters

Read preview/ first. Copy the example files to `.claude/settings.json` and `.codex/config.toml` in your workbench. Put hooks/ at the workbench root. JSON does not support comments, so field explanations belong here. Put blocked operations in permissions.deny and routine commands in permissions.allow. Deny takes precedence when both match. The empty lists are for the exercise; existing user and managed settings also merge into the effective configuration. Claude Code loads project Hooks after you trust the project.

Follow the task card: list the commands you actually use, then fill the table. preview/settings.json allows git commit, push, status, diff, and log, plus uv run, ssh lab, and gh. Read(./.env) in the deny list prevents the Agent from directly reading .env; scripts load it at startup. autoAllowBashIfSandboxed is false so commands outside the table still enter the permission flow. allowUnsandboxedCommands is false to disable retries outside the sandbox. The ssh lab:* entry in excludedCommands runs ssh lab outside the sandbox, where ssh uses its own private key. failIfUnavailable is true so startup stops when sandbox dependencies are missing.

The completed configuration sets `sandbox.network.strictAllowlist` to true to reject sandboxed connections to unlisted domains. This field has no effect in a project settings file. It needs user settings, managed settings, or the command-line `--settings` option. For the exercise, copy preview/settings.json to `.claude/settings.json` in the workbench and start from the workbench root:

```sh
claude --settings .claude/settings.json
```

This loads the domain list and ssh exception from the same command-line configuration. Domain restrictions apply to sandboxed commands. The ssh lab exception runs outside the sandbox; manage permissions on the server separately.

The Codex starter uses workspace-write and on-request. An empty writable_roots list adds no writable directories. Both exclude fields remove default temporary-directory write access. network_access is false, so command networking needs separate configuration or approval. Codex loads project configuration after you trust the project. Rules for commands outside the sandbox use `.rules` files. This TOML sets the sandbox and approval policy.

## Connect the checks

hooks/check_tex.py reads JSON from stdin and takes the edited path from tool_input.file_path. It calls `code/check_numbers.py` only for .tex files under the workbench paper/ directory. The checker is copied unchanged from `paper/v2/cases/lesson-1-answers/en/code/check_numbers.py`, the lesson 1 reference answer. Copy code/check_numbers.py and both CSV files in data/ to the same locations in your workbench. Run `python3 code/check_numbers.py paper/main.tex` from the workbench root. The CSV files are also unchanged copies from the reference answer and contain the actual lesson 1 experiment results. The checker accepts one .tex path relative to the workbench root, exits 0 on success, and exits nonzero with a reason on a mismatch. The Hook forwards failures to stderr and exits 2 so Claude sees the reason. The edit has already happened.

hooks/pre_push_secrets.sh needs Python 3, Git, and gitleaks. It supports `git push`, `git push origin main`, `git push -u origin main`, and `git push origin HEAD:main`, including git -C. Run the push as a standalone command, one branch at a time. The script reads the destination branch tip from the actual remote and scans the range from that tip to the local commit. A new branch or a remote object missing locally triggers a scan of the source history. Reports redact secret values. Findings, scanner failures, and timeouts exit 2 so PreToolUse blocks the push. This is a Claude Code tool Hook. Connect a Git pre-push Hook separately for pushes made manually in a terminal.

The preview lists github.com, arxiv.org, and api.openalex.org as specified in the task card. Launching with --settings as shown above rejects connections to unlisted domains. The Claude sandbox also allows writes to temporary directories by default. Add api.github.com in the same settings layer when required by gh commands.

## Rerun verification

Install gitleaks, then run from this materials directory:

```sh
python3 code/test_hooks.py
```

The program sends synthetic stdin events, creates a temporary local repository, scans benign commits with real gitleaks, and tests blocking exit codes with a scanner double. It prints the results. preview/verification.json preserves executed checks for both language versions of the initial materials.

Fields were checked against [Claude settings](https://code.claude.com/docs/en/settings), [sandboxing](https://code.claude.com/docs/en/sandboxing), [Hooks](https://code.claude.com/docs/en/hooks), [Codex configuration](https://developers.openai.com/codex/config-reference/), and [Codex rules](https://developers.openai.com/codex/rules/). The scan-range syntax comes from the [gitleaks documentation](https://github.com/gitleaks/gitleaks).
