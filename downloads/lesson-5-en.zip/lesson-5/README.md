# Lesson 5 exercise materials: Safety controls

## Stages of the session

- Preparation: check Python, Git, Bash and gitleaks, download the required components and back up your configuration. Do not enable the finished permission table.
- Class session: draw the role capability table, configure boundaries, test allowed and denied actions, then check Hook coverage.
- Review and extension: first redraw the information flow, then distinguish a denial at one entry point from process isolation, and finally retest with another entry point or execution environment.

Record your preparation checks in preflight.md and your review in review-after-class.md. The session page gives the timing of each activity and the examples for comparison. Complete installations and downloads before class so that the materials are ready for use.

The materials add project permission configuration, a sandbox and two automatic checks to the Lesson 4 setup. The exercises train the analysis of trust boundaries, the assignment of permissions by role and the verification of boundaries through behavioral tests at more than one entry point.

- [settings.example.json](settings.example.json): starting point for the Claude Code permission table, with allow and deny both empty.
- [config.example.toml](config.example.toml): starting point for the Codex project configuration, limiting the write scope and disabling network access for commands.
- [hooks/check_tex.py](hooks/check_tex.py): checks the numbers after a .tex file under paper/ is edited.
- [hooks/pre_push_secrets.sh](hooks/pre_push_secrets.sh): scans the commits to be pushed before a single-branch push.
- [code/check_numbers.py](code/check_numbers.py): the number checker from the Lesson 1 reference answers, using only the Python standard library.
- data/: the raw experiment results the checker needs, [results.csv](data/results.csv) and [curves.csv](data/curves.csv).
- [code/test_hooks.py](code/test_hooks.py): reruns the branch tests with fake event input and ordinary commits.
- [.env.example](.env.example): starting point for environment variable names, with values left empty; copy it to .env and fill it in yourself.
- [.gitignore](.gitignore): makes Git ignore .env.
- [preview/](preview/README.md): the complete configuration and actual verification records to examine first in class.
- [AGENTS.md](AGENTS.md): the stable conventions of the setup.
- [CLAUDE.md](CLAUDE.md): makes Claude Code read the same conventions.

## Examining the example and configuring your setup

Before class, only read the materials and make backups; the configuration below is carried out in class after roles have been assigned. Read preview/ first, then copy the two example files to the setup's `.claude/settings.json` and `.codex/config.toml`. Place hooks/ at the root of the setup. JSON does not support comments, so the field notes are given here. `permissions.deny` holds deny rules and `permissions.allow` holds rules for common commands; when both match, deny takes precedence. The empty arrays are to be filled in during the exercise, and existing user configuration and managed configuration also take part in the merge. Claude Code loads a project's Hooks only after the project is trusted.

Following the task card on the session page, first list the commands actually used, then fill in the table. preview/settings.json allows git commit, push, status, diff and log, and also allows uv run, ssh lab and gh. Read(./.env) in the deny list stops the agent from reading .env directly; scripts load it themselves at startup. The sandbox's autoAllowBashIfSandboxed is set to false, so commands outside the table still go through a permission prompt. allowUnsandboxedCommands is set to false, disabling retries outside the sandbox. ssh lab:* in excludedCommands lets ssh lab run outside the sandbox, with ssh using its own private key. failIfUnavailable is set to true, so startup stops when sandbox components are missing.

The finished example sets `sandbox.network.strictAllowlist` to true, strictly denying sandboxed commands access to domains not on the list. This field does not take effect in a project configuration file; it requires user configuration, managed configuration or `--settings` on the command line. For the exercise, copy preview/settings.json to the setup's `.claude/settings.json` and start from the root of the setup:

```sh
claude --settings .claude/settings.json
```

In this way the allowlist and the ssh exception are loaded from the same command-line configuration. Domain restrictions apply only to commands in the sandbox. The ssh lab exception runs outside the sandbox, and server-side permissions are managed separately.

The Codex starting point uses workspace-write and on-request. writable_roots is empty, meaning there are no additional writable directories; the two exclude fields remove write permission for the default temporary directories. network_access is false, so commands that need the network must be configured separately or request approval. Codex loads project configuration only after the project is trusted, and rules for commands outside the sandbox use a `.rules` file. This TOML file sets the sandbox and approval policy.

## Connecting the two checks

`hooks/check_tex.py` reads JSON from stdin and takes the file path from tool_input.file_path. Only .tex files under the setup's paper/ call `code/check_numbers.py`. The checker is copied unchanged from `code/check_numbers.py` in the Lesson 1 reference answers. Place code/check_numbers.py and the two CSVs in data/ at the same locations in the setup, and run `python3 code/check_numbers.py paper/main.tex` from its root. data/ is also copied unchanged from the reference answers and holds the real Lesson 1 experiment results. The checker takes one .tex path relative to the setup root, exits 0 on success, and exits nonzero with the reason when numbers do not match. The Hook writes the failure reason to stderr and exits 2, so Claude sees the reason; the file edit has already taken place.

`hooks/pre_push_secrets.sh` requires Python 3, Git and gitleaks. It supports `git push`, `git push origin main`, `git push -u origin main` and `git push origin HEAD:main`, and also supports git -C. Run each push separately, one branch at a time. The script reads the target remote's current branch position and scans the range from there to the local commit; for a new branch, or when the remote objects are missing locally, it scans the source branch's history. The scan report masks secret values. A suspected secret, a scan failure or a timeout all exit 2, and PreToolUse blocks the push. It is a Claude Code tool Hook; a git push run manually on the command line requires Git's own pre-push Hook to be connected separately.

Following the session page's task card, preview's allowedDomains contains github.com, arxiv.org and api.openalex.org. When the agent is started with the --settings option above, connections to domains not on the list are denied. The Claude sandbox also allows writing to temporary directories by default. api.github.com, which gh commonly uses, must be added to the same list according to the calls actually made.

## Rerunning the verification

After installing gitleaks, run in this materials directory:

```sh
python3 code/test_hooks.py
```

The program feeds fake events through stdin, creates a temporary local repository, scans ordinary commits, then uses a scanner stand-in to test the exit code when a problem is found. Results are written to the terminal. The existing preview/verification.json keeps the actual Chinese and English run results from the first version of the materials.

Fields were checked against [Claude settings](https://code.claude.com/docs/en/settings), [sandboxing](https://code.claude.com/docs/en/sandboxing), [Hooks](https://code.claude.com/docs/en/hooks), [Codex configuration](https://developers.openai.com/codex/config-reference/) and [Codex rules](https://developers.openai.com/codex/rules/). The specification of the scan range follows the [gitleaks documentation](https://github.com/gitleaks/gitleaks).

## Notes on boundaries

The existing verification script tests the Hook branches and the scan entry point; it does not verify the operating-system sandbox of the current desktop app or CLI. After enabling your own configuration, run harmless behavioral tests of allowed and denied actions separately. The script-type commands allowed in the example and SSH outside the sandbox are both broad capabilities; restrict them according to your own role table.

A Read deny rule constrains only the corresponding tool entry point; any script run by the same user may read environment variables or local credentials. .gitignore only prevents ordinary commits. When credentials must be isolated, use process isolation, a separate account or a restricted service.

Check Hook and sandbox fields against the vendors' current documentation. Place the full check before external publication at a fixed publication entry point, and record the version of the product checked. Tests use invalid samples or scanner stand-ins, never real credentials.

Complete the review, independent work and transfer assessment specified on the session page. Any identified core readings are required; remaining extension topics are optional.
