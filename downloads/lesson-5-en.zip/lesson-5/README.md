# Lesson 5 exercise materials: Safety controls

## The three stages of this lesson

- Before class: check Python, Git, Bash and gitleaks, download the needed components and back up your configuration. Do not enable the finished permission table.
- In class: draw the role capability table, configure boundaries, test allowed and denied actions, then check Hook coverage.
- After class: first redraw the information flow, then tell a denial at one entry point apart from process isolation, and finally retest with another entry point or execution environment.

Record your preparation checks in preflight.md and your after-class review in review-after-class.md. The lesson page gives the timing for each activity and examples to compare. Complete installations and downloads before class so the materials are ready to use.

Add project permission configuration, a sandbox and two automatic checks to the Lesson 4 workbench.

- [settings.example.json](settings.example.json): starting point for the Claude Code permission table, with allow and deny both empty.
- [config.example.toml](config.example.toml): starting point for the Codex project configuration, limiting the write scope and turning off network access for commands.
- [hooks/check_tex.py](hooks/check_tex.py): checks the numbers after a .tex file under paper/ is edited.
- [hooks/pre_push_secrets.sh](hooks/pre_push_secrets.sh): scans the commits to be pushed before a single-branch push.
- [code/check_numbers.py](code/check_numbers.py): the number checker from the Lesson 1 reference answers, using only the Python standard library.
- data/: the raw experiment results the checker needs, [results.csv](data/results.csv) and [curves.csv](data/curves.csv).
- [code/test_hooks.py](code/test_hooks.py): reruns the branch tests with fake event input and ordinary commits.
- [.env.example](.env.example): starting point for environment variable names, with values left empty; copy it to .env and fill it in yourself.
- [.gitignore](.gitignore): makes Git ignore .env.
- [preview/](preview/README.md): the complete configuration and actual verification records to look at first in class.
- [AGENTS.md](AGENTS.md): the workbench's stable conventions.
- [CLAUDE.md](CLAUDE.md): makes Claude Code read the same conventions.

## Inspect the example and configure your workbench

Before class, only read the materials and make backups; the configuration below is done in class after roles are divided. Read preview/ first, then copy the two example files to the workbench's `.claude/settings.json` and `.codex/config.toml`. Put hooks/ at the workbench root. JSON does not support comments, so the field notes are here. `permissions.deny` holds deny rules and `permissions.allow` holds rules for common commands; when both match, deny wins. The empty arrays are for you to fill in during the exercise, and existing user configuration and managed configuration also take part in the merge. Claude Code loads a project's Hooks only after you trust the project.

Following the task card on the course page, first list the commands you actually use, then fill in the table. preview/settings.json allows git commit, push, status, diff and log, and also allows uv run, ssh lab and gh. Read(./.env) in the deny list stops the agent from reading .env directly; scripts load it themselves when they start. The sandbox's autoAllowBashIfSandboxed is set to false, so commands outside the table still go through a permission prompt. allowUnsandboxedCommands is set to false, turning off retries outside the sandbox. ssh lab:* in excludedCommands lets ssh lab run outside the sandbox, with ssh using its own private key. failIfUnavailable is set to true, so startup stops when sandbox components are missing.

The finished product sets `sandbox.network.strictAllowlist` to true, strictly denying sandboxed commands access to domains not on the list. This field does not take effect in a project configuration file; it needs user configuration, managed configuration or `--settings` on the command line. For the exercise, copy preview/settings.json to the workbench's `.claude/settings.json` and start from the workbench root:

```sh
claude --settings .claude/settings.json
```

This way the allowlist and the ssh exception load from the same command-line configuration. Domain restrictions apply only to commands in the sandbox. The ssh lab exception runs outside the sandbox, and server-side permissions are managed separately.

The Codex starting point uses workspace-write and on-request. writable_roots is empty, meaning there are no extra writable directories; the two exclude fields remove write permission for the default temporary directories. network_access is false, so commands that need the network must be configured separately or request approval. Codex loads project configuration only after you trust the project, and rules for commands outside the sandbox use a `.rules` file. This TOML file is for setting the sandbox and approval policy.

## Connect the two checks

`hooks/check_tex.py` reads JSON from stdin and takes the file path from tool_input.file_path. Only .tex files under the workbench's paper/ call `code/check_numbers.py`. The checker is copied unchanged from `code/check_numbers.py` in the Lesson 1 reference answers. Put code/check_numbers.py and the two CSVs in data/ in the same places in the workbench, and run `python3 code/check_numbers.py paper/main.tex` from the workbench root. data/ is also copied unchanged from the reference answers and holds the real Lesson 1 experiment results. The checker takes one .tex path relative to the workbench, exits 0 on success, and exits nonzero with the reason when numbers do not match. The Hook writes the failure reason to stderr and exits 2, so Claude sees the reason; the file edit has already happened.

`hooks/pre_push_secrets.sh` needs Python 3, Git and gitleaks. It supports `git push`, `git push origin main`, `git push -u origin main` and `git push origin HEAD:main`, and also supports git -C. Run each push on its own, one branch at a time. The script reads the target remote's current branch position and scans the range from there to the local commit; for a new branch, or when the remote objects are missing locally, it scans the source branch's history. The scan report hides secret values. A suspected secret, a scan failure or a timeout all exit 2, and PreToolUse blocks the push. It is a Claude Code tool Hook; a git push run by hand on the command line needs Git's own pre-push Hook connected separately.

Following the course page's task card, preview's allowedDomains contains github.com, arxiv.org and api.openalex.org. When started with the --settings above, connections to domains not on the list are denied. The Claude sandbox also allows writing to temporary directories by default. api.github.com, which gh commonly uses, needs to be added to the same list according to the calls you actually make.

## Rerun the verification

After installing gitleaks, run in this materials directory:

```sh
python3 code/test_hooks.py
```

The program feeds fake events through stdin, creates a temporary local repository, actually scans ordinary commits, then uses a scanner stand-in to test the exit code when a problem is found. Results are written to the terminal. The existing preview/verification.json keeps the actual Chinese and English run results from the first version of the materials.

Fields were checked against [Claude settings](https://code.claude.com/docs/en/settings), [sandboxing](https://code.claude.com/docs/en/sandboxing), [Hooks](https://code.claude.com/docs/en/hooks), [Codex configuration](https://developers.openai.com/codex/config-reference/) and [Codex rules](https://developers.openai.com/codex/rules/). The way the scan range is written comes from the [gitleaks documentation](https://github.com/gitleaks/gitleaks).

## notes on boundaries

The existing verification script tests the Hook branches and the scan entry point; it does not mean the operating-system sandbox of the current desktop app or CLI has been verified. After enabling your own configuration, run harmless behavioral tests of allowed and denied actions separately. The script-type commands allowed in the example and SSH outside the sandbox are both broad capabilities; tighten them according to your own role table.

A Read deny rule constrains only the corresponding tool entry point; any script run by the same user may read environment variables or local credentials. .gitignore only prevents ordinary commits. When credentials need isolating, use process isolation, a separate account or a restricted service.

Check Hook and sandbox fields against the vendors' current docs. Put the full check before external publication at a fixed publication entry point, and record the version of the product checked. Tests use invalid samples or scanner stand-ins, never real credentials.
