# Project conventions
- Keep project configuration in .claude/settings.json and .codex/config.toml.
- Check .tex edits under paper/ with code/check_numbers.py.
- Scan pending commits before pushing and fix failed checks.
- Keep secret values in the keychain or a Git-ignored .env file.
