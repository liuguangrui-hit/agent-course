#!/usr/bin/env python3
"""Verify the hooks with synthetic event JSON and benign temporary repositories."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time


MATERIAL = Path(__file__).resolve().parents[1]
CASES = []


def run(args, cwd, env=None):
    return subprocess.run(args, cwd=cwd, env=env, text=True, capture_output=True, check=True)


def check(name, hook, event, expected, cwd, env, contains=None):
    started = time.perf_counter()
    command = [sys.executable, str(hook)] if hook.suffix == ".py" else ["sh", str(hook)]
    result = subprocess.run(
        command, input=json.dumps(event) if isinstance(event, dict) else event,
        cwd=cwd, env=env, text=True, capture_output=True, timeout=30,
    )
    assert result.returncode == expected, (name, result.returncode, result.stderr)
    if contains:
        assert contains in result.stderr, (name, result.stderr)
    CASES.append({"case": name, "exit_code": result.returncode,
                  "elapsed_seconds": round(time.perf_counter() - started, 6)})


def main():
    real_scanner = shutil.which("gitleaks")
    if not real_scanner:
        raise SystemExit("Install gitleaks and put it on PATH before running this verification.")
    version = subprocess.run([real_scanner, "version"], capture_output=True, text=True, check=True).stdout.strip()
    with tempfile.TemporaryDirectory(prefix="hook-check-", dir=MATERIAL) as temporary:
        root = Path(temporary)
        repo, remote, tools = root / "workbench", root / "remote.git", root / "tools"
        for path in (repo, tools, repo / "paper", repo / "code"):
            path.mkdir(parents=True, exist_ok=True)
        checker = repo / "code/check_numbers.py"
        checker.write_text(
            '# Test fixture: returns a controlled result; no research data.\n'
            'import os, sys\n'
            'from pathlib import Path\n'
            'assert Path(sys.argv[1]).is_file()\n'
            'Path(os.environ["HOOK_TEST_CHECKED"]).write_text(sys.argv[1])\n'
            'if os.environ.get("HOOK_TEST_CHECK_FAIL"):\n'
            '    print("Number mismatch in test fixture.", file=sys.stderr)\n'
            '    sys.exit(1)\n'
        )
        (repo / "paper/main.tex").write_text('% Benign hook test fixture.\n')
        (repo / "notes.tex").write_text('% Benign hook test fixture.\n')
        (repo / "paper/notes.md").write_text('Benign hook test fixture.\n')
        env = {**os.environ, "CLAUDE_PROJECT_DIR": str(repo),
               "HOOK_TEST_CHECKED": str(root / "checked-path.txt")}
        tex_hook = MATERIAL / "hooks/check_tex.py"

        def tex(path):
            return {"cwd": str(repo), "tool_name": "Edit", "tool_input": {"file_path": path}}

        check("tex_missing_path", tex_hook, {"tool_input": {}}, 0, repo, env)
        check("tex_other_suffix", tex_hook, tex("paper/notes.md"), 0, repo, env)
        check("tex_outside_paper", tex_hook, tex("notes.tex"), 0, repo, env)
        check("tex_valid_relative", tex_hook, tex("paper/main.tex"), 0, repo, env)
        assert (root / "checked-path.txt").read_text() == "paper/main.tex"
        check("tex_valid_absolute", tex_hook, tex(str(repo / "paper/main.tex")), 0, repo, env)
        check("tex_mismatch", tex_hook, tex("paper/main.tex"), 2, repo,
              {**env, "HOOK_TEST_CHECK_FAIL": "1"}, "Number mismatch")
        checker.rename(repo / "code/check_numbers.saved.py")
        check("tex_missing_checker", tex_hook, tex("paper/main.tex"), 2, repo, env, "Create code/check_numbers.py")
        (repo / "code/check_numbers.saved.py").rename(checker)
        (repo / "paper/link.tex").symlink_to(repo / "notes.tex")
        check("tex_symlink_outside_paper", tex_hook, tex("paper/link.tex"), 0, repo, env)
        check("tex_invalid_json", tex_hook, "{", 2, repo, env, "hook failed")
        (repo / "paper/link.tex").unlink()

        git_env = {**env, "GIT_CONFIG_NOSYSTEM": "1", "GIT_CONFIG_GLOBAL": os.devnull}
        run(["git", "init", "--bare", str(remote)], root, git_env)
        run(["git", "init", "-b", "main"], repo, git_env)
        run(["git", "config", "user.name", "Hook Verification"], repo, git_env)
        run(["git", "config", "user.email", "hooks@example.invalid"], repo, git_env)
        run(["git", "add", "paper", "code", "notes.tex"], repo, git_env)
        run(["git", "commit", "-m", "Add benign baseline"], repo, git_env)
        run(["git", "remote", "add", "origin", str(remote)], repo, git_env)
        run(["git", "push", "-u", "origin", "main"], repo, git_env)
        old = run(["git", "rev-parse", "HEAD"], repo, git_env).stdout.strip()
        (repo / "baseline.txt").write_text('Benign pending commit.\n')
        run(["git", "add", "baseline.txt"], repo, git_env)
        run(["git", "commit", "-m", "Add benign pending commit"], repo, git_env)
        tip = run(["git", "rev-parse", "HEAD"], repo, git_env).stdout.strip()
        scanner = tools / "gitleaks"
        scanner.write_text(
            '#!/usr/bin/env python3\n'
            '# Test fixture: controlled scanner status, no secret samples.\n'
            'import json, os, sys\n'
            'from pathlib import Path\n'
            'Path(os.environ["HOOK_TEST_SCAN_ARGS"]).write_text(json.dumps(sys.argv[1:]))\n'
            'status = int(os.environ.get("HOOK_TEST_SCAN_EXIT", "0"))\n'
            'if status:\n'
            '    print("Controlled scanner failure; no secret samples.", file=sys.stderr)\n'
            'sys.exit(status)\n'
        )
        scanner.chmod(0o755)
        scan_log = root / "scan-args.json"
        mock_env = {**git_env, "PATH": str(tools) + os.pathsep + os.environ["PATH"],
                    "HOOK_TEST_SCAN_ARGS": str(scan_log)}
        push_hook = MATERIAL / "hooks/pre_push_secrets.sh"

        def push(command):
            return {"cwd": str(repo), "tool_name": "Bash", "tool_input": {"command": command}}

        check("push_non_push", push_hook, push("git status"), 0, repo, mock_env)
        check("push_clean_mock", push_hook, push("git push origin main"), 0, repo, mock_env)
        scan_args = json.loads(scan_log.read_text())
        assert "--log-opts=" + old + ".." + tip in scan_args
        pending_count = int(run(["git", "rev-list", "--count", old + ".." + tip], repo, git_env).stdout)
        check("push_findings_mock", push_hook, push("git push origin main"), 2, repo,
              {**mock_env, "HOOK_TEST_SCAN_EXIT": "1"}, "Push blocked")
        check("push_scanner_error_mock", push_hook, push("git push origin main"), 2, repo,
              {**mock_env, "HOOK_TEST_SCAN_EXIT": "7"}, "Push blocked")
        check("push_default", push_hook, push("git push"), 0, repo, mock_env)
        check("push_set_upstream", push_hook, push("git push -u origin main"), 0, repo, mock_env)
        check("push_refspec", push_hook, push("git push origin HEAD:main"), 0, repo, mock_env)
        check("push_git_C", push_hook, push("git -C . push origin main"), 0, repo, mock_env)
        check("push_new_branch", push_hook, push("git push origin HEAD:new-branch"), 0, repo, mock_env)
        assert "--log-opts=" + tip in json.loads(scan_log.read_text())
        check("push_multiple_branches", push_hook, push("git push origin main other"), 2, repo, mock_env)
        check("push_unknown_remote", push_hook, push("git push missing main"), 2, repo, mock_env)
        check("push_invalid_json", push_hook, "{", 2, repo, mock_env)
        # A real scan on benign commits verifies the gitleaks CLI invocation.
        check("push_clean_real_gitleaks", push_hook, push("git push origin main"), 0, repo, git_env)
        run(["git", "push", "origin", "main"], repo, git_env)
        if scan_log.exists():
            scan_log.unlink()
        check("push_no_pending_commits", push_hook, push("git push origin main"), 0, repo,
              {**mock_env, "HOOK_TEST_SCAN_EXIT": "1"})
        assert not scan_log.exists()

    starter = json.loads((MATERIAL / "settings.example.json").read_text())
    preview = json.loads((MATERIAL / "preview/settings.json").read_text())
    assert starter == {"permissions": {"deny": [], "allow": []}}
    report = {
        "verification_kind": "Executed hooks with synthetic stdin and benign Git commits; finding branch uses a scanner test double.",
        "gitleaks_version": version,
        "json_files_parsed": 2,
        "deny_rules": len(preview["permissions"]["deny"]),
        "allow_rules": len(preview["permissions"]["allow"]),
        "allowed_domains": len(preview["sandbox"]["network"]["allowedDomains"]),
        "hook_events": len(preview["hooks"]),
        "pending_commits_in_test": pending_count,
        "cases_passed": len(CASES),
        "maximum_case_seconds": max(case["elapsed_seconds"] for case in CASES),
        "cases": CASES,
    }
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
