# Completed configuration and verification

[settings.json](settings.json) is the complete Claude Code configuration to view in class. [verification.json](verification.json) preserves executed tests for both language versions of the initial materials.

| Item | Value | Source |
|---|---:|---|
| Deny rules | 5 | settings.json permissions.deny |
| Allow rules | 8 | settings.json permissions.allow |
| Network domains | 3 | settings.json sandbox.network.allowedDomains |
| Hook events | 2 | settings.json hooks |
| Passed cases per language in the initial version | 23 | Executed code/test_hooks.py |
| Pending commits in the test repository | 1 | Executed git rev-list over the remote-to-local range |
| Slowest Chinese-version case in seconds | 0.462950 | verification.json zh.maximum_case_seconds |
| Slowest English-version case in seconds | 0.378229 | verification.json en.maximum_case_seconds |

The real scan used gitleaks 8.30.1 on benign commits in a temporary repository. A scanner double returned failure for the findings branch. The tests contain no secret samples. Values come from file parsing, Git counts, and process timing.

The configuration includes the Read(./.env) deny rule, the ssh lab:* sandbox exception, and sandbox.network.strictAllowlist set to true. Copy settings.json to `.claude/settings.json` in the workbench, then run `claude --settings .claude/settings.json` from its root. strictAllowlist has no effect in the project settings layer. Loading through --settings makes sandboxed commands reject connections to unlisted domains; see the [official network isolation reference](https://code.claude.com/docs/en/sandboxing#network-isolation).

Use hooks/ and the included code/check_numbers.py and data/ at the workbench root. The number checker comes from the lesson 1 reference answer; see the [materials README](../README.md) for its interface. Case counts and timings in the table preserve the initial run; configuration counts are read from the current settings.json. Follow the lesson exercise to test loading and sandbox boundaries inside Claude Code on your workbench.
