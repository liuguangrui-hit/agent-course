#!/usr/bin/env python3
"""Check numbers after an Edit or Write under paper/."""
import json
import os
from pathlib import Path
import subprocess
import sys


def fail(message):
    print(message, file=sys.stderr)
    return 2


def main():
    try:
        event = json.load(sys.stdin)
        tool_input = event.get("tool_input", {})
        file_path = tool_input.get("file_path", "")
        if not isinstance(file_path, str) or not file_path:
            return 0
        root = Path(os.environ.get("CLAUDE_PROJECT_DIR") or event.get("cwd") or ".").resolve()
        path = Path(file_path).expanduser()
        if not path.is_absolute():
            path = Path(event.get("cwd") or root) / path
        path = path.resolve()
        try:
            path.relative_to(root / "paper")
        except ValueError:
            return 0
        if path.suffix != ".tex":
            return 0
        checker = root / "code" / "check_numbers.py"
        if not checker.is_file():
            return fail("Create code/check_numbers.py from the lesson 1 reference answer, then retry the check.")
        # The checker accepts one project-relative .tex path and returns nonzero on mismatch.
        result = subprocess.run(
            [sys.executable, str(checker), str(path.relative_to(root))],
            cwd=root, capture_output=True, text=True, timeout=5,
        )
        if result.returncode:
            reason = (result.stderr + result.stdout).strip() or "Number checker returned a failure."
            return fail(reason + "\nCorrect the numbers and run the check again.")
        return 0
    except subprocess.TimeoutExpired:
        return fail("Number check exceeded its 5-second budget. Move slow work to the closing routine.")
    except (OSError, ValueError, AttributeError, TypeError) as error:
        return fail("Number-check hook failed: " + str(error))


if __name__ == "__main__":
    sys.exit(main())
