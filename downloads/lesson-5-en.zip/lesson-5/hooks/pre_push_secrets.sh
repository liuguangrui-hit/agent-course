#!/bin/sh
# Preserve hook JSON on fd 3 while Python reads the program from stdin.
exec 3<&0
exec python3 - <<'PY'
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import subprocess
import sys


def block(message):
    print(message, file=sys.stderr)
    sys.exit(2)


def git(args, cwd, check=True):
    result = subprocess.run(
        ["git", *args], cwd=cwd, capture_output=True, text=True, timeout=3,
        env={**os.environ, "GIT_TERMINAL_PROMPT": "0"},
    )
    if check and result.returncode:
        block("Cannot determine pending commits. Check the remote and branch, then retry.")
    return result.stdout.strip()


def main():
    event = json.load(os.fdopen(3))
    command = event.get("tool_input", {}).get("command", "")
    words = shlex.split(command)
    if not words:
        return
    # Keep the exercise focused on a standalone push of one branch.
    if Path(words[0]).name != "git":
        if re.search(r"\bgit\b.*\bpush\b", command, re.S):
            block("Run git push as a standalone command so its commits can be checked.")
        return
    cwd = Path(event.get("cwd") or os.environ.get("CLAUDE_PROJECT_DIR") or ".").resolve()
    index = 1
    while index < len(words) and words[index] == "-C":
        if index + 1 >= len(words):
            block("git -C needs a directory.")
        cwd = (cwd / words[index + 1]).resolve()
        index += 2
    if index >= len(words) or words[index] != "push":
        if "push" in words[index:]:
            block("Use git push or git -C DIRECTORY push for this exercise.")
        return
    args = words[index + 1:]
    if any(token in command for token in (";", "&&", "||", "|", "`", "$", "\n", ">", "<")):
        block("Run git push as a standalone command with literal arguments.")
    positional = []
    for arg in args:
        if arg in ("-u", "--set-upstream", "--dry-run", "-n", "--verbose", "-v", "--quiet", "-q"):
            continue
        if arg.startswith("-"):
            block("Use a single-branch git push for this exercise.")
        positional.append(arg)
    if len(positional) > 2:
        block("Push one branch at a time for this exercise.")
    repo = Path(git(["rev-parse", "--show-toplevel"], cwd))
    branch = git(["symbolic-ref", "--quiet", "--short", "HEAD"], repo, check=False)
    if positional:
        remote = positional[0]
    else:
        remote = git(["config", "--get", "branch." + branch + ".pushRemote"], repo, False)
        remote = remote or git(["config", "--get", "remote.pushDefault"], repo, False)
        remote = remote or git(["config", "--get", "branch." + branch + ".remote"], repo, False)
        if not remote:
            remotes = git(["remote"], repo).splitlines()
            remote = "origin" if "origin" in remotes else (remotes[0] if len(remotes) == 1 else "")
    if remote not in git(["remote"], repo).splitlines():
        block("Choose a configured remote: git push REMOTE BRANCH.")
    urls = git(["remote", "get-url", "--push", "--all", remote], repo).splitlines()
    if len(urls) != 1:
        block("Use a remote with one push URL for this exercise.")
    if len(positional) == 2:
        refspec = positional[1]
        if refspec.startswith("+") or "*" in refspec:
            block("Use a single branch without a forced refspec.")
        source, separator, target = refspec.partition(":")
        target = target if separator else source
        if not source or not target or target == "HEAD":
            block("Name the destination branch: git push REMOTE HEAD:BRANCH.")
    else:
        if git(["config", "--get-all", "remote." + remote + ".push"], repo, False):
            block("Name one branch explicitly: git push REMOTE BRANCH.")
        mode = git(["config", "--get", "push.default"], repo, False) or "simple"
        upstream_remote = git(["config", "--get", "branch." + branch + ".remote"], repo, False)
        merge = git(["config", "--get", "branch." + branch + ".merge"], repo, False)
        if not branch or mode not in ("simple", "current", "upstream"):
            block("Name one branch explicitly: git push REMOTE BRANCH.")
        source, target = branch, branch
        if mode == "upstream" or (mode == "simple" and remote == upstream_remote):
            if not merge or (mode == "simple" and merge != "refs/heads/" + branch):
                block("Name the destination branch explicitly.")
            target = merge
    if not target.startswith("refs/"):
        target = "refs/heads/" + target
    if not target.startswith("refs/heads/"):
        block("Push one branch for this exercise.")
    git(["check-ref-format", target], repo)
    if git(["config", "--bool", "--get", "remote." + remote + ".mirror"], repo, False) == "true":
        block("Use a non-mirror remote for this exercise.")
    if git(["config", "--bool", "--get", "push.followTags"], repo, False) == "true":
        block("Disable push.followTags or check tags separately before this exercise.")
    tip = git(["rev-parse", "--verify", "--end-of-options", source + "^{commit}"], repo)
    # Read the actual destination rather than trusting a possibly stale tracking ref.
    advertised = git(["ls-remote", "--refs", urls[0], target], repo)
    old = next((line.split()[0] for line in advertised.splitlines() if line.split()[1] == target), "")
    revision = tip
    if old and git(["cat-file", "-t", old], repo, False) == "commit":
        revision = old + ".." + tip
    # A new destination or an unavailable old object needs the full source history.
    if not git(["rev-list", "--max-count=1", revision], repo):
        return
    if not shutil.which("gitleaks"):
        block("Install gitleaks, then retry the push check.")
    result = subprocess.run(
        ["gitleaks", "git", "--redact", "--no-banner", "--no-color", "--verbose",
         "--exit-code", "1", "--log-opts=" + revision, str(repo)],
        cwd=repo, capture_output=True, text=True, timeout=5,
    )
    if result.returncode:
        reason = (result.stdout + result.stderr).strip() or "Secret scan returned a failure."
        block("Push blocked. Review the redacted scan report.\n" + reason)


try:
    main()
except subprocess.TimeoutExpired:
    block("Push check timed out. Check the connection or scan the history before retrying.")
except (OSError, ValueError, AttributeError, TypeError, IndexError) as error:
    block("Push-check hook failed: " + str(error))
PY
