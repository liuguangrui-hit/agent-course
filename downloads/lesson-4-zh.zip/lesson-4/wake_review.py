#!/usr/bin/env python3
"""One local timer, one tool-free Claude review, one explicit outcome.

The input is supplied through stdin. This is a classroom example, not a
long-running scheduler. Use a fresh output directory for every invocation.
"""
import argparse
from datetime import datetime, timedelta, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import signal
import subprocess
import time


def stamp():
    return datetime.now(timezone.utc).isoformat()


def stop_child(process):
    if process.poll() is not None:
        return
    if os.name == 'nt':
        subprocess.run(['taskkill', '/PID', str(process.pid), '/T', '/F'],
                       capture_output=True, check=False)
    else:
        os.killpg(process.pid, signal.SIGTERM)
        try:
            process.wait(timeout=3)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
    process.wait(timeout=5)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--delay-seconds', type=float, default=5)
    parser.add_argument('--timeout-seconds', type=float, default=90)
    args = parser.parse_args(argv)
    if not 0 <= args.delay_seconds <= 300 or not 0 < args.timeout_seconds <= 300:
        parser.error('delay must be 0..300 seconds; timeout must be 0..300 seconds')
    source = args.input.resolve()
    raw = source.read_bytes()
    content = raw.decode('utf-8')
    args.out = args.out.resolve()
    args.out.mkdir(parents=True, exist_ok=False)
    metadata = {
        'phase': 'waiting', 'host': platform.node(), 'platform': platform.system(),
        'local_timezone': datetime.now().astimezone().strftime('%Z %z'),
        'created_at_utc': stamp(),
        'due_at_utc': (datetime.now(timezone.utc) + timedelta(seconds=args.delay_seconds)).isoformat(),
        'input': str(source), 'input_sha256': hashlib.sha256(raw).hexdigest(),
        'delay_seconds': args.delay_seconds, 'timeout_seconds': args.timeout_seconds,
        'calls_started': 0,
    }
    record = args.out / 'run.json'

    def save():
        record.write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

    # No file tools, command tools or MCP servers are exposed to this review.
    command = ['claude', '-p', '--restricted', '--tools', '', '--disallowedTools', 'mcp__*',
               '--strict-mcp-config', '--mcp-config', '{"mcpServers":{}}',
               '--disable-slash-commands', '--permission-mode', 'dontAsk',
               '--no-session-persistence', '--output-format', 'text']
    prompt = ('只读下面这一份课堂记录，核查它是否写明输入身份、执行状态和下一步。'
              '缺项就指出缺项，不补造事实。只把意见输出到最终回答。\n\n' + content)
    process = None
    save()
    print(json.dumps({'phase': 'waiting', 'due_at_utc': metadata['due_at_utc'],
                      'record': str(record)}, ensure_ascii=False), flush=True)
    try:
        time.sleep(args.delay_seconds)
        process = subprocess.Popen(command, cwd=args.out, stdin=subprocess.PIPE,
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding='utf-8',
                                   start_new_session=os.name != 'nt',
                                   creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name == 'nt' else 0)
        metadata.update(phase='running', pid=process.pid, started_at_utc=stamp(), calls_started=1)
        save()
        stdout, stderr = process.communicate(prompt, timeout=args.timeout_seconds)
        (args.out / 'stdout.txt').write_text(stdout, encoding='utf-8')
        (args.out / 'stderr.txt').write_text(stderr, encoding='utf-8')
        if process.returncode:
            metadata.update(phase='failed', exit_code=process.returncode)
            code = process.returncode if 0 < process.returncode < 126 else 1
        elif not stdout.strip():
            metadata.update(phase='empty_output', exit_code=0)
            code = 2
        else:
            (args.out / 'review.md').write_text(stdout, encoding='utf-8')
            metadata.update(phase='completed', exit_code=0)
            code = 0
    except subprocess.TimeoutExpired:
        stop_child(process)
        stdout, stderr = process.communicate()
        (args.out / 'stdout.txt').write_text(stdout, encoding='utf-8')
        (args.out / 'stderr.txt').write_text(stderr, encoding='utf-8')
        metadata.update(phase='timeout', exit_code=process.returncode)
        code = 124
    except KeyboardInterrupt:
        if process is not None:
            stop_child(process)
        metadata.update(phase='cancelled', exit_code=process.returncode if process else None)
        code = 130
    except OSError as error:
        metadata.update(phase='launch_failed', error_type=type(error).__name__)
        code = 127
    metadata['finished_at_utc'] = stamp()
    metadata['source_unchanged'] = hashlib.sha256(source.read_bytes()).hexdigest() == metadata['input_sha256']
    if not metadata['source_unchanged']:
        metadata['phase'] = 'input_changed'
        code = 3
    save()
    print(json.dumps(metadata, ensure_ascii=False), flush=True)
    return code


if __name__ == '__main__':
    raise SystemExit(main())
