# 第 1 轮成品

第 3 课在本机 CPU 实跑的成品作为本课第 1 轮，原始预测、结果和自审意见保留，网页由本课脚本生成。

| 文件或文件夹 | 用途 |
|---|---|
| [site/index.html](site/index.html) | 公开汇总，只有定性摘要与循环指标 |
| [site/round-1.html](site/round-1.html) | 公开详情，逐条预测与对错 |
| [site/style.css](site/style.css) | 公开页样式 |
| [internal/index.html](internal/index.html) | 内部汇总 |
| [internal/round-1.html](internal/round-1.html) | 完整预测、数字、图与审查 |
| [internal/style.css](internal/style.css) | 内部页样式 |
| [internal/assets/](internal/assets/) | 内部页使用的原文和结果文件副本 |
| [runs/1/prediction.md](runs/1/prediction.md) | 第 3 课实验前写下的四条预测 |
| [runs/1/result.md](runs/1/result.md) | 逐条对错、结论与数字来源 |
| [runs/1/review.md](runs/1/review.md) | 原始 Codex 自审，正式整体审查未通过 |
| [runs/1/public.json](runs/1/public.json) | 同一原文的中英文定性投影 |
| [runs/1/results/](runs/1/results/) | 真实 CSV、图、元数据、数值核对与日志 |
| [runs/1/code/](runs/1/code/) | 第 3 课实际使用的实验、汇总和画图脚本 |
| [playbook.md](playbook.md) | 从第 1 轮实际过程提取的两条经验 |
| [notification.txt](notification.txt) | 完成通知示例，网址为占位 |

## 真实数字

只有一轮，四条预测一对三错，预测命中率为 25%。数字与结论通过自审，真实 Git 提交及另一家独立审查未通过，整体通过率为 0%。网页读 result.md 的对错表，识别 results.csv 的 PREVIEW_UNCOMMITTED 占位提交，保留未通过判定。

results/results.csv 有 240 行，四种方法、四档噪声、五个种子和三种策略。40% 噪声下 CE 的五种子均值为：带噪验证集早停准确率 93.25%，干净验证集早停 92.26%，不早停 68.37%；带噪与干净触发停止分别在第 11.8 与 14.4 轮。恢复权重轮次分别为 3.8 与 6.4。每个值来自 [逐次结果](runs/1/results/results.csv)，汇总见 [summary.csv](runs/1/results/summary.csv)，同种子比较见 [paired_differences.csv](runs/1/results/paired_differences.csv)。实际运行耗时由 [run_metadata.json](runs/1/results/run_metadata.json) 记录，为 258.5348861217499 秒。

这些是第 3 课已有实跑结果，本课导入并重新生成网页。原审查中的 prediction.md 和 results.csv 摘要与原件一致，result.md 的摘要与当前原件不同；本课保留原件及原审查，整体判定仍为未通过。没有第 2 轮及以后的结果，没有本课服务器运行、真实提交、发布或通知发送记录。notification.txt 展示要发送的文字，不含实验具体数字。两份材料共用第 3 课现有英文标注图，数据与代码相同。

## 重新生成与重跑

在上一层练习目录运行：

```sh
python3 code/make_page.py --root preview --language zh
```

它重建 preview/site/ 与 preview/internal/，不改第 1 轮输入。公开页只有 HTML 和 CSS，内部页保留全部小结果与原文。

重跑实验时另存结果，保留课上先看的原件：

```sh
uv run python preview/runs/1/code/run_experiment.py --seeds 0 --epochs 5 --out runs/replay/smoke
uv run python preview/runs/1/code/run_experiment.py --out runs/replay/results
uv run python preview/runs/1/code/analyze_results.py --input runs/replay/results/results.csv --out runs/replay/results
uv run --with matplotlib==3.9.4 python preview/runs/1/code/plot_results.py --input runs/replay/results/results.csv --out runs/replay/results/fig_early_stop.png --language zh
```

实验和汇总只依赖 numpy，画图由 uv 临时提供 matplotlib。replay 是重跑目录，不是新增编号轮次，也不进入公开页面。正式循环把完成的代码放入 code/，先提交，再用 `--commit git` 写入实际提交编号。
