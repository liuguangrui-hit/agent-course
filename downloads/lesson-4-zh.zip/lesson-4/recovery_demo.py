#!/usr/bin/env python3
"""A process-failure recovery demo for one local file effect, not remote exactly-once."""
import argparse
from hashlib import sha256
import json
import os
from pathlib import Path
import tempfile


def atomic_json(path, value):
    descriptor, temp = tempfile.mkstemp(prefix=path.name + '.tmp-', dir=path.parent)
    try:
        with os.fdopen(descriptor, 'w', encoding='utf-8') as stream:
            json.dump(value, stream, ensure_ascii=False, indent=2)
            stream.write('\n')
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temp, path)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--crash-after-action', action='store_true')
    args = parser.parse_args()
    root = args.root.resolve()
    root.mkdir(parents=True, exist_ok=True)
    lock = root / '.lock'
    try:
        lock.mkdir()
    except FileExistsError:
        parser.exit(3, 'Lock exists; verify the owner before takeover.\n')
    try:
        (lock / 'owner').write_text(str(os.getpid()), encoding='utf-8')
        payload = {'run': 'demo-run-1', 'value': 17}
        action = root / 'effect.json'
        events_path = root / 'events.json'
        events = json.loads(events_path.read_text()) if events_path.exists() else {}
        if action.exists():
            if json.loads(action.read_text()) != payload:
                parser.exit(4, 'Existing effect has another identity or content.\n')
            events['reconciled_existing_effect'] = True
        else:
            atomic_json(action, payload)
            events['effect_created'] = True
        atomic_json(events_path, events)
        if args.crash_after_action:
            parser.exit(17, 'Simulated failure after the effect and before state commit.\n')
        atomic_json(root / 'state.json', {'phase': 'completed', 'run': payload['run'],
                                         'effect_sha256': sha256(action.read_bytes()).hexdigest()})
        events['completed'] = True
        atomic_json(events_path, events)
        print(json.dumps({'effect_count': len(list(root.glob('effect.json'))),
                          'phase': 'completed', 'run': payload['run']}))
    finally:
        (lock / 'owner').unlink()
        lock.rmdir()


if __name__ == '__main__':
    main()
