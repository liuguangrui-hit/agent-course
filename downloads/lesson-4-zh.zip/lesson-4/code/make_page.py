"""Build public and internal lesson pages using only the Python standard library."""
import argparse
import csv
import hashlib
import html
import json
import re
import shutil
from pathlib import Path


TEXT = {
    "zh": dict(title="实验循环结果", internal="内部结果页", rounds="完成轮次",
               hit="预测命中率", review_rate="审查通过率", round="轮次", question="问题",
               prediction="预测", verdict="对错", review="审查", conclusion="结论",
               correct="对", wrong="错", passed="通过", failed="未通过", pending="待审",
               empty="暂无完成轮次", none="暂无", board="经验榜", back="返回汇总",
               result="结果说明", raw="结果文件", private="完整数字与图", status="状态",
               source="来源", preview="第 3 课实跑预览，自审，提交字段为占位值"),
    "en": dict(title="Experiment loop results", internal="Internal results", rounds="Completed rounds",
               hit="Prediction hit rate", review_rate="Review pass rate", round="Round", question="Question",
               prediction="Prediction", verdict="Verdict", review="Review", conclusion="Conclusion",
               correct="Correct", wrong="Wrong", passed="Passed", failed="Failed", pending="Pending",
               empty="No completed rounds yet", none="No data", board="Playbook", back="Back to summary",
               result="Result report", raw="Result files", private="Full numbers and figures", status="Status",
               source="Source", preview="Real Lesson 3 preview, self-reviewed, with a placeholder commit"),
}
CSS = """*{box-sizing:border-box}body{margin:0;background:#f3f5f4;color:#1c302c;font:17px/1.65 system-ui,sans-serif}main{max-width:1100px;margin:auto;padding:36px 22px 60px}h1{font-size:2.1rem;line-height:1.25}h2{margin-top:2rem}a{color:#17645e}header{border-bottom:3px solid #17645e;padding-bottom:20px}.metrics{display:flex;flex-wrap:wrap;gap:18px;margin:25px 0}.metric,article{background:white;border:1px solid #cbd8d1;border-radius:8px;padding:18px}.metric{flex:1;min-width:180px}.metric strong{display:block;font-size:1.7rem}.scroll{overflow-x:auto}table{width:100%;border-collapse:collapse;background:#fff}th,td{text-align:left;vertical-align:top;padding:12px;border-bottom:1px solid #d5dfda}th{background:#e4eee8}img{max-width:100%;height:auto}pre{overflow:auto;background:#e4eee8;padding:16px}code{overflow-wrap:anywhere}.note{color:#54635d;font-size:.94rem}article{margin:16px 0}ul{padding-left:24px}footer{margin-top:34px} @media(max-width:650px){main{padding:22px 14px}h1{font-size:1.7rem}th,td{padding:9px;font-size:.95rem}.metrics{gap:9px}.metric{min-width:135px}}"""


def esc(value):
    return html.escape(str(value), quote=True)


def inline(text, prefix="", public=False):
    """Escape all text; accept relative links only, remapping round source links."""
    pattern = re.compile(r"(!?)\[([^\]]*)\]\(([^)]+)\)|`([^`]+)`")
    out, start = [], 0
    for m in pattern.finditer(text):
        out.append(esc(text[start:m.start()]))
        if m.group(4) is not None:
            out.append("<code>" + esc(m.group(4)) + "</code>")
        else:
            image, label, target = m.group(1, 2, 3)
            mapped = re.fullmatch(r"runs/(\d+)/(?:result|review|prediction)\.md", target)
            if mapped:
                target = "round-" + mapped.group(1) + ".html"
            elif public or re.search(r"^[/\\]|:|\.\.", target):
                target = ""
            else:
                target = prefix + target
            if target and image and not public:
                out.append('<img loading="lazy" src="' + esc(target) + '" alt="' + esc(label) + '">')
            elif target and not image:
                out.append('<a href="' + esc(target) + '">' + esc(label) + '</a>')
            else:
                out.append(esc(label))
        start = m.end()
    out.append(esc(text[start:]))
    return "".join(out)


def cells(line):
    return [c.strip() for c in line.strip().strip("|").split("|")]


def tables(text):
    lines = text.splitlines()
    for i, line in enumerate(lines[:-1]):
        if line.startswith("|") and re.fullmatch(r"[| :\-]+", lines[i + 1]):
            rows, j = [], i + 2
            while j < len(lines) and lines[j].startswith("|"):
                rows.append(cells(lines[j]))
                j += 1
            yield cells(line), rows


def markdown(text, prefix="", public=False):
    """Render the headings, paragraphs, tables, lists and code blocks used here."""
    lines, out, i = text.splitlines(), [], 0
    while i < len(lines):
        line = lines[i]
        if line.startswith("```"):
            block, i = [], i + 1
            while i < len(lines) and not lines[i].startswith("```"):
                block.append(lines[i]); i += 1
            out.append("<pre><code>" + esc("\n".join(block)) + "</code></pre>")
        elif line.startswith("|") and i + 1 < len(lines) and re.fullmatch(r"[| :\-]+", lines[i + 1]):
            head, rows, i = cells(line), [], i + 2
            while i < len(lines) and lines[i].startswith("|"):
                rows.append(cells(lines[i])); i += 1
            out.append(table(head, [[inline(c, prefix, public) for c in r] for r in rows])); continue
        elif re.match(r"^#{1,6} ", line):
            level = len(line) - len(line.lstrip("#"))
            out.append(f"<h{level}>" + inline(line[level + 1:], prefix, public) + f"</h{level}>")
        elif line.startswith("- "):
            items = []
            while i < len(lines) and lines[i].startswith("- "):
                items.append("<li>" + inline(lines[i][2:], prefix, public) + "</li>"); i += 1
            out.append("<ul>" + "".join(items) + "</ul>"); continue
        elif line.strip():
            out.append("<p>" + inline(line, prefix, public) + "</p>")
        i += 1
    return "\n".join(out)


def table(headers, rows):
    return ('<div class="scroll"><table><thead><tr>' + "".join("<th>" + esc(h) + "</th>" for h in headers)
            + "</tr></thead><tbody>" + "".join("<tr>" + "".join("<td>" + c + "</td>" for c in r) + "</tr>" for r in rows)
            + "</tbody></table></div>")


def document(title, body, lang):
    return ('<!doctype html>\n<html lang="' + lang + '"><head><meta charset="utf-8">'
            '<meta name="viewport" content="width=device-width, initial-scale=1"><title>' + esc(title)
            + '</title><link rel="stylesheet" href="style.css"></head><body><main>' + body + '</main></body></html>\n')


def verdicts(prediction, result):
    prediction_rows = next((r for h, r in tables(prediction) if h[0] in {"预测", "Prediction"}), None)
    result_rows = next((r for h, r in tables(result) if h[-1] in {"对错", "Verdict"}), None)
    values = {"对": True, "错": False, "Correct": True, "Wrong": False}
    if not prediction_rows or not result_rows or len(prediction_rows) != len(result_rows):
        raise ValueError("Prediction and result tables must have the same nonzero row count")
    if any(r[-1] not in values for r in result_rows):
        raise ValueError("Every result verdict must be 对/错 or Correct/Wrong")
    return [values[r[-1]] for r in result_rows]


def review_status(text, result_rows, digests):
    # The copied Lesson 3 self-review explicitly rejects formal provenance.
    if any(r.get("commit") == "PREVIEW_UNCOMMITTED" for r in result_rows):
        return "failed"
    markers = re.findall(r"^REVIEW_STATUS: (PASS|FAIL)$", text, re.M)
    if len(markers) != 1:
        raise ValueError("Review must contain exactly one REVIEW_STATUS: PASS or FAIL line")
    if markers[0] == "PASS":
        for name, digest in digests.items():
            recorded = re.search(re.escape(name) + r" SHA-256[：:]\s*`?([a-f0-9]{64})", text)
            if recorded is None or recorded.group(1) != digest:
                raise ValueError("Passing review must match current input SHA-256 digests: " + name)
    return "passed" if markers[0] == "PASS" else "failed"


def read_round(path, lang):
    prediction = (path / "prediction.md").read_text(encoding="utf-8")
    result = (path / "result.md").read_text(encoding="utf-8")
    review = (path / "review.md").read_text(encoding="utf-8")
    with (path / "results/results.csv").open(encoding="utf-8", newline="") as f:
        rows = list(csv.DictReader(f))
    if not rows:
        raise ValueError(f"{path}: empty results.csv")
    checks = verdicts(prediction, result)
    # Public prose is an explicit, qualitative projection of the private inputs.
    public = json.loads((path / "public.json").read_text(encoding="utf-8"))[lang]
    if set(public) != {"question", "predictions", "conclusion"} or len(public["predictions"]) != len(checks):
        raise ValueError(f"{path}: public.json needs question, matching predictions, conclusion")
    for value in [public["question"], public["conclusion"], *public["predictions"]]:
        if not isinstance(value, str) or not value.strip() or re.search(r"[0-9%±]|https?://|@", value):
            raise ValueError(f"{path}: public prose must be qualitative, without numeric results or addresses")
    digests = {name: hashlib.sha256((path / name).read_bytes()).hexdigest()
               for name in ["prediction.md", "results/results.csv", "result.md"]}
    return dict(n=int(path.name), path=path, prediction=prediction, result=result, review=review,
                rows=rows, checks=checks, public=public, status=review_status(review, rows, digests),
                preview=any(r.get("commit") == "PREVIEW_UNCOMMITTED" for r in rows))


def build(root, lang):
    t = TEXT[lang]
    rounds, issues = [], []
    for path in sorted((root / "runs").glob("*"), key=lambda p: int(p.name) if p.name.isdecimal() else -1):
        if not path.is_dir() or not path.name.isdecimal():
            continue
        names = ["prediction.md", "result.md", "review.md", "results/results.csv", "public.json"]
        missing = [name for name in names if not (path / name).is_file()]
        try:
            run = json.loads((path / 'run.json').read_text()) if (path / 'run.json').exists() else {}
            if run.get('phase') == 'failed':
                issues.append((path.name, 'execution_failed', str(run.get('error_code', 'unspecified'))))
            elif missing:
                issues.append((path.name, 'incomplete', 'Missing: ' + ', '.join(missing)))
            else:
                rounds.append(read_round(path, lang))
        except (ValueError, OSError, KeyError, IndexError, TypeError) as error:
            issues.append((path.name, 'invalid', str(error)))
    board = (root / "playbook.md").read_text(encoding="utf-8")
    entries = re.findall(r"^## .+?(?=^## |\Z)", board, re.M | re.S)[:5]
    total = sum(len(r["checks"]) for r in rounds)
    hits = sum(sum(r["checks"]) for r in rounds)
    passed = sum(r["status"] == "passed" for r in rounds)
    metrics = [(t["rounds"], str(len(rounds))),
               (t["hit"], f"{hits}/{total} · {hits / total:.0%}" if total else t["none"]),
               (t["review_rate"], f"{passed}/{len(rounds)} · {passed / len(rounds):.0%}" if rounds else t["none"])]
    metric_html = '<div class="metrics">' + "".join('<div class="metric">' + esc(label) + '<strong>' + esc(value) + '</strong></div>' for label, value in metrics) + '</div>'
    for private in [False, True]:
        output = root / ("internal" if private else "site")
        # Rebuild only owned output folders so old published rounds cannot linger.
        if output.is_symlink():
            raise ValueError("Output folder must not be a symlink")
        if output.exists():
            shutil.rmtree(output)
        output.mkdir()
        (output / "style.css").write_text(CSS + "\n", encoding="utf-8")
        summary = []
        for r in rounds:
            p, number = r["public"], str(r["n"])
            question = '<a href="round-' + number + '.html">' + esc(p["question"]) + '</a>'
            checks = [t["correct"] if c else t["wrong"] for c in r["checks"]]
            summary.append([number, question, '<br>'.join(esc(s) for s in p["predictions"]),
                            '<br>'.join(esc(s) for s in checks), esc(t[r["status"]])])
            body = '<a href="index.html">' + t["back"] + '</a><h1>' + esc(t["round"] + ' ' + number + ': ' + p["question"]) + '</h1>'
            body += '<p>' + esc(t["review"] + ': ' + t[r["status"]]) + '</p>'
            if r["preview"]:
                body += '<p class="note">' + esc(t["preview"]) + '</p>'
            body += table([t["prediction"], t["verdict"]], [[esc(s), esc(v)] for s, v in zip(p["predictions"], checks)])
            body += '<h2>' + t["conclusion"] + '</h2><p>' + esc(p["conclusion"]) + '</p>'
            if private:
                asset = output / 'assets/runs' / number
                asset.mkdir(parents=True)
                for name in ["prediction.md", "result.md", "review.md"]:
                    shutil.copy2(r["path"] / name, asset / name)
                shutil.copytree(r["path"] / 'results', asset / 'results')
                prefix = 'assets/runs/' + number + '/'
                for name, key in [("prediction", "prediction"), ("result", "result"), ("review", "review")]:
                    body += '<section><h2>' + t[key] + '</h2>' + markdown(r[name], prefix) + '</section>'
                body += '<h2>' + t["raw"] + '</h2><ul>'
                for file in sorted((asset / 'results').rglob('*')):
                    if file.is_file():
                        relative = file.relative_to(output).as_posix()
                        body += '<li><a href="' + esc(relative) + '">' + esc(file.relative_to(asset).as_posix()) + '</a></li>'
                body += '</ul>'
            (output / ('round-' + number + '.html')).write_text(document(t["round"] + ' ' + number, body, lang), encoding="utf-8")
        title = t["internal"] if private else t["title"]
        body = '<header><h1>' + title + '</h1></header>' + metric_html
        body += table([t["round"], t["question"], t["prediction"], t["verdict"], t["review"]], summary) if rounds else '<p>' + t["empty"] + '</p>'
        if issues:
            labels = ({'execution_failed': '执行失败', 'incomplete': '未完成', 'invalid': '待核'}
                      if lang == 'zh' else
                      {'execution_failed': 'Execution failed', 'incomplete': 'Incomplete', 'invalid': 'Needs verification'})
            body += '<h2>' + ('未计入完成分母的轮次' if lang == 'zh' else 'Rounds outside completed denominators') + '</h2>'
            headers = [t['round'], t['status']] + ([('原因' if lang == 'zh' else 'Reason')] if private else [])
            issue_rows = [[esc(number), esc(labels[status])] + ([esc(reason)] if private else [])
                          for number, status, reason in issues]
            body += table(headers, issue_rows)
        (output / 'build-status.json').write_text(json.dumps({
            'completed': len(rounds), 'outside_completed': len(issues),
            'prediction_denominator': total, 'review_denominator': len(rounds),
            'round_statuses': [{'round': number, 'status': status} for number, status, _ in issues]
        }, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        body += '<footer><h2>' + t["board"] + '</h2>'
        body += ''.join('<article>' + markdown(e, public=True) + '</article>' for e in entries) if entries else '<p>' + t["none"] + '</p>'
        body += '</footer>'
        (output / 'index.html').write_text(document(title, body, lang), encoding="utf-8")
    print(f"rounds={len(rounds)} incomplete_or_failed={len(issues)} predictions={hits}/{total} reviews={passed}/{len(rounds)}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent.parent)
    parser.add_argument('--language', choices=['zh', 'en'])
    args = parser.parse_args()
    root = args.root.resolve()
    lang = args.language or next((p.name for p in [root, *root.parents] if p.name in TEXT), 'en')
    build(root, lang)


if __name__ == '__main__':
    main()
