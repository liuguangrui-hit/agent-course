# 第 4 课练习材料：自动化

## 本课的三个阶段

- 课前预备：找齐前课结果，准备依赖与本地预览，完成一次零延迟只读调用，不创建长期调度。
- 课上一小时：课堂观察中断恢复，设置一次短延迟的只读审阅，用新会话接状态，再设计经验检验。
- 课后复习与拔高：先画恢复路径，再区分重试与科学负结果，最后接少量调度或三组检验。

课前检查写入 preflight.md，课后复盘写入 review-after-class.md。逐段时间与正反例见本课课程页。安装和下载在课前完成，课堂直接使用本地材料。

接着第 3 课实验仓库，练习定时开工、收工审查、知识库回写、经验榜和结果页。

| 文件或文件夹 | 用途 |
|---|---|
| [LOOP.md](LOOP.md) | 一轮开工与收工、锁交接及固定评价标准 |
| [STATE.md](STATE.md) | 初始状态模板，每一步完成后填写 |
| [playbook.md](playbook.md) | 空经验榜，说明四个字段、合并与上限 |
| [playbook-archive.md](playbook-archive.md) | 经验榜超出上限时的归档 |
| [review_task.md](review_task.md) | 数字、结论、提交对应关系的只读审查 |
| [reflection_task.md](reflection_task.md) | 每天检查是否又完成三轮，再独立反思 |
| [ledger.csv](ledger.csv) | 空用量表，开工与收工各记一行实际用量 |
| [questions.md](questions.md) | 指向第 2 课 vault/questions.md 的说明 |
| [code/run_experiment.py](code/run_experiment.py) | 第 3 课原始实验代码，保留起步版本 |
| [code/make_page.py](code/make_page.py) | 标准库网页生成器，分公开与内部两份 |
| [data/](data/) | 第 3 课带来的第 1 课真实 CSV |
| [pyproject.toml](pyproject.toml) | numpy 实验环境 |
| [uv.lock](uv.lock) | 第 3 课锁定的环境版本 |
| [.gitignore](.gitignore) | 排除环境、密钥、日志、运行锁及生成网页 |
| [preview/](preview/README.md) | 第 1 轮真实成品、网页与通知示例 |
| [AGENTS.md](AGENTS.md) | 稳定项目约定 |
| [CLAUDE.md](CLAUDE.md) | 引用 AGENTS.md |

## 先看成品

在浏览器打开 [公开汇总](preview/site/index.html)，再看 [公开详情](preview/site/round-1.html)。完整数字与图在 [内部详情](preview/internal/round-1.html)，数字来源和审查情况见 [预览说明](preview/README.md)。通知见 [notification.txt](preview/notification.txt)。成品只有第 1 轮。

## 开始练习

将同语言的各课材料分别作为相邻的 lesson-2、lesson-3、lesson-4 文件夹。本课任务从 lesson-4 内执行，这样 `../lesson-2/vault/` 指向自己的知识库。完成第 2 课的知识库和问题清单后开始。第 3 课已装好的工具配置由学员带过来。

按本课正文先演示中断恢复，再沿用前课完整成果或明确来源的预览作起点。课堂一起设置一次定时只读审阅，从 STATE.md 接续；课后根据执行环境扩成少量周期调度。通知与发布沿用已授权渠道，课堂先看本地页。

实验环境沿用 Python 3.9 至 3.12 与 numpy 2.0.2。

```sh
uv sync --frozen
mkdir -p logs
```

`code/run_experiment.py` 与第 3 课起步代码相同，输出到 data/，只有 `--quick`，其短跑为二十轮。它需要按 LOOP.md 加入早停、种子、轮数、输出目录和提交参数。已做完第 3 课的学员可把自己的代码带过来；预览的实现和汇总脚本也可复制到 code/ 作起点。

运行时创建 `runs/<n>/`、logs/ 和 reflections/。每轮含 prediction.md、results/、result.md、review.md，以及公开文字投影 public.json。public.json 的结构见 [真实预览](preview/runs/1/public.json)，它不存实验数字或评分，对错由生成器从 result.md 取，整体审查判定由 review.md 取。

## 生成网页

在本练习目录运行：

```sh
python3 code/make_page.py
```

生成 site/index.html、site/style.css 和每轮 site/round-n.html，internal/ 同结构并保留原文和结果文件。缺文件、执行失败或内容待核的轮次单独展示状态，不进入完成分母。每份 build-status.json 记录分母与状态。执行失败可在本轮 run.json 写 phase 为 failed 和 error_code。生成前逐轮核对 public.json 和经验榜的展示范围，投影字段与数字字符检查不能判断内容是否适合公开。

先在本地查看。获得具体发布目标与投影授权后，只将批准的 site/ 内容部署，internal/ 留在本机。核对远端部署并打开实际版本。生成目录已排除在实验仓库的 Git 跟踪之外。

## 用量与恢复

ledger.csv 初始只有表头，token 与费用读实际执行记录，不可读时留空并写 unavailable。STATE.md 记录已记账的轮次与半轮键，接着做时核对已有行。

锁在开工时建立，收工结束释放。监视器续写最近活动时间，新收工对话通过 owner 和 worker 接管已有锁，细节见 LOOP.md。过期心跳需要核查持有者和实际进程，不能直接删锁。STOP 及超时锁由学员核对后处理。

## 中断恢复演示

[recovery_demo.py](recovery_demo.py)只演示一次本地文件动作后的进程失败恢复，不提供外部服务的恰好执行一次保证。使用自己新建的演示目录：

```bash
python3 recovery_demo.py --root demo-run --crash-after-action
python3 recovery_demo.py --root demo-run
python3 recovery_demo.py --root demo-run
```

第一条应退出 17，产物已写而 state.json 未提交；后两条都显示 effect_count 为 1。events.json 保留恢复观察。故意失败会释放示例锁；真正进程被强杀留下旧锁时，核对 owner 后人工接管。此脚本不承诺断电持久性或分布式租约安全。

网页先在本地看。公开字段由用户逐项选择，问题和预测也可能是未发表信息；随机通知频道名不等于访问控制。历史预览保留原样，新运行按本轮 LOOP.md 记录。

## 单次唤醒与只读审阅

[wake_review.py](wake_review.py)沿用已有 Claude 登录，以官方非交互入口启动一次无工具审阅，输入由脚本经 stdin 提供。它限制工具与 MCP，保存主机、时区、输入哈希、计划与实际时间、进程状态和输出。命令选项已对照本轮 CLI 帮助与[官方 CLI 文档](https://code.claude.com/docs/en/cli-reference)核对，所用版本需支持 --restricted。需要换官方入口时，在课堂一起核对等效权限与输出方式。

课前先完成一次零延迟可用性检查，使用新的输出目录：

```bash
python3 wake_review.py --input preflight-input.md --out preflight-call --delay-seconds 0 --timeout-seconds 90
```

课堂把输入换为这一轮的 result.md，设置五秒延迟。包内预览可以演练，不能记成自己的新实验：

```bash
python3 wake_review.py --input preview/runs/1/result.md --out one-shot-review --delay-seconds 5 --timeout-seconds 90
```

completed 且 review.md 非空才表示调用完成；运行失败、空输出、启动失败和超时分别记录。按 Ctrl+C 可取消本次等待或停止本次子进程，检查 run.json 与实际进程后再交接。每次使用新目录，旧记录保留；程序退出后没有周期任务。周期调度的配置与停止在 4.1 继续。
