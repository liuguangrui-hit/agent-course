# 第 4 课练习材料

接着第 3 课实验仓库，练习定时开工、收工审查、知识库回写、经验榜和结果页。

| 文件或文件夹 | 用途 |
|---|---|
| [LOOP.md](LOOP.md) | 一轮开工与收工、锁交接及固定评价标准 |
| [STATE.md](STATE.md) | 初始状态模板，每一步完成后填写 |
| [playbook.md](playbook.md) | 空经验榜，说明四个字段、合并与上限 |
| [playbook-archive.md](playbook-archive.md) | 经验榜超出上限时的归档 |
| [review_task.md](review_task.md) | 数字、结论、提交对应关系的只读审查 |
| [reflection_task.md](reflection_task.md) | 每天检查是否又完成三轮，再独立反思 |
| [ledger.csv](ledger.csv) | 空用量表，开工与收工各记一行实际用量 |
| [questions.md](questions.md) | 指向第 2 课 vault/questions.md 的说明 |
| [code/run_experiment.py](code/run_experiment.py) | 第 3 课原始实验代码，保留起步版本 |
| [code/make_page.py](code/make_page.py) | 标准库网页生成器，分公开与内部两份 |
| [data/](data/) | 第 3 课带来的第 1 课真实 CSV |
| [pyproject.toml](pyproject.toml) | numpy 实验环境 |
| [uv.lock](uv.lock) | 第 3 课锁定的环境版本 |
| [.gitignore](.gitignore) | 排除环境、密钥、日志、运行锁及生成网页 |
| [preview/](preview/README.md) | 第 1 轮真实成品、网页与通知示例 |
| [AGENTS.md](AGENTS.md) | 稳定项目约定 |
| [CLAUDE.md](CLAUDE.md) | 引用 AGENTS.md |

## 先看成品

在浏览器打开 [公开汇总](preview/site/index.html)，再看 [公开详情](preview/site/round-1.html)。完整数字与图在 [内部详情](preview/internal/round-1.html)，数字来源和审查情况见 [预览说明](preview/README.md)。通知见 [notification.txt](preview/notification.txt)。成品只有第 1 轮。

## 开始练习

将同语言的各课材料分别作为相邻的 lesson-2、lesson-3、lesson-4 文件夹。本课任务从 lesson-4 内执行，这样 `../lesson-2/vault/` 指向自己的知识库。完成第 2 课的知识库和问题清单后开始。第 3 课已装好的工具配置由学员带过来。

按正文先手动跑一轮，再建 22:00 开工、07:00 收工和 08:00 反思三个定时任务。每次用新对话，进度存 STATE.md。练习包提供任务文件，定时器、ntfy 和 lab-results 仓库在课堂中配置。

实验环境沿用 Python 3.9 至 3.12 与 numpy 2.0.2。

```sh
uv sync --frozen
mkdir -p logs
```

`code/run_experiment.py` 与第 3 课起步代码相同，输出到 data/，只有 `--quick`，其短跑为二十轮。它需要按 LOOP.md 加入早停、种子、轮数、输出目录和提交参数。已做完第 3 课的学员可把自己的代码带过来；预览的实现和汇总脚本也可复制到 code/ 作起点。

运行时创建 `runs/<n>/`、logs/ 和 reflections/。每轮含 prediction.md、results/、result.md、review.md，以及公开文字投影 public.json。public.json 的结构见 [真实预览](preview/runs/1/public.json)，它不存实验数字或评分，对错由生成器从 result.md 取，整体审查判定由 review.md 取。

## 生成网页

在本练习目录运行：

```sh
python3 code/make_page.py
```

生成 site/index.html、site/style.css 和每轮 site/round-n.html，internal/ 同结构并保留原文和结果文件。缺少预测、结果说明、审查或结果 CSV 的轮次不进入完成轮次。生成前逐轮核对 public.json 和经验榜的公开文字。脚本检查投影字段、预测条数和数字字符；公开文字的含义由收工核对。

只把 site/ 内容复制到公开的 lab-results 仓库，提交、推送并核对 Pages 部署。internal/ 在本机打开。生成目录已排除在实验仓库的 Git 跟踪之外，公开仓库只接收 site/ 内容。

## 用量与恢复

ledger.csv 初始只有表头，token 与费用读实际执行记录，不可读时留空并写 unavailable。STATE.md 记录已记账的轮次与半轮键，接着做时核对已有行。

锁在开工时建立，收工结束删除。监视器续写最近活动时间，六小时超时按最近活动计算。新收工对话通过 owner 和 worker 接管已有锁，细节见 LOOP.md。STOP 及超时锁由学员核对后处理。
