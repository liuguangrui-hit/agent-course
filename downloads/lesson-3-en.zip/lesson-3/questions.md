# Question: Can noisy-validation early stopping curb memorization of wrong labels?

## Abstract

In Lesson 1, continued training on noisy labels can reduce clean test accuracy as the network memorizes wrong labels. Hold out 10% of the training data with the same label noise and stop according to its validation loss. Can this preserve clean test accuracy? Use clean labels on the same validation examples as a control, and compare both with no early stopping. Predict the stopping epoch, final accuracy, and the difference between the two stopping rules at 40% noise, then test four noise levels and five seeds.
