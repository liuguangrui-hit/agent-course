# Lesson 3 Agent experiments practice materials

Start from the Lesson 1 label-noise experiment to practice writing predictions, committing code, running in the background, comparing results, and reviewing conclusions.

| File or folder | Purpose |
|---|---|
| [questions.md](questions.md) | A ready-to-use question and abstract |
| [code/run_experiment.py](code/run_experiment.py) | An unchanged copy of Lesson 1 code to extend in Exercise 2 |
| [data/results.csv](data/results.csv) | Original per-run results from Lesson 1 |
| [data/curves.csv](data/curves.csv) | Lesson 1 test accuracy by epoch to understand the phenomenon |
| [pyproject.toml](pyproject.toml) | uv environment with numpy as its only dependency |
| [uv.lock](uv.lock) | Locked environment versions |
| [.gitignore](.gitignore) | Excludes data, results, environments, secrets, PDFs, and runtime logs |
| [logs/](logs/) | Empty folder for the classroom logs/run.log |
| [preview/](preview/README.md) | A completed example with predictions written before a real run, a figure, and a Codex self-review |
| [AGENTS.md](AGENTS.md) | Stable project conventions shared by both agents |
| [CLAUDE.md](CLAUDE.md) | References AGENTS.md |

## Use

Open this folder in your agent, read the question and Lesson 1 data, then follow Exercises 1 through 3 in the lesson. Learners create prediction.md, result.md, review.md, and results/ at the root. The completed example stays in preview/.

The environment uses Python 3.9 through 3.12 and numpy 2.0.2. Once uv is available, run:

```sh
uv sync --frozen
mkdir -p logs
uv run python code/run_experiment.py
```

The original script writes into data/. In Exercise 2, add validation early stopping, seed and epoch options, and redirect new output to results/. The original --quick uses 20 epochs. The classroom five-epoch smoke test needs an explicit epoch option. logs/ is empty in the practice folder. Git and the current website packaging script omit empty folders, so run mkdir -p logs after extracting the download or cloning on the server.

Use the same 10% held-out examples for both stopping rules, replacing only the labels for the clean control. Restore the weights with the best validation loss and record both the selected checkpoint epoch and the stopping trigger epoch. See the [preview instructions](preview/README.md) to reproduce the completed example.
