# Lesson 3 exercise materials: Experimental analysis

## The three stages of this lesson

- Before class: prepare Git, locked dependencies, logs/ and an available execution environment. Do not start full training.
- In class: first freeze the prediction, then change the code and do short runs; the preview analysis is saved in a separate rehearsal file, and the final conclusion about the new control is written after class.
- After class: first restate the discriminating plan, then tell "not significant" apart from "equivalent", and finally add seeds, intervals or a mechanism control.

Record your preparation checks in preflight.md and your after-class review in review-after-class.md. The lesson page gives the timing for each activity and examples to compare. Complete installations and downloads before class so the materials are ready to use.

Starting from the label-noise experiment of Lesson 1, practice writing a prediction first, committing code, running in the background, comparing results and reviewing conclusions.

| File or folder | Purpose |
|---|---|
| [questions.md](questions.md) | A question and abstract you can start on directly |
| [code/run_experiment.py](code/run_experiment.py) | The Lesson 1 experiment code copied unchanged, for modification in Exercise 2 |
| [data/results.csv](data/results.csv) | Raw results of every Lesson 1 run |
| [data/curves.csv](data/curves.csv) | Lesson 1 test accuracy for every epoch, for understanding the phenomenon |
| [pyproject.toml](pyproject.toml) | uv environment, depending only on numpy |
| [uv.lock](uv.lock) | Locked environment versions |
| [.gitignore](.gitignore) | Excludes data, results, environments, secrets, PDFs and run logs |
| [logs/](logs/) | Empty directory; the class experiment's logs/run.log goes here |
| [preview/](preview/README.md) | A complete finished example that wrote its prediction before the real run, with result figures and a Codex self-review |
| [AGENTS.md](AGENTS.md) | Stable project conventions shared by both agents |
| [CLAUDE.md](CLAUDE.md) | Refers to AGENTS.md |

## Environment setup and use in class

Open the agent in this folder, read the question and the Lesson 1 data first, then work through Exercises 1 to 3 on the course page. prediction.md, result.md, review.md and results/ at the root are files students generate; the finished example is kept in preview/.

The environment uses Python 3.9 to 3.12 and numpy 2.0.2. Get uv ready before class, then download the dependencies and check the import:

```sh
uv sync --frozen
mkdir -p logs
uv run python -c "import numpy; print(numpy.__version__)"
```

The original code writes results into data/, so do not run it before class and overwrite the materials. After changing it in class according to the discriminating plan, write output to a new directory. When modifying it in Exercise 2, add validation-set early stopping and parameters for seeds and epochs, and change the new output to results/. The original --quick is 20 epochs, so the 5-epoch smoke test in class needs a new epochs parameter. logs/ is empty in the exercise directory, and neither Git nor the current site's packaging script keeps empty directories, so run mkdir -p logs first after unzipping or cloning.

Both kinds of early stopping should use the same 10% of validation samples, with the clean control replacing only the validation labels. After stopping, restore the weights with the best validation loss, and record both the epoch of the selected weights and the epoch at which stopping was triggered. See the [preview notes](preview/README.md) to rerun the finished example directly.

## extension exercise

[verify_noise_identity.py](verify_noise_identity.py) enumerates symmetric label flips with rational numbers and checks the formula for the expected noisy accuracy. It verifies the mathematical relation; it does not run training, nor does it directly verify the current implementation, which stops early on cross-entropy.

```bash
python3 verify_noise_identity.py
```

In class, run short tests of both arms of the new control with matched seeds, which only check the pairing and output structure. The five-seed preview is written separately to smoke/analysis-rehearsal.md for practicing intervals, and does not establish the result of the new control. The full job runs after class according to the frozen prediction.md, followed by the final result.md and review.md. The Lesson 2 question page shows a design that selects the epoch by accuracy, while the current preview stops early on cross-entropy with patience 8; the two designs are registered separately. The commit placeholder fields in the preview are kept as they were, and the code hash is the actual identity; the real experiment records its own actual commit.
