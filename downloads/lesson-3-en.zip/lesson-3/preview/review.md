Reviewed version: PREVIEW_UNCOMMITTED; result.md SHA-256 is `143125a7deb6c0fcd4590120283de644fd3061f2926b577f09075ecdb302e865`.

# Codex review

The reviewer is the same Codex session that created these materials, now checking [prediction.md](prediction.md), the results and records in results/, and [result.md](result.md) as a reviewer. This is a self-review.

## Numbers and conclusions

Passed. Recomputing CE at 40% noise over seeds 0 through 4 gives 93.25% noisy-validation accuracy and 92.26% clean-validation accuracy. The paired difference is positive 0.99 percentage points with SD 1.07 percentage points. Stopping triggers average 11.8 and 14.4 epochs, a difference of negative 2.6. Restored checkpoint epochs average 3.8 and 6.4. The report distinguishes these epoch definitions correctly.

Accuracy falls inside the prewritten 92% to 96% range; the other three predictions fail their criteria, giving one correct prediction and three wrong predictions. CE without stopping reaches 68.37% accuracy and 81.10% wrong-label fit, while noisy early stopping has 2.52% wrong-label fit. These values match summaries computed from per-run data. The small_loss values of 90.98% and 96.19% also match five-seed means at the same noise level.

The report describes no clear accuracy difference between stopping rules, consistent with the classroom criterion: the paired 95% confidence interval, −0.34 to 2.32 percentage points, crosses zero. It restricts the memorization conclusion to the tested synthetic task and states untested noise and datasets together. It does not treat high clean test accuracy as proof that wrong-label memorization is absent.

## Commit provenance

The formal exercise provenance check does not pass. Every commit field is PREVIEW_UNCOMMITTED, which cannot establish a code commit made before the run or identify the commit before the current code. run_metadata.json provides a code SHA-256 to identify the file version, but this does not replace Git history, a prediction commit timestamp, or a GitHub link. The materials clearly disclose this placeholder.

## Review limits and verdict

Suitable as a locally run completed preview; numbers and conclusions pass self-review. It does not meet the formal classroom requirements for actual Git commit provenance and independent review by another agent. Runtime records include matrix-multiplication warnings. Finite-value checks and seven matrix-shape comparisons against a reference passed; these records do not replace a complete rerun in another environment. The classroom experiment needs real commits and a new independent review.

Review input digests:

- prediction.md SHA-256: `04dd4d08b4c875fa1fa3882c6879cc105ae1e4a4f098093c81d01b393215f9fa`.
- results.csv SHA-256: `2e06d48bdbcb926cb3e36780dc08c888b1acd7012882b1a0f42e710a85cefeba`.
- result.md SHA-256: `143125a7deb6c0fcd4590120283de644fd3061f2926b577f09075ecdb302e865`.

Changes to these inputs require an updated review.
