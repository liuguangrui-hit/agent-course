# Noisy-validation early stopping

The commit field is PREVIEW_UNCOMMITTED, a fixed placeholder. The experiment code SHA-256 is `61e67a81d112c5e810c1c4a9b98ba99b501ee6f07b32caebef2c695031000c21`, recorded in [run_metadata.json](results/run_metadata.json).

## Predictions and results

The target is the five-seed CE mean at 40% noise. Positive differences mean noisy minus clean. Verdicts use the ranges in the [prerun predictions](prediction.md).

| Prediction | Actual result | Verdict |
|---|---|---|
| Noisy stopping at epoch 16, allowed range 13 to 19 | Epoch 11.8, SD 1.92, 4.2 epochs earlier than predicted | Wrong |
| Noisy stopping accuracy 94%, allowed range 92% to 96% | 93.25%, SD 1.94 percentage points, 0.75 percentage points below prediction | Correct |
| Noisy accuracy 3 percentage points below clean, allowed deficit 2 to 4 | 0.99 percentage points above clean, paired-difference SD 1.07 percentage points, no clear difference | Wrong |
| Noisy stopping 4 epochs later, allowed delay 2 to 6 | 2.6 epochs earlier, paired-difference SD 3.44 epochs | Wrong |

| CE at 40% noise | Final test accuracy | Stopping trigger epoch | Restored checkpoint epoch | Wrong-label fit rate |
|---|---|---|---|---|
| Noisy-validation early stopping | 93.25% ± 1.94 percentage points | 11.8 ± 1.92 | 3.8 ± 1.92 | 2.52% ± 1.25 percentage points |
| Clean-validation early stopping | 92.26% ± 1.22 percentage points | 14.4 ± 2.51 | 6.4 ± 2.51 | 4.00% ± 1.38 percentage points |
| No early stopping | 68.37% ± 2.84 percentage points | 80 | 80 | 81.10% ± 2.03 percentage points |

Every ± is the sample SD across five seeds. Wrong-label fit rate is the fraction of corrupted training examples for which the model predicts the wrong training label. Per-run values are in [results.csv](results/results.csv), grouped statistics in [summary.csv](results/summary.csv), and same-seed differences in [paired_differences.csv](results/paired_differences.csv). With seeds paired, the 95% confidence interval for the accuracy gap is −0.34 to 2.32 percentage points and for the stopping-epoch gap −6.9 to 1.7 epochs; both cross zero.

## What this shows

For CE on this synthetic task, noisy-validation early stopping raises final accuracy from 68.37% without stopping to 93.25%, while reducing wrong-label fit from 81.10% to 2.52%. It curbs late memorization of wrong labels. Noisy validation does not delay CE stopping as predicted: it triggers 2.6 epochs earlier on average and restores earlier weights. There is no clear accuracy difference between the two validation stopping rules.

## What this does not show

The experiment does not establish that early stopping eliminates all wrong-label memorization or that noisy validation generally outperforms clean validation. It tests symmetric label flips on a ten-class Gaussian task, without asymmetric noise, real datasets, or other stopping metrics. At the same noise level, small_loss reaches 90.98% with noisy validation and 96.19% with clean validation, so the CE direction does not transfer to every loss. There is no independent Git history or GitHub repository; the classroom experiment must establish commit provenance. This review is a self-review by the same Codex session.

## Actual settings and execution

A real local CPU run used ce, label_smoothing, gce, and small_loss, noise rates 0, 0.2, 0.4, and 0.6, seeds 0 through 4, and an 80-epoch limit, producing 240 result rows without reducing the setting. Of 4000 original training examples, 400 were held out for validation and 3600 used for training. The independent clean test set has 2000 examples. Validation conditions share examples. Both rules monitor cross-entropy with patience 8 and minimum improvement 0.0001, restore the best weights, and share the trajectory that continues to epoch 80 for the baseline. Python 3.12.13, numpy 2.0.2. A one-seed five-epoch smoke test ran first. Runtime records retain matrix-multiplication warning counts; weight and probability finite checks passed, as did comparisons of seven matrix shapes against a double-precision reference. See [numerical_check.json](results/numerical_check.json).

![Three stopping policies across four losses](results/fig_early_stop.png)

The figure is generated from the result CSV. Error bars show sample SD across five seeds. See [review.md](review.md) for the review.
