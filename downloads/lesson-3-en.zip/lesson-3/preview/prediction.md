# Predictions for noisy-validation early stopping

Written before the experiment on 2026-10-13, before implementing early stopping or running the new experiment.

The target is the mean over five CE seeds at 40% label noise. Final accuracy is clean test accuracy after restoring the weights with the best validation loss. The stopping epoch is the epoch that triggers stopping after eight epochs without improvement. The selected checkpoint epoch is recorded separately.

| Prediction | Reason | Falsification condition |
|---|---|---|
| Noisy-validation early stopping triggers at epoch 16 | Validation noise lets loss improvements continue longer | Mean stopping epoch falls outside 13 to 19 |
| Noisy-validation early stopping reaches 94% final accuracy | Restoring the best weights reduces late memorization of wrong labels | Mean accuracy falls below 92% or above 96% |
| Noisy-validation accuracy is 3 percentage points below clean-validation accuracy | Noisy validation loss selects worse weights | Mean noisy minus clean accuracy falls outside negative 4 to negative 2 percentage points |
| Noisy-validation early stopping triggers 4 epochs later | Noisy validation loss delays the stopping signal | Mean noisy minus clean stopping epoch falls outside 2 to 6 |

## Settings fixed in advance

Keep the Lesson 1 ten-class Gaussian task, 512 hidden units, an 80-epoch limit, batch size 64, and learning rate 0.002. Apply symmetric label flips to 4000 training examples, then hold out 10% using a fixed split. Both validation conditions use the same examples. Compare CE, label_smoothing, GCE, and small_loss at noise rates 0, 0.2, 0.4, and 0.6 with seeds 0 through 4.

Both stopping rules monitor validation cross-entropy with a minimum improvement of 0.0001 and patience 8, restoring the best weights. Train one trajectory per setting. Each stopping rule freezes its selected weights independently, while the trajectory continues to epoch 80 for the no-stopping control. Evaluate the 2000 clean test examples once for each policy at its final weights.

This is a locally run download preview. The prediction file was saved first, implementation followed, and results were generated afterward. There is no separate Git history. PREVIEW_UNCOMMITTED is a fixed placeholder in every result row. For the classroom experiment, commit the predictions and code before running, then record the actual commit in every result row.
