"""Derive five-seed summaries and paired differences from results.csv."""
import argparse
import csv
from pathlib import Path

import numpy as np

POLICIES = ["noisy_validation", "clean_validation", "no_early_stop"]
# Two-sided 95% t quantiles by degrees of freedom, for small seed counts.
T95 = {1: 12.706, 2: 4.303, 3: 3.182, 4: 2.776, 5: 2.571, 6: 2.447, 7: 2.365, 8: 2.306, 9: 2.262}


def main():
    ap = argparse.ArgumentParser()
    root = Path(__file__).resolve().parent.parent / "results"
    ap.add_argument("--input", type=Path, default=root / "results.csv")
    ap.add_argument("--out", type=Path, default=root)
    a = ap.parse_args()
    with a.input.open(newline="") as f:
        rows = list(csv.DictReader(f))
    commits = {r["commit"] for r in rows}
    if len(commits) != 1:
        raise ValueError("Analyze one code version at a time")
    commit = next(iter(commits))
    summaries, differences = [], []
    for method in dict.fromkeys(r["method"] for r in rows):
        for rate in sorted({float(r["noise"]) for r in rows if r["method"] == method}):
            groups = {}
            for policy in POLICIES:
                group = sorted([r for r in rows if r["method"] == method
                                and float(r["noise"]) == rate and r["policy"] == policy],
                               key=lambda r: int(r["seed"]))
                if len(group) < 2 or len({r["seed"] for r in group}) != len(group):
                    raise ValueError("Need at least two distinct seeds in every setting")
                groups[policy] = group
                entry = {"commit": commit, "method": method, "noise": rate,
                         "policy": policy, "n_seeds": len(group)}
                for key in ["final_acc", "stop_epoch", "selected_epoch", "wrong_label_fit"]:
                    values = np.array([float(r[key]) for r in group if r[key] != ""])
                    entry[key + "_mean"] = float(values.mean()) if len(values) else ""
                    entry[key + "_sd"] = float(values.std(ddof=1)) if len(values) > 1 else ""
                summaries.append(entry)
            noisy, clean = groups["noisy_validation"], groups["clean_validation"]
            if [r["seed"] for r in noisy] != [r["seed"] for r in clean]:
                raise ValueError("Stopping comparisons require matched seeds")
            entry = {"commit": commit, "method": method, "noise": rate,
                     "comparison": "noisy_minus_clean", "n_seeds": len(noisy)}
            for key in ["final_acc", "stop_epoch", "selected_epoch"]:
                values = np.array([float(n[key]) - float(c[key]) for n, c in zip(noisy, clean)])
                mean, sd = float(values.mean()), float(values.std(ddof=1))
                entry[key + "_delta_mean"] = mean
                entry[key + "_delta_sd"] = sd
                half = T95.get(len(values) - 1, 1.96) * sd / np.sqrt(len(values))
                entry[key + "_delta_ci95_low"] = mean - half
                entry[key + "_delta_ci95_high"] = mean + half
                entry[key + "_ci_crosses_zero"] = bool(mean - half <= 0 <= mean + half)
            differences.append(entry)
    a.out.mkdir(parents=True, exist_ok=True)
    for name, data in [("summary.csv", summaries), ("paired_differences.csv", differences)]:
        with (a.out / name).open("w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(data[0]))
            writer.writeheader()
            writer.writerows(data)
    print(f"done summary_rows={len(summaries)} paired_rows={len(differences)}")


if __name__ == "__main__":
    main()
