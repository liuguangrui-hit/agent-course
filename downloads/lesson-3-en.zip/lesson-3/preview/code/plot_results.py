"""Plot the real Lesson 3 CSV; plotting dependencies are supplied with uv --with."""
import argparse
import csv
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
import numpy as np

METHODS = ["ce", "label_smoothing", "gce", "small_loss"]
TITLES = {"ce": "Cross-entropy", "label_smoothing": "Label smoothing", "gce": "Generalized cross-entropy", "small_loss": "Small-loss selection"}
POLICIES = ["noisy_validation", "clean_validation", "no_early_stop"]
LABELS = {"noisy_validation": "Noisy-validation early stop", "clean_validation": "Clean-validation early stop", "no_early_stop": "No early stopping"}
STYLES = {"noisy_validation": ("#D36B20", "o", "--"), "clean_validation": ("#147A96", "s", "-"), "no_early_stop": ("#68737D", "^", ":")}


def main():
    ap = argparse.ArgumentParser()
    root = Path(__file__).resolve().parent.parent / "results"
    ap.add_argument("--input", type=Path, default=root / "results.csv")
    ap.add_argument("--out", type=Path, default=root / "fig_early_stop.png")
    ap.add_argument("--language", choices=["zh", "en"], default="en")
    a = ap.parse_args()
    chinese = a.language == "zh"
    if chinese:
        names = {font.name for font in font_manager.fontManager.ttflist}
        choices = ["Heiti TC", "Heiti SC", "STHeiti", "PingFang SC", "Noto Sans CJK SC", "Microsoft YaHei", "WenQuanYi Zen Hei"]
        available = [name for name in choices if name in names]
        if not available:
            raise RuntimeError("Install a CJK font before plotting with --language zh")
        plt.rcParams["font.family"] = available + ["DejaVu Sans"]
    titles = {"ce": "交叉熵", "label_smoothing": "标签平滑", "gce": "广义交叉熵", "small_loss": "小损失筛选"} if chinese else TITLES
    labels_by_policy = {"noisy_validation": "带噪验证集早停", "clean_validation": "干净验证集早停", "no_early_stop": "不早停"} if chinese else LABELS
    with a.input.open(newline="") as f:
        rows = list(csv.DictReader(f))
    plt.rcParams.update({"font.size": 11, "axes.spines.top": False, "axes.spines.right": False})
    fig, axes = plt.subplots(2, 2, figsize=(11.4, 8.2), sharex=True, sharey=True)
    for ax, method in zip(axes.flat, METHODS):
        for policy in POLICIES:
            rates = sorted({float(r["noise"]) for r in rows if r["method"] == method})
            means, stds = [], []
            for rate in rates:
                values = np.array([100 * float(r["final_acc"]) for r in rows
                                   if r["method"] == method and r["policy"] == policy
                                   and float(r["noise"]) == rate])
                if len(values) != 5:
                    raise ValueError("Expected five seeds in every plotted setting")
                means.append(values.mean())
                stds.append(values.std(ddof=1))
            color, marker, linestyle = STYLES[policy]
            ax.errorbar(np.array(rates) * 100, means, yerr=stds, color=color,
                        marker=marker, linestyle=linestyle, linewidth=2,
                        markersize=5, capsize=3, label=labels_by_policy[policy])
        ax.set_title(titles[method], loc="left", fontweight="bold")
        ax.set_xticks([0, 20, 40, 60])
        ax.set_xlim(-3, 63)
        ax.set_ylim(30, 102)
        ax.grid(axis="y", alpha=0.18)
        ax.set_axisbelow(True)
    xlabel = "训练与带噪验证集的标签噪声，%" if chinese else "Training / noisy-validation label noise, %"
    ylabel = "最终干净测试准确率，%" if chinese else "Final clean test accuracy, %"
    axes[1, 0].set_xlabel(xlabel)
    axes[1, 1].set_xlabel(xlabel)
    axes[0, 0].set_ylabel(ylabel)
    axes[1, 0].set_ylabel(ylabel)
    fig.suptitle("验证标签与早停" if chinese else "Validation labels and early stopping", x=0.08, ha="left", fontsize=19, fontweight="bold")
    handles, labels = axes[0, 0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="upper center", bbox_to_anchor=(0.5, 0.92), ncol=3, frameon=False, fontsize=10)
    fig.text(0.08, 0.018, "五个种子，误差条为样本标准差。同一训练轨迹，耐心值 8，上限 80 轮。" if chinese else "Five seeds; error bars: sample SD. Shared training trajectory; patience 8; maximum 80 epochs.", fontsize=10, color="#4D5862")
    fig.subplots_adjust(left=0.08, right=0.98, bottom=0.11, top=0.83, hspace=0.28, wspace=0.12)
    a.out.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(a.out, dpi=170, facecolor="white")
    plt.close(fig)


if __name__ == "__main__":
    main()
