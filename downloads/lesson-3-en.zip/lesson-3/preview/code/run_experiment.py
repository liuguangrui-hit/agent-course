"""Lesson 3 early stopping, extended from the Lesson 1 NumPy experiment.

Each loss/noise/seed setting shares a training trajectory across both validation
selectors and the no-stopping control. Test data never selects a checkpoint.
PREVIEW_UNCOMMITTED is an explicit provenance placeholder, not a Git commit.
"""
import argparse
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import time
import warnings

import numpy as np

METHODS = ["ce", "label_smoothing", "gce", "small_loss"]
NOISE = [0.0, 0.2, 0.4, 0.6]
SEEDS = [0, 1, 2, 3, 4]
PLACEHOLDER = "PREVIEW_UNCOMMITTED"


def predict(params, x):
    h = np.maximum(x @ params["W1"] + params["b1"], 0)
    return softmax(h @ params["W2"] + params["b2"])


def cross_entropy(probabilities, labels):
    return float(-np.log(np.maximum(probabilities[np.arange(len(labels)), labels], 1e-12)).mean())


class Selector:
    def __init__(self, patience, min_delta):
        self.patience = patience
        self.min_delta = min_delta
        self.best_loss = float("inf")
        self.best_epoch = 0
        self.best_params = None
        self.wait = 0
        self.stop_epoch = None

    def update(self, epoch, loss, params):
        if self.stop_epoch is not None:
            return
        if not np.isfinite(loss):
            raise ValueError("Validation loss is not finite")
        if loss < self.best_loss - self.min_delta:
            self.best_loss, self.best_epoch, self.wait = loss, epoch, 0
            self.best_params = {name: value.copy() for name, value in params.items()}
        else:
            self.wait += 1
            if self.wait >= self.patience:
                self.stop_epoch = epoch


def resolve_commit(value):
    if value == PLACEHOLDER:
        return value
    if value != "git":
        raise ValueError("Use --commit git for a real run, or the preview placeholder")
    # Require a repository at this preview root, not an unrelated parent repo.
    root = Path(__file__).resolve().parent.parent
    if not (root / ".git").exists():
        raise ValueError("Initialize and commit a repository at the experiment root first")
    status = subprocess.check_output(["git", "status", "--porcelain"], cwd=root, text=True)
    if status.strip():
        raise ValueError("Commit or ignore all changes before running with --commit git")
    return subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip()


def make_data(rng, n_train=4000, n_test=2000, d=20, k=10, sep=1.15):
    means = rng.normal(size=(k, d)) * sep
    def sample(n):
        y = rng.integers(0, k, size=n)
        x = means[y] + rng.normal(size=(n, d))
        return x.astype(np.float32), y
    return sample(n_train), sample(n_test)


def flip(rng, y, rate, k=10):
    y = y.copy()
    idx = rng.random(len(y)) < rate
    y[idx] = (y[idx] + rng.integers(1, k, size=idx.sum())) % k
    return y


def softmax(z):
    z = z - z.max(1, keepdims=True)
    e = np.exp(z)
    return e / e.sum(1, keepdims=True)


def train(x, y_noisy, x_val, y_val_noisy, y_val_clean, method, rate, rng,
          hidden=512, epochs=80, bs=64, lr=2e-3, k=10, patience=8, min_delta=1e-4):
    d = x.shape[1]
    params = {
        "W1": rng.normal(size=(d, hidden)).astype(np.float32) * np.sqrt(2 / d),
        "b1": np.zeros(hidden, np.float32),
        "W2": rng.normal(size=(hidden, k)).astype(np.float32) * np.sqrt(1 / hidden),
        "b2": np.zeros(k, np.float32),
    }
    m = {p: np.zeros_like(v) for p, v in params.items()}
    v = {p: np.zeros_like(v) for p, v in params.items()}
    step = 0
    selectors = {
        "noisy_validation": Selector(patience, min_delta),
        "clean_validation": Selector(patience, min_delta),
    }
    validation_rows = []
    n = len(x)
    for ep in range(epochs):
        order = rng.permutation(n)
        for s in range(0, n, bs):
            b = order[s:s + bs]
            xb, yb = x[b], y_noisy[b]
            h_pre = xb @ params["W1"] + params["b1"]
            h = np.maximum(h_pre, 0)
            p = softmax(h @ params["W2"] + params["b2"])
            onehot = np.eye(k, dtype=np.float32)[yb]
            if method == "ce":
                g = p - onehot
            elif method == "label_smoothing":
                target = onehot * 0.9 + 0.1 / k
                g = p - target
            elif method == "gce":
                q = 0.7
                py = p[np.arange(len(yb)), yb][:, None]
                # d/dz of (1 - p_y^q)/q = -p_y^q * (onehot - p)
                g = (py ** q) * (p - onehot)
            elif method == "small_loss":
                keep_frac = 1 - rate * min(1.0, ep / 10)
                loss = -np.log(p[np.arange(len(yb)), yb] + 1e-12)
                keep = np.argsort(loss)[: max(1, int(round(keep_frac * len(yb))))]
                mask = np.zeros((len(yb), 1), np.float32)
                mask[keep] = 1
                g = (p - onehot) * mask * len(yb) / max(1, len(keep))
            g = g / len(yb)
            grads = {
                "W2": h.T @ g,
                "b2": g.sum(0),
            }
            gh = (g @ params["W2"].T) * (h_pre > 0)
            grads["W1"] = xb.T @ gh
            grads["b1"] = gh.sum(0)
            step += 1
            for name in params:
                m[name] = 0.9 * m[name] + 0.1 * grads[name]
                v[name] = 0.999 * v[name] + 0.001 * grads[name] ** 2
                mh = m[name] / (1 - 0.9 ** step)
                vh = v[name] / (1 - 0.999 ** step)
                params[name] -= lr * mh / (np.sqrt(vh) + 1e-8)
        if not all(np.isfinite(value).all() for value in params.values()):
            raise ValueError("Nonfinite model weights")
        probabilities = predict(params, x_val)
        if not np.isfinite(probabilities).all():
            raise ValueError("Nonfinite validation probabilities")
        losses = {
            "noisy_validation": cross_entropy(probabilities, y_val_noisy),
            "clean_validation": cross_entropy(probabilities, y_val_clean),
        }
        for policy, selector in selectors.items():
            selector.update(ep + 1, losses[policy], params)
            validation_rows.append({"policy": policy, "epoch": ep + 1,
                                    "val_loss": losses[policy],
                                    "selector_stopped": selector.stop_epoch is not None})
    checkpoints = {}
    for policy, selector in selectors.items():
        checkpoints[policy] = {
            "params": selector.best_params, "selected_epoch": selector.best_epoch,
            "stop_epoch": selector.stop_epoch if selector.stop_epoch is not None else epochs,
            "stop_reason": "patience" if selector.stop_epoch is not None else "epoch_limit",
            "selected_val_loss": selector.best_loss,
        }
    checkpoints["no_early_stop"] = {
        "params": params, "selected_epoch": epochs, "stop_epoch": epochs,
        "stop_reason": "epoch_limit", "selected_val_loss": "",
    }
    return checkpoints, validation_rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", type=Path, default=Path(__file__).resolve().parent.parent / "results")
    ap.add_argument("--epochs", type=int, default=80)
    ap.add_argument("--seeds", type=int, nargs="+", default=SEEDS)
    ap.add_argument("--methods", choices=METHODS, nargs="+", default=METHODS)
    ap.add_argument("--noise", type=float, nargs="+", default=NOISE)
    ap.add_argument("--patience", type=int, default=8)
    ap.add_argument("--min-delta", type=float, default=1e-4)
    ap.add_argument("--commit", default=PLACEHOLDER, help="git or PREVIEW_UNCOMMITTED")
    a = ap.parse_args()
    if a.epochs < 1 or a.patience < 1 or a.min_delta < 0 or any(r < 0 or r > 1 for r in a.noise):
        ap.error("Invalid training or early-stopping settings")
    commit = resolve_commit(a.commit)
    a.out.mkdir(parents=True, exist_ok=True)
    rows, validation_rows = [], []
    warning_counts = Counter()
    t0 = time.time()
    for seed in a.seeds:
        (x, y), (x_test, y_test) = make_data(np.random.default_rng(seed))
        split = np.random.default_rng(2000 + seed).permutation(len(x))
        validation_idx, training_idx = split[:400], split[400:]
        for rate in a.noise:
            y_noisy = flip(np.random.default_rng(1000 + seed), y, rate)
            for method in a.methods:
                with warnings.catch_warnings(record=True) as caught:
                    warnings.simplefilter("always", RuntimeWarning)
                    checkpoints, history = train(
                        x[training_idx], y_noisy[training_idx], x[validation_idx],
                        y_noisy[validation_idx], y[validation_idx], method, rate,
                        np.random.default_rng(seed), epochs=a.epochs,
                        patience=a.patience, min_delta=a.min_delta)
                warning_counts.update(str(w.message) for w in caught)
                for policy, checkpoint in checkpoints.items():
                    params = checkpoint.pop("params")
                    with warnings.catch_warnings(record=True) as caught:
                        warnings.simplefilter("always", RuntimeWarning)
                        test_probabilities = predict(params, x_test)
                        train_probabilities = predict(params, x[training_idx])
                    warning_counts.update(str(w.message) for w in caught)
                    if not np.isfinite(test_probabilities).all() or not np.isfinite(train_probabilities).all():
                        raise ValueError("Nonfinite final probabilities")
                    test_predictions = test_probabilities.argmax(1)
                    train_predictions = train_probabilities.argmax(1)
                    corrupted = y_noisy[training_idx] != y[training_idx]
                    wrong_fit = float((train_predictions[corrupted] == y_noisy[training_idx][corrupted]).mean()) if corrupted.any() else ""
                    rows.append({"commit": commit, "method": method, "noise": rate,
                                 "seed": seed, "policy": policy,
                                 "final_acc": float((test_predictions == y_test).mean()),
                                 **checkpoint, "wrong_label_fit": wrong_fit,
                                 "train_true_acc": float((train_predictions == y[training_idx]).mean()),
                                 "epochs": a.epochs, "patience": a.patience,
                                 "min_delta": a.min_delta, "n_train": 3600,
                                 "n_val": 400, "n_test": 2000,
                                 "train_noise_actual": float(corrupted.mean()),
                                 "val_noise_actual": float((y_noisy[validation_idx] != y[validation_idx]).mean())})
                validation_rows.extend({"commit": commit, "method": method, "noise": rate,
                                        "seed": seed, **row} for row in history)
                print(f"seed={seed} noise={rate} method={method} elapsed={time.time()-t0:.1f}s", flush=True)
                # Save complete finished settings so an interruption leaves readable evidence.
                write_csv(a.out / "results.csv", rows)
                write_csv(a.out / "validation_curves.csv", validation_rows)
    source = Path(__file__).read_bytes()
    metadata = {"commit": commit, "commit_is_placeholder": commit == PLACEHOLDER,
                "code_sha256": hashlib.sha256(source).hexdigest(),
                "python": platform.python_version(), "numpy": np.__version__,
                "platform": platform.system(), "machine": platform.machine(),
                "methods": a.methods, "noise": a.noise, "seeds": a.seeds,
                "epochs": a.epochs, "patience": a.patience, "min_delta": a.min_delta,
                "hidden": 512, "batch_size": 64, "learning_rate": 0.002,
                "n_train": 3600, "n_val": 400, "n_test": 2000,
                "validation_fraction": 0.1, "elapsed_seconds": time.time()-t0,
                "rows": len(rows), "evaluation": "one final test evaluation per policy",
                "execution": "local CPU; one shared trajectory per loss/noise/seed",
                "numeric_warnings": dict(warning_counts),
                "finite_checks": "weights and validation probabilities each epoch; final train/test probabilities"}
    (a.out / "run_metadata.json").write_text(json.dumps(metadata, indent=2) + "\n")
    print(f"done rows={len(rows)} elapsed={time.time()-t0:.1f}s", flush=True)


def write_csv(path, rows):
    with path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


if __name__ == "__main__":
    main()
