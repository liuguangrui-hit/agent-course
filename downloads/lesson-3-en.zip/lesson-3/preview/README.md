# Completed Exercises 2 and 3

Predictions were written first, early stopping was then implemented and run locally in full, and the results were compared and self-reviewed by Codex.

| File or folder | Purpose |
|---|---|
| [prediction.md](prediction.md) | Prerun predictions, reasons, falsification criteria, and fixed settings |
| [code/run_experiment.py](code/run_experiment.py) | Adds both validation stopping rules and a no-stopping control to Lesson 1 code |
| [code/analyze_results.py](code/analyze_results.py) | Computes grouped means, SDs, and same-seed differences from per-run results |
| [code/plot_results.py](code/plot_results.py) | Plots final accuracy for all three policies from CSV |
| [results/results.csv](results/results.csv) | 240 real result rows, each with a commit column |
| [results/validation_curves.csv](results/validation_curves.csv) | Per-epoch validation losses and selector status, without test curves |
| [results/summary.csv](results/summary.csv) | Five-seed means and sample SDs for each setting |
| [results/paired_differences.csv](results/paired_differences.csv) | Noisy minus clean differences matched by seed |
| [results/fig_early_stop.png](results/fig_early_stop.png) | Four losses, four noise levels, and three stopping policies |
| [results/run_metadata.json](results/run_metadata.json) | Actual environment, settings, code digest, warning counts, and elapsed time |
| [results/numerical_check.json](results/numerical_check.json) | Matrix-multiplication comparisons against a double-precision reference |
| [results/run.log](results/run.log) | Full experiment log ending in done |
| [result.md](result.md) | Predictions beside outcomes, verdicts, and evidence limits |
| [review.md](review.md) | Codex self-review tied to this result version |

## Reproduce

Run from the parent practice folder. Save new outputs separately to preserve the classroom preview.

```sh
uv run python preview/code/run_experiment.py --seeds 0 --epochs 5 --out results/smoke
uv run python preview/code/run_experiment.py --out results/replay
uv run python preview/code/analyze_results.py --input results/replay/results.csv --out results/replay
uv run --with matplotlib==3.9.4 python preview/code/plot_results.py --input results/replay/results.csv --out results/replay/fig_early_stop.png --language en
```

The experiment and summaries depend only on numpy. Plotting adds matplotlib temporarily through uv. Final test accuracy is evaluated at the restored weights. stop_epoch is the stopping trigger, and selected_epoch is the restored checkpoint epoch; both are 80 for no stopping. Both selectors share a trajectory and freeze when triggered, without changing their selections using later validation losses.

Every result commit is PREVIEW_UNCOMMITTED, explicitly marking an uncommitted preview. Commit the extended code before the classroom run. The completed script supports --commit git, checking Git status at its project root and refusing uncommitted changes. Place it in the classroom project code/ folder to use that mode, and write classroom logs to logs/run.log.

This run used the local machine, with no server execution, GitHub push, or independent review by a different agent.
