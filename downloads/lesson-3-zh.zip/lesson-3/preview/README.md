# 练习 2 与 3 的成品

先写预测，再实现早停并在本机跑完整实验，最后对照数字并由 Codex 自审。

| 文件或文件夹 | 用途 |
|---|---|
| [prediction.md](prediction.md) | 实验前预测、理由、推翻条件和预先固定的设置 |
| [code/run_experiment.py](code/run_experiment.py) | 在第 1 课代码上增加两种验证集早停与不早停对照 |
| [code/analyze_results.py](code/analyze_results.py) | 从逐次结果计算分组均值、标准差和同种子差值 |
| [code/plot_results.py](code/plot_results.py) | 从 CSV 画三种策略的最终准确率图 |
| [results/results.csv](results/results.csv) | 240 行真实结果，每行有 commit 列 |
| [results/validation_curves.csv](results/validation_curves.csv) | 每轮验证损失和选择器是否已停止，不含测试曲线 |
| [results/summary.csv](results/summary.csv) | 每个设置的五种子均值与样本标准差 |
| [results/paired_differences.csv](results/paired_differences.csv) | 按相同种子计算带噪减干净的差值与波动 |
| [results/fig_early_stop.png](results/fig_early_stop.png) | 四种损失、四档噪声、三种停止策略的图 |
| [results/run_metadata.json](results/run_metadata.json) | 实际环境、参数、代码摘要、告警计数和运行耗时 |
| [results/numerical_check.json](results/numerical_check.json) | 矩阵乘法与双精度参考计算的核对记录 |
| [results/run.log](results/run.log) | 完整实验日志，末行 done 表示结束 |
| [result.md](result.md) | 预测与结果并排、对错判断和结论边界 |
| [review.md](review.md) | 对这个结果版本的 Codex 自审意见 |

## 重跑

在上一层练习目录运行。输出另存，保留课上先看的成品。

```sh
uv run python preview/code/run_experiment.py --seeds 0 --epochs 5 --out results/smoke
uv run python preview/code/run_experiment.py --out results/replay
uv run python preview/code/analyze_results.py --input results/replay/results.csv --out results/replay
uv run --with matplotlib==3.9.4 python preview/code/plot_results.py --input results/replay/results.csv --out results/replay/fig_early_stop.png --language zh
```

实验与汇总只依赖 numpy，画图通过 uv 临时补充 matplotlib。最终测试准确率在恢复后的权重上计算。触发停止和恢复权重轮次分别是 stop_epoch 与 selected_epoch，不早停的两列都为 80。两种早停共用训练轨迹，选择器触发后冻结，不再看后续验证损失来改变选择。

结果的 commit 均为 PREVIEW_UNCOMMITTED，明确表示未提交的预览。学员完成早停代码后，在正式运行前提交；成品脚本的 --commit git 模式会检查其项目根目录的 Git 状态，有未提交改动就拒绝运行。把脚本放到课堂项目 code/ 中使用该模式，日志仍按课堂任务写到 logs/run.log。

本次只在本机执行，没有服务器运行、GitHub 推送或独立跨 Agent 审查记录。
