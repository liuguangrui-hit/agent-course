#!/usr/bin/env python3
"""Enumerate symmetric label corruption; no model calls or random sampling."""
from fractions import Fraction
import json


def enumerate_accuracy(classes, noise, n_correct, n_examples=4):
    total = Fraction(0)
    for index in range(n_examples):
        truth = index % classes
        prediction = truth if index < n_correct else (truth + 1) % classes
        for observed in range(classes):
            probability = 1 - noise if observed == truth else noise / (classes - 1)
            total += probability * (prediction == observed)
    return total / n_examples


def main():
    rows = []
    for classes in (2, 3, 10):
        for noise in (Fraction(0), Fraction(2, 5), Fraction(9, 10)):
            for correct in (0, 1, 2, 4):
                clean = Fraction(correct, 4)
                formula = (1 - classes * noise / (classes - 1)) * clean + noise / (classes - 1)
                actual = enumerate_accuracy(classes, noise, correct)
                if actual != formula:
                    raise ArithmeticError('identity failed')
                rows.append({'classes': classes, 'noise': float(noise),
                             'clean_accuracy': float(clean), 'noisy_accuracy': float(actual)})
    print(json.dumps({'kind': 'exact enumeration, not a training experiment',
                      'verified_cases': len(rows), 'rows': rows}, indent=2))


if __name__ == '__main__':
    main()
