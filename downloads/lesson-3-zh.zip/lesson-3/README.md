# 第 3 课练习材料：实验分析

## 本课的三个阶段

- 课前预备：准备 Git、锁定依赖、logs/ 与可用执行端，不启动正式训练。
- 课上一小时：课堂先冻结预测，再改代码与做短运行；预览分析另存演练文件，新对照的正式结论课后写。
- 课后复习与拔高：先复述判别计划，再辨析不显著与等价，最后补种子、区间或机制对照。

课前检查写入 preflight.md，课后复盘写入 review-after-class.md。逐段时间与正反例见本课课程页。安装和下载在课前完成，课堂直接使用本地材料。

从第 1 课的标签噪声实验出发，练习先写预测、提交代码、后台运行、对照结果和审查结论。

| 文件或文件夹 | 用途 |
|---|---|
| [questions.md](questions.md) | 一个可直接开始的题目与摘要 |
| [code/run_experiment.py](code/run_experiment.py) | 原样复制第 1 课实验代码，供练习 2 修改 |
| [data/results.csv](data/results.csv) | 第 1 课每次运行的原始结果 |
| [data/curves.csv](data/curves.csv) | 第 1 课每轮测试准确率，供理解现象 |
| [pyproject.toml](pyproject.toml) | uv 环境，只依赖 numpy |
| [uv.lock](uv.lock) | 锁定环境版本 |
| [.gitignore](.gitignore) | 排除数据、结果、环境、密钥、PDF 和运行日志 |
| [logs/](logs/) | 空目录，课堂实验的 logs/run.log 放在这里 |
| [preview/](preview/README.md) | 先写预测再实跑的完整成品，包含结果图和 Codex 自审 |
| [AGENTS.md](AGENTS.md) | 两家 Agent 共用的稳定项目约定 |
| [CLAUDE.md](CLAUDE.md) | 引用 AGENTS.md |

## 环境准备与课堂使用

在这一文件夹打开 Agent，先读问题和第 1 课数据，再按正文练习 1 至 3 操作。根目录的 prediction.md、result.md、review.md 和 results/ 是学员要生成的文件；成品示例保存在 preview/。

环境使用 Python 3.9 至 3.12 和 numpy 2.0.2。课前准备好 uv，先下载依赖并检查导入：

```sh
uv sync --frozen
mkdir -p logs
uv run python -c "import numpy; print(numpy.__version__)"
```

原始代码把结果写入 data/，不要在课前运行它覆盖材料。课堂按判别计划修改后，输出写到新目录。在练习 2 修改时，增加验证集早停、种子和轮数参数，并把新输出改到 results/。原始 --quick 是 20 轮，课堂的 5 轮冒烟测试需新增轮数参数。logs/ 在练习目录中为空，Git 和当前网站打包脚本都不保留空目录，解压或 clone 后先执行 mkdir -p logs。

两种早停应使用同一批 10% 验证样本，干净对照只替换验证标签。停止后恢复最佳验证损失权重，分别记录所选权重轮次和触发停止轮次。查看 [预览说明](preview/README.md) 可直接重跑成品。

## 加深练习

[verify_noise_identity.py](verify_noise_identity.py)用有理数枚举对称标签翻转，核验带噪准确率的期望公式。它验证数学关系，不执行训练，也不直接验证当前按交叉熵早停的实现。

```bash
python3 verify_noise_identity.py
```

课堂对新对照两臂做同种子的短运行，只检查配对与输出结构。五种子预览另写 smoke/analysis-rehearsal.md 练区间，不回答新增对照。完整任务按冻结 prediction.md 课后运行，随后写正式 result.md 和 review.md。第 2 课问题页展示了按准确率选择轮次的方案，当前预览按交叉熵、耐心值 8 早停，两项设计分别登记。预览中的提交占位字段保留原貌，代码哈希是实际身份；正式实验记录自己的真实提交。
