# 第 3 课 Agent 实验练习材料

从第 1 课的标签噪声实验出发，练习先写预测、提交代码、后台运行、对照结果和审查结论。

| 文件或文件夹 | 用途 |
|---|---|
| [questions.md](questions.md) | 一个可直接开始的题目与摘要 |
| [code/run_experiment.py](code/run_experiment.py) | 原样复制第 1 课实验代码，供练习 2 修改 |
| [data/results.csv](data/results.csv) | 第 1 课每次运行的原始结果 |
| [data/curves.csv](data/curves.csv) | 第 1 课每轮测试准确率，供理解现象 |
| [pyproject.toml](pyproject.toml) | uv 环境，只依赖 numpy |
| [uv.lock](uv.lock) | 锁定环境版本 |
| [.gitignore](.gitignore) | 排除数据、结果、环境、密钥、PDF 和运行日志 |
| [logs/](logs/) | 空目录，课堂实验的 logs/run.log 放在这里 |
| [preview/](preview/README.md) | 先写预测再实跑的完整成品，包含结果图和 Codex 自审 |
| [AGENTS.md](AGENTS.md) | 两家 Agent 共用的稳定项目约定 |
| [CLAUDE.md](CLAUDE.md) | 引用 AGENTS.md |

## 使用

在这一文件夹打开 Agent，先读问题和第 1 课数据，再按正文练习 1 至 3 操作。根目录的 prediction.md、result.md、review.md 和 results/ 是学员要生成的文件；成品示例保存在 preview/。

环境使用 Python 3.9 至 3.12 和 numpy 2.0.2。准备好 uv 后运行：

```sh
uv sync --frozen
mkdir -p logs
uv run python code/run_experiment.py
```

原始代码把结果写入 data/。在练习 2 修改时，增加验证集早停、种子和轮数参数，并把新输出改到 results/。原始 --quick 是 20 轮，课堂的 5 轮冒烟测试需新增轮数参数。logs/ 在练习目录中为空，Git 和当前网站打包脚本都不保留空目录，解压或 clone 后先执行 mkdir -p logs。

两种早停应使用同一批 10% 验证样本，干净对照只替换验证标签。停止后恢复最佳验证损失权重，分别记录所选权重轮次和触发停止轮次。查看 [预览说明](preview/README.md) 可直接重跑成品。
